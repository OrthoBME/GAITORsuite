function calibrations = findCali2(date,panel)

% Find the date, and define the calibration constants based on the date.
% Specific to EHL's data. Definitely a clunky hard code - but it saved time
% for EHL processing the data.
% cal_X, cal_Y, and cal_Z = slope of calibration curve in v/g
% cal_Xint, cal_Yint, and cal_Zint = y-intercepts of the calibration curve
% in volts.

date = num2str(date);

comp = [];
comp(1) = strcmp(date,'20160314');  % strcmp compares 2 strings.  1 = they are the same, 0 = not the same.
comp(2) = strcmp(date,'20160315');
comp(3) = strcmp(date,'20160316');
comp(4) = strcmp(date,'20160317');
comp(5) = strcmp(date,'20160411');
comp(6) = strcmp(date,'20160414');
comp(7) = strcmp(date,'20160418');
comp(8) = strcmp(date,'20160502');
comp(9) = strcmp(date,'20160504');
comp(10) = strcmp(date,'20160506');
loc = find(comp == 1);  % find where the dates matched -- look for the location of the 1.

if loc == 1;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
elseif loc == 2;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0038;        cal_Y = 0.0076;        cal_Z = 0.0041;
        cal_Xint = -0.2413;    cal_Yint = 0.4018;     cal_Zint = -0.0260;
    else
        cal_X = 0.0113;        cal_Y = 0.0115;        cal_Z = 0.0036;
        cal_Xint = 0.2918;     cal_Yint = -0.1752;    cal_Zint = 0.0045;
    end
elseif loc == 3;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0095;        cal_Y = 0.0076;        cal_Z = 0.0040;
        cal_Xint = -0.6066;    cal_Yint = 0.3809;     cal_Zint = 0.0187;
    else
        cal_X = 0.0128;        cal_Y = 0.0109;        cal_Z = 0.0036;
        cal_Xint = 0.1152;     cal_Yint = -0.2018;    cal_Zint = 0.0106;
    end
elseif loc == 4;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0044;        cal_Y = 0.0082;        cal_Z = 0.0041;
        cal_Xint = -0.0555;    cal_Yint = 0.3905;     cal_Zint = 0.0278;
    else
        cal_X = 0.0131;        cal_Y = 0.01197;        cal_Z = 0.0037;
        cal_Xint = 0.1189;     cal_Yint = 0.9657;     cal_Zint = -0.0007; 
    end
elseif loc == 5;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0149;        cal_Y = 0.0068;        cal_Z = 0.0044;
        cal_Xint = 0.1237;     cal_Yint = 0.5092;     cal_Zint = 0.0039;
    else
        cal_X = 0.0116;        cal_Y = 0.0140;        cal_Z = 0.0037;
        cal_Xint = 0.0980;     cal_Yint = -0.3548;    cal_Zint = 0.0106;
    end
elseif loc == 6;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0144;        cal_Y = 0.0083;        cal_Z = 0.0036;
        cal_Xint = 0.1060;     cal_Yint = 0.4651;     cal_Zint = 0.1697;
    else
        cal_X = 0.0127;        cal_Y = 0.0125;        cal_Z = 0.0037;
        cal_Xint = 0.1325;     cal_Yint = -0.2146;    cal_Zint = 0.0048; 
    end
elseif loc == 7;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0147;        cal_Y = 0.0070;        cal_Z = 0.0040;
        cal_Xint = 0.0829;     cal_Yint = 0.4559;     cal_Zint = 0.0617;
    else
        cal_X = 0.0124;        cal_Y = 0.0110;        cal_Z = 0.0035;
        cal_Xint = 0.1239;     cal_Yint = -0.1597;    cal_Zint = 0.0339; 
    end
elseif loc == 8;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0135;        cal_Y = 0.0071;        cal_Z = 0.0044;
        cal_Xint = -0.0653;    cal_Yint = 0.4873;     cal_Zint = 0.0102;
    else
        cal_X = 0.0104;        cal_Y = 0.0122;        cal_Z = 0.0038;
        cal_Xint = 0.0064;     cal_Yint = -0.3074;    cal_Zint = -0.0089;
    end
elseif loc == 9;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0118;        cal_Y = 0.0069;        cal_Z = 0.0039;
        cal_Xint = 0.1115;     cal_Yint = 0.4238;     cal_Zint = 0.0231;
    else
        cal_X = 0.0114;        cal_Y = 0.0120;        cal_Z = 0.0038;
        cal_Xint = 0.0657;     cal_Yint = -0.2630;    cal_Zint = -0.0171;
    end
elseif loc == 10;
    if panel == 'A' || panel == 'a'
        cal_X = 0.0068;        cal_Y = 0.0079;        cal_Z = 0.0045;
        cal_Xint = -0.6595;    cal_Yint = 0.4122;     cal_Zint = -0.0315;
    else
        cal_X = 0.0117;        cal_Y = 0.0115;        cal_Z = 0.0036;
        cal_Xint = 0.1630;     cal_Yint = -0.2583;    cal_Zint = 0.01113; 
    end
end

calibrations = [cal_X cal_Y cal_Z cal_Xint cal_Yint cal_Zint]; 

end