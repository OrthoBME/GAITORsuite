  function [Results] = EDGARStepTracker(Input, AGATHA_Data, file)

%% Inputs to EDGAR_StepTracker
%
% Input: Taken from 'Input_Setup.m'.  Gives a cell array of all input
%        variables, including the x-coordinate locations of each force panel.
% AGATHA_Data: Output from AGATHA. If you are trying to run this function
%        independently from AGATHA - then you need to preload your AGATHAData.mat
%        into the workspace.  For example, type: load('AGATHAData.mat') into the
%        workspace before you call the function. 
% file:  Trial name.  For example, 'Rat06_t03_'

%% EDGAR_StepTracker  January 18, 2017
% Last Updated: January 19, 2017
% Brittany Y. Jacobs & Emily H. Lakes

%% To Run EDGAR_StepTracker as a script, uncomment the following:
% load('Input_EX16_Week12.mat'); 
% Directory = uigetdir;
% File = uipickfiles('FilterSpec',Directory,'Type',{'*.mat' '.mat'});
% FileCount = 1;
% Finish = length(File);
% TrialIDName = [];

% while FileCount <= Finish  
% try
    
% File = cellstr(File); 
% [~,trialname,~] = fileparts(File{FileCount});
% load ([trialname '.mat']);
% AGATHA_Data = DATA.AGATHA;
% FileCount = FileCount + 1;
% file = trialname;
% Comment out if statement at line 165
%% End script functionality %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


A = Input.PlateBounds(1);
AB = Input.PlateBounds(2);
B = Input.PlateBounds(3);
C = Input.PlateBounds(4);
CD = Input.PlateBounds(5);
D = Input.PlateBounds(6);

nameparts = regexp(file, '_','split');  

date = nameparts{1};
animalnum = nameparts{2};
trial = nameparts{3};
IDtag = [animalnum trial];

OutputName = [date animalnum];
xlsFileName = [OutputName, '.xls'];
if ~exist(xlsFileName,'file') 
    xlswrite(xlsFileName, [{'Trial'} {'Direction'} {'Fore/Hind'} {'L/R Foot'} {'Panel'}]);
end

A_panel = [];
B_panel = [];
C_panel = [];
D_panel = [];
A_txt = {};
B_txt = {};
C_txt = {};
D_txt = {};
    
% From AGATHA_Data, we want columns 10 (x location of top left corner
% of paw) and 12 (width of paw in x direction).
PawMin = AGATHA_Data(:,12);
PawMax = AGATHA_Data(:,12) + AGATHA_Data(:,14);  % = Pawmin + width of paw
PawWidth = AGATHA_Data(:,14);
PawCenter = AGATHA_Data(:,10);  % Paw centroid

% Define new bounds for 80% of the paw, taken from the heel
% (BackwardRange) and the toe (ForwardRange).
Range1 = PawMax - 0.8*(PawWidth);
Range2 = PawMin + 0.8*(PawWidth);

for i = 1:size(AGATHA_Data,1)
    if (PawCenter(i) > A & PawCenter(i) < AB) & (((Range1(i) > A & Range1(i) < AB) & (PawMax(i) > A & PawMax(i) < AB)) || ((PawMin(i) > A & PawMin(i) < AB) & (Range2(i) > A & Range2(i) < AB)))
        AGATHA_Data(i,17) = 1;
    elseif (PawCenter(i) > AB & PawCenter(i) < B) & (((Range1(i) > AB & Range1(i) < B) & (PawMax(i) > AB & PawMax(i) < B)) || ((PawMin(i) > AB & PawMin(i) < B) & (Range2(i) > AB & Range2(i) < B)))
        AGATHA_Data(i,17) = 2;
    elseif (PawCenter(i) > C & PawCenter(i) < CD) & (((Range1(i) > C & Range1(i) < CD) & (PawMax(i) > C & PawMax(i) < CD)) || ((PawMin(i) > C & PawMin(i) < CD) & (Range2(i) > C & Range2(i) < CD)))
        AGATHA_Data(i,17) = 3;
    elseif (PawCenter(i) > CD & PawCenter(i) < D) & (((Range1(i) > CD & Range1(i) < D) & (PawMax(i) > CD & PawMax(i) < D)) || ((PawMin(i) > CD & PawMin(i) < D) & (Range2(i) > CD & Range2(i) < D)))
        AGATHA_Data(i,17) = 4;
    else
        AGATHA_Data(i,17) = 400;
    end
end

Results = AGATHA_Data;
seek400 = find(Results(:,17) == 400);
Results(seek400,:) = [];

xlsResults = [Results(:,2) Results(:,9) Results(:,16) Results(:,17)];
    
if xlsResults(1,3) == 0
    for j = 1:length(xlsResults(:,1))
            if xlsResults(j,1) == 1
                ForeHind(j,1) = cellstr('Fore Paw');
            else
                ForeHind(j,1) = cellstr('Hind Paw');
            end
            if xlsResults(j,2) == 1
                LRFoot(j,1) = cellstr('Left Paw');
            else
                LRFoot(j,1) = cellstr('Right Paw');
            end
            if xlsResults(j,3) == 1
                direction(j,1) = cellstr('Left');
            else
                direction(j,1) = cellstr('Right');
            end
            if xlsResults(j,4) == 1
                Panel(j,1) = cellstr('A');
            elseif xlsResults(j,4) == 2
                Panel(j,1) = cellstr('B');
            elseif xlsResults(j,4) == 3
                Panel(j,1) = cellstr('C');
            elseif xlsResults(j,4) == 4
                Panel(j,1) = cellstr('D');
            end
            Trial(j,1) = cellstr(IDtag);
    end
else
    count = 1;
        for j = length(xlsResults(:,1)):-1:1
            if xlsResults(j,1) == 1
                ForeHind(count,1) = cellstr('Fore Paw');
            else
                ForeHind(count,1) = cellstr('Hind Paw');
            end
            if xlsResults(j,2) == 1
                LRFoot(count,1) = cellstr('Left Paw');
            else
                LRFoot(count,1) = cellstr('Right Paw');
            end
            if xlsResults(j,3) == 1
                direction(count,1) = cellstr('Left');
            else
                direction(count,1) = cellstr('Right');
            end
            if xlsResults(j,4) == 1
                Panel(count,1) = cellstr('A');
            elseif xlsResults(j,4) == 2
                Panel(count,1) = cellstr('B');
            elseif xlsResults(j,4) == 3
                Panel(count,1) = cellstr('C');
            elseif xlsResults(j,4) == 4
                Panel(count,1) = cellstr('D');
            end
            Trial(count,1) = cellstr(IDtag);
            count = count+1;
        end
end
           
Results = [Trial direction ForeHind LRFoot Panel];
    
[success,message] = xlsappend(xlsFileName,Results,1);

% Don't try and look at file{2} if you only chose 1 file to begin with.
% Comment out below if running within AGATHA
% if length(File) == 1
%     break
% end
% end
% Stop commenting out things here.

end
