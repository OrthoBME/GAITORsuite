%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  dynamicEDGAR_DMM.m
%%%%%  EDGAR Dynamic Data Processing Interface
%%%%%  Edited from ZXPeaks (HEK) by BYMJ 12-12-14
%%%%%  Edited from dynamicEDGAR.m (BYMJ) by EHL 03-23-2016
%%%%%  Edited from dynamicEDGAR_EHL2.m (EHL) by BYMJ on 4-6-2017
%%%%%  EHL converted to 4 force plate system, and now calculates the free
%%%%%  moment and center of pressure for the foot.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear;
home;
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% SET BATCH NAME AND SETUP MODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set summary file name for batch
batch = 'DMM_Results.xls';

% Select setup. For 2-cube/4-panel setup, please set setup to 'EDGAR'. For
% 4-cube/2-panel setup, please set setup to 'EDGAR2'.
setup = 'EDGAR_DMM';
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Note:
% 1 = LEFT FOOT;        % 0 = RIGHT FOOT;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  FIND FILE
%%%%%  (EDIT ON 8/17/15 BYMJ) & Pull Info (EHL 9/27/2016)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose what file type you have.  Change to '*.tdms' to convert directly
% from .tdms within the code.  If you already converted, then leave as .mat
[file,path] = uigetfile('*.tdms','Find the Files to Import','MultiSelect', 'on');

% This is needed for the multiselect.  Always put the file in this format.
file = cellstr(file); 

% START loop for each trial/file you clicked above.
for n = 1:length(file)
    filename = fullfile ( path, file{n} );
    % Break up filename into path, name, and extension.
    [path,name,extension] = fileparts(filename);  
    
    % Break up the name into it's components (assumes name is separated by 
    % underscores).  Change this based on your naming convention.
    switch setup
        case 'EDGAR'
            nameparts = regexp(name, '_','split');  
            date = nameparts{1};
            animalnum = nameparts{2};
            trial = nameparts{3};
        case 'EDGAR2'
            nameparts = regexp(name, '_','split');  
            date = nameparts{2};
            animalnum = nameparts{3};
            trial = nameparts{4};
        case 'EDGAR_DMM'
            nameparts = regexp(name, '_','split');  
            date = nameparts{1};
            group = nameparts{2};
            gender = nameparts{3};
            animalnum = nameparts{4};
            trial = str2double(nameparts{5}(2:end));
    end

    % Pull the body weight from the file name. 
    % In grams. -- Specific to EHL's data - edit for your data.
    % All animalnum are 'r##', so take last 2 digits in the string, 
    % and convert to a number.
    animalcolumn = str2double(animalnum);  
    date = str2double(date);
    
    % Specific to DMM experiment. 
    if strcmp(setup,'EDGAR_DMM')
        % BW matrix has animalnum as the column (DMM mice labeled 0-4 in
        % each cage). 
        if strcmp(gender,'F')
            if strcmp(group,'DMM')
                if date < 20160630 % Week 2
                    BWmatrix = [22 22 26 23 24];
                elseif date < 20160714 && date > 20160630 % Week 4
                    BWmatrix = [24 25 26 23 25];
                elseif date < 20160728 && date > 20160714 % Week 6
                    BWmatrix = [25 25 28 24 26];
                elseif date < 20160818 && date > 20160728 % Week 9
                    BWmatrix = [26 28 32 26 28];
                elseif date > 20160818 % Week 12
                    BWmatrix = [25 33 35 28 30];
                end
            elseif strcmp(group,'SHAM')
                if date < 20160630 % Week 2
                    BWmatrix = [23 22 22 23 22];
                elseif date < 20160714 && date > 20160630 % Week 4
                    BWmatrix = [23 24 24 25 23];
                elseif date < 20160728 && date > 20160714 % Week 6
                    BWmatrix = [22 24 24 23 23];
                elseif date < 20160818 && date > 20160728 % Week 9
                    BWmatrix = [25 24 28 23 23];
                elseif date > 20160818 % Week 12
                    BWmatrix = [27 24 28 26 24];
                end
            end
        elseif strcmp(gender,'M')
            if strcmp(group,'DMM')
                if date < 20160630 % Week 2
                    BWmatrix = [27 30 29 26 29];
                elseif date < 20160714 && date > 20160630 % Week 4
                    BWmatrix = [28 32 31 28 29];
                elseif date < 20160728 && date > 20160714 % Week 6
                    BWmatrix = [30 34 33 30 31];
                elseif date < 20160818 && date > 20160728 % Week 9
                    BWmatrix = [32 39 34 35 34];
                elseif date > 20160818 % Week 12
                    BWmatrix = [35 40 36 36 35];
                end
            elseif strcmp(group,'SHAM')
                if date < 20160630 % Week 2
                    BWmatrix = [26 24 25 26 26];
                elseif date < 20160714 && date > 20160630 % Week 4
                    BWmatrix = [29 26 28 27 28];
                elseif date < 20160728 && date > 20160714 % Week 6
                    BWmatrix = [30 30 30 29 29];
                elseif date < 20160818 && date > 20160728 % Week 9
                    BWmatrix = [33 35 34 35 34];
                elseif date > 20160818 % Week 12
                    BWmatrix = [38 39 33 36 33];
                end
            end
        end
        BW = BWmatrix(animalcolumn+1);  % Add 1 because mouse numbers were 0-4, but BWmatrix is 1-5.
    end
    
    % Call getforceEDGAR
    % n is the number of files you clicked. For each file, run 
    % getforceEDGAR/getforceEDGAR2.
    switch setup
        case 'EDGAR'
            getforceEDGAR(animalnum, name, n, filename, thresh, BW, date, path, batch); 
        case 'EDGAR2'
            getforceEDGAR2(animalnum, name, n, filename, thresh, BW, date, path, batch); 
        case 'EDGAR_DMM'
            getforceEDGAR_DMM(animalnum, group, gender, name, trial, filename, BW, date, batch); 
    end
    
    if length(file) == 1
        break
    end
end

fprintf ('COMPLETE  \n \n')
clear
