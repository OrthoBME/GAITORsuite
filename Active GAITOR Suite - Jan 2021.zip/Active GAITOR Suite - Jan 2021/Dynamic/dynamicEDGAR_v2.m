%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  dynamicEDGAR_v2.m
%%%%%  EDGAR Dynamic Data Processing Interface
%%%%%  Rebuild by KDA on March 6, 2020
%%%%%  Edited by KMC on March 19, 2020 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This code will isolate fore/hind paw contacts on the force plates and
% save data for each step in a .mat file

% Date in .mat file includes: 
% [Time, X_values, Y_values, Z_values, AC/BD, R/L, A/B/C/D]
% where: data(:,5) = AC/BD where 1 = AC and 0 = BD
%        data(:,6) = R/L where 1 = Right and 0 = Left
%        data(:,7) = A/B/C/D where 1 = A, 2 = B, 3 = C, 4 = D

% To run, load batch of .tdms dynamic files

clc; clearvars;
home;
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SET BATCH NAME AND SETUP MODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose what file type you have.  Change to '*.tdms' to convert directly
% from .tdms within the code.  If you already converted, then leave as .mat
[file,path] = uigetfile('*.tdms','Find the File to Import','MultiSelect', 'on');
file = cellstr(file); 

%% TRIM FORCE CURVES TO FOOT-STIKE OF INTEREST

for n=1:length(file)
    
    q='y';
    counter=1;
       
    close all
   
    while q == 'y'
    % Open the file
        filename = fullfile ( path, file{n} );
        [path,name,extension] = fileparts(filename);  
        if exist([filename(1:end-5) '.mat'],'file') 
             matFile{1} = [filename(1:end-5) '.mat'];
        else
            % Convert function is from MathWorks. EHL made no edits to it.  It converts
            % the .tdms file from Labview directly into a .mat file for MatLab. This 
            % removes the step of converting files to excel before importing them 
            % into Matlab. 
            matFile = simpleConvertTDMS(filename,1); 
        end
        fprintf('Loading... %s \n',name);
        load(matFile{1});

        % Convert the TDMS file into MATLAB matrix
        rawtime = (Time.Data);
        ACPlate_FZ = (Untitled5.Data);
        BDPlate_FZ = (Untitled2.Data);
        ACPlate_FX = (Untitled4.Data);
        BDPlate_FX = (Untitled1.Data);
        ACPlate_FY = (Untitled3.Data);
        BDPlate_FY = (Untitled.Data);
        rawdata = [rawtime ACPlate_FX ACPlate_FY ACPlate_FZ BDPlate_FX BDPlate_FY BDPlate_FZ];
        clear Time Untitled Untitled1 Untitled2 Untitled3 Untitled4 Untitled5
        clear rawtime ACPlate_FX ACPlate_FY ACPlated_FZ BDPlate_FX BDPlate_FY BDPlated_FZ

        % Apply a lowpass 25Hz Butterworth Filter
        fNorm = 25/(2500/2); % 25 Hz cutoff, fs = 2500 Hz
        [B, A] = butter(4, fNorm, 'low'); 
        FilteredData = [rawdata(:,1), filter(B,A,rawdata(:,2)), filter(B,A,rawdata(:,3)), ...
            filter(B,A,rawdata(:,4)), filter(B,A,rawdata(:,5)), filter(B,A,rawdata(:,6)), ...
            filter(B,A,rawdata(:,7))];  

        %% Pick the Force Plate
        % Here you will select which force plate your step is on (click anywhere on the curve).
        % The blue curve shows the Z data from force plates AC and the
        % orange curve shows the Z data from force plates BD.
        
        % Here you can change the position on the screen that the curves
        % show up. You will need to change the coordinates for all lines in
        % the code. OuterPosition = [left bottom width height]
        fig = figure('units','normalized','outerposition',[0 0 0.5 0.75]);
        hold on
        subplot(3,4,[2:4,6:8,10:12]), plot(FilteredData(:,1), FilteredData(:,4), FilteredData(:,1), FilteredData(:,7));
        title('Vertical Force-Time Curves');
        xlabel('Time');
        ylabel('Vertical Force (in Voltage)');
        t1 = subplot(3,4,1, 'replace');
        fixfont = text(0,0,sprintf('Which Force Plate? \nBlue = AC \nOrange = BD \nClick the Curve \nPress Enter to END'), 'Parent', t1); axis off
        fixfont.FontSize = 14;
        % Enable data cursor mode
        datacursormode on
        dcm_obj = datacursormode(fig);
        % Set update function
        set(dcm_obj);
        % Wait while the user to click
        pause 
        % Export cursor to workspace
        info_struct = getCursorInfo(dcm_obj);
        if isfield(info_struct, 'Position')
          StartOfCurve = info_struct.Position;
          hold on
          subplot(3,4,[2:4,6:8,10:12]), plot(StartOfCurve(1),StartOfCurve(2),'ko');
        end
        ID = find(FilteredData(:,1) == StartOfCurve(1));
        if FilteredData(ID,4) == StartOfCurve(2)
            FilteredData2 = [FilteredData(:,1), FilteredData(:,2), FilteredData(:,3), FilteredData(:,4)];
            FilteredData2(:,5) = 1;
        else
            FilteredData2 = [FilteredData(:,1), FilteredData(:,5), FilteredData(:,6), FilteredData(:,7)];
            FilteredData2(:,5) = 2;
        end

        close all

        %% Cut out the curve of interest
        % Here you will isolate the curve(s) of interest, keeping fore-hind
        % pairs together. Click close to the start and end of the curve
        % (doesn't have to be exact).
        
        fig = figure('units','normalized','outerposition',[0 0 0.5 0.75]);
        hold on
        subplot(3,4,[2:4,6:8,10:12]), plot(FilteredData2(:,1), FilteredData2(:,4),'Color',[0,0.7,0.9]);
        title('Vertical Force-Time Curve');
        xlabel('Time');
        ylabel('Vertical Force (in Voltage)');
        t1 = subplot(3,4,1, 'replace');
        fixfont = text(0,0,sprintf('Please click \nat the START \nof the force-time curve \nthat you want to isolate. \n \nKeep fore-hind pairs \ntogether. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 14;
        % Enable data cursor mode
        datacursormode on
        dcm_obj = datacursormode(fig);
        % Set update function
        set(dcm_obj);
        % Wait while the user to click
        pause 
        % Export cursor to workspace
        info_struct = getCursorInfo(dcm_obj);
        if isfield(info_struct, 'Position')
          StartOfCurve = info_struct.Position;
          hold on
          subplot(3,4,[2:4,6:8,10:12]), plot(StartOfCurve(1),StartOfCurve(2),'ko');
        end

        t1 = subplot(3,4,5, 'replace');
        fixfont = text(0,0,sprintf('Please click \nat the END \nof the force-time curve \nthat you want to isolate. \n \nKeep fore-hind pairs \ntogether. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 14;
        % Enable data cursor mode
        datacursormode on
        dcm_obj = datacursormode(fig);
        % Set update function
        set(dcm_obj);
        % Wait while the user to click
        pause 
        % Export cursor to workspace
        info_struct = getCursorInfo(dcm_obj);
        if isfield(info_struct, 'Position')
          EndOfCurve = info_struct.Position;
          hold on
          subplot(3,4,[2:4,6:8,10:12]), plot(EndOfCurve(1),EndOfCurve(2),'ko');
        end
        ID_Start = find(FilteredData2(:,1) == StartOfCurve(1));
        ID_End = find(FilteredData2(:,1) == EndOfCurve(1));

        % Cut the data based upon the User Inputs
        if (StartOfCurve(1)-100) > 0
            if (EndOfCurve(1)+100) < length(FilteredData2(:,1))
                CutData = FilteredData2(ID_Start-100:ID_End+100,:);
            else
                CutData = FilteredData2(ID_Start-100:ID_End,:);
            end
        else
            CutData = FilteredData2(1:ID_End+100,:);
        end

        close all
        clear StartOfCurve EndOfCurve

        %% Cut out and Zero the Z Curve
        % Here you will select the start and end of the curve. The curve
        % will be zeroed based on these two points, so they should be
        % roughly the same voltage. 
        
        fig = figure('units','normalized','outerposition',[0 0 0.5 0.75]);
        hold on
        subplot(3,4,[2:4,6:8,10:12]), plot(CutData(:,1), CutData(:,4), 'Color',[0,0.7,0.9]);
        title('Verticl Force-Time Curves');
        xlabel('Time');
        ylabel('Vertical Force (in Voltage)');
        t1 = subplot(3,4,1, 'replace');
        fixfont = text(0,0,sprintf('Please click \nat the START \nof the force-time curve \nthat you want to isolate. \n \nKeep fore-hind pairs \ntogether. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 14;
        % Enable data cursor mode
        datacursormode on
        dcm_obj = datacursormode(fig);
        % Set update function
        set(dcm_obj);
        % Wait while the user to click
        pause 
        % Export cursor to workspace
        info_struct = getCursorInfo(dcm_obj);
        if isfield(info_struct, 'Position')
          StartOfCurve = info_struct.Position;
          hold on
          subplot(3,4,[2:4,6:8,10:12]), plot(StartOfCurve(1),StartOfCurve(2),'ko');
        end

        t1 = subplot(3,4,5, 'replace');
        fixfont = text(0,0,sprintf('Please click \nat the END \nof the force-time curve \nthat you want to isolate. \n \nKeep fore-hind pairs \ntogether. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 14;
        % Enable data cursor mode
        datacursormode on
        dcm_obj = datacursormode(fig);
        % Set update function
        set(dcm_obj);
        % Wait while the user to click
        pause 
        % Export cursor to workspace
        info_struct = getCursorInfo(dcm_obj);
        if isfield(info_struct, 'Position')
          EndOfCurve = info_struct.Position;
          hold on
          subplot(3,4,[2:4,6:8,10:12]), plot(EndOfCurve(1),EndOfCurve(2),'ko');
        end
        ID_Start = find(CutData(:,1) == StartOfCurve(1));
        ID_End = find(CutData(:,1) == EndOfCurve(1));
        
        % Cut the data based upon the User Inputs
        CutData2 = CutData(ID_Start:ID_End,:);
        Z_Zero = (CutData2(1,4) + CutData2(length(CutData2(:,1)),4)) / 2;
        Y_Zero = (CutData2(1,3) + CutData2(length(CutData2(:,1)),3)) / 2;
        X_Zero = (CutData2(1,2) + CutData2(length(CutData2(:,1)),2)) / 2;

        Data_CutANDZeroed = [CutData2(:,1), CutData2(:,2)-X_Zero, CutData2(:,3)-Y_Zero, CutData2(:,4)-Z_Zero, CutData2(:,5)];  

        close all
        
        %% Break fore-hind pairs
        % Here you will separate fore and hind paw from fore-hind pairs, or
        % isolate single hind paws. 
        
        fig = figure('units','normalized','outerposition',[0 0 0.5 0.75]);
        hold on
        subplot(3,4,[2:4,6:8,10:12]), plot(Data_CutANDZeroed(:,1), Data_CutANDZeroed(:,4), 'Color',[0,0.7,0.9]);
        title('Verticl Force-Time Curves');
        xlabel('Time');
        ylabel('Vertical Force (in Voltage)');
        t1 = subplot(3,4,1, 'replace');
        fixfont = text(0,0,sprintf('Please click \nat the BREAK \nof the fore-hind pair. \nIf there is no fore-hind \npair, click at the START \nof the curve. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 14;
        % Enable data cursor mode
        datacursormode on
        dcm_obj = datacursormode(fig);
        % Set update function
        set(dcm_obj);
        % Wait while the user to click
        pause 
        % Export cursor to workspace
        info_struct = getCursorInfo(dcm_obj);
        if isfield(info_struct, 'Position')
          BreakInCurve = info_struct.Position;
          hold on
          subplot(3,4,[2:4,6:8,10:12]), plot(StartOfCurve(1),StartOfCurve(2),'ko');
        end
        ID_Break = find(Data_CutANDZeroed(:,1) == BreakInCurve(1));

        close all
        
        %% Shows final step with all forces and identify foot and force plate
        % Here you will see the final step with all force curves (including
        % X, Y, and Z). Finally, you will identify the foot and force plate
        % for each step. 
        
        % Hind Paw Only
        if (ID_Break < 25)
            % Flips ML (Y) and BP (X) curves if necessary based on first 1/5 of trial
            % ML curve should start positive while BP curve should start negative
            XFlipper = mean(Data_CutANDZeroed(1:floor(length(Data_CutANDZeroed(:,1))*.2),2));
            if XFlipper > 0
                Data_CutANDZeroed(:,2) = -1*Data_CutANDZeroed(:,2);
            end
            YFlipper = mean(Data_CutANDZeroed(1:floor(length(Data_CutANDZeroed(:,1))),3));
            if YFlipper < 0
                Data_CutANDZeroed(:,3) = -1*Data_CutANDZeroed(:,3);
            end

            % Cut out and Zero the Z Curve
            fig = figure('units','normalized','outerposition',[0 0 0.5 0.75]);
            hold on
            subplot(3,4,[2:4,6:8,10:12]), plot(Data_CutANDZeroed(:,1), Data_CutANDZeroed(:,4), Data_CutANDZeroed(:,1), Data_CutANDZeroed(:,3), Data_CutANDZeroed(:,1), Data_CutANDZeroed(:,2), 'Color',[0,0.7,0.9]);
            t1 = subplot(3,4,5, 'replace');
            fixfont = text(0,0,sprintf(['Here is your cut curve. \nIt will be saved as \n ',[name,'_HindLimbFC',int2str(counter)],'.']), 'Parent', t1); axis off
            fixfont.FontSize = 14;

            % Select Right or Left foot strike
            prompt = {'Right or Left?'};
            dlg_title = 'Foot?';
            num_lines = 1;
            defaultans = {'R'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            FootID = answer{1};

            % Select force plate (A or C; B or D)
            prompt = {'A, B, C, D?'};
            dlg_title = 'Force Plate?';
            num_lines = 1;
            defaultans = {'A'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            ForePlateID = answer{1};
            
            CurveName = [name,'_HindLimbFC',int2str(counter),'.mat'];
            data = Data_CutANDZeroed;
            if (FootID == 'R') || (FootID == 'r') 
                data(:,6) = 1;
            else
                data(:,6) = 0;
            end
            
            if (ForePlateID == 'A') || (ForePlateID == 'a') 
                data(:,7) = 1;
            elseif (ForePlateID == 'B') || (ForePlateID == 'b')
                data(:,7) = 2;
            elseif (ForePlateID == 'C') || (ForePlateID == 'c')
                data(:,7) = 3;
            else
                data(:,7) = 4;
            end
            save(CurveName,'data');
            
            clear data
            counter = counter + 1;

            clear Data_CuteANDZeroed    
        
        % Fore-Hind Paw Pair
        else
            ForeLimbData = Data_CutANDZeroed(1:ID_Break,:);
            HindLimbData = Data_CutANDZeroed(ID_Break:length(Data_CutANDZeroed(:,1)),:);
            
            XFlipper = mean(ForeLimbData(1:floor(length(ForeLimbData(:,1))*.2),2));
            if XFlipper < 0
                ForeLimbData(:,2) = -1*ForeLimbData(:,2);
            end
            YFlipper = mean(ForeLimbData(1:floor(length(ForeLimbData(:,1))),3));
            if YFlipper < 0
                ForeLimbData(:,3) = -1*ForeLimbData(:,3);
            end
            
            XFlipper = mean(HindLimbData(1:floor(length(HindLimbData(:,1))*.2),2));
            if XFlipper < 0
                HindLimbData(:,2) = -1*HindLimbData(:,2);
            end
            YFlipper = mean(HindLimbData(1:floor(length(HindLimbData(:,1))),3));
            if YFlipper < 0
                HindLimbData(:,3) = -1*HindLimbData(:,3);
            end
            
            % Cut out and Zero the Z Curve
            fig = figure('units','normalized','outerposition',[0 0 0.5 0.75]);
            hold on
            subplot(3,4,[2:4,6:8,10:12]), plot(ForeLimbData(:,1), ForeLimbData(:,4), ForeLimbData(:,1), ForeLimbData(:,3), ForeLimbData(:,1), ForeLimbData(:,2), HindLimbData(:,1), HindLimbData(:,4), HindLimbData(:,1), HindLimbData(:,3), HindLimbData(:,1), HindLimbData(:,2));
            t1 = subplot(3,4,5, 'replace');
            fixfont = text(0,0,sprintf(['Here is your cut curve. \nIt will be saved as \n',[name,'_ForeLimbFC',int2str(counter)],'\nand \n',[name,'_HindLimbFC',int2str(counter)],'.']), 'Parent', t1, 'Interpreter', 'none'); axis off
            fixfont.FontSize = 14;
            
            % Select Right or Left Foot Strike
            prompt = {'Right or Left?'};
            dlg_title = 'Foot?';
            num_lines = 1;
            defaultans = {'R'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            FootID = answer{1};
            
            % Select force plate (A or C; B or D)
            prompt = {'A, B, C, D?'};
            dlg_title = 'Force Plate?';
            num_lines = 1;
            defaultans = {'A'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            ForcePlateID = answer{1};
            
            % Save hind paw data
            CurveName = [name,'_HindLimbFC',int2str(counter),'.mat'];
            data = HindLimbData;
            if (FootID == 'R') || (FootID == 'r') 
                data(:,6) = 1;
            else
                data(:,6) = 0;
            end
            
            if (ForcePlateID == 'A') || (ForcePlateID == 'a')
                data(:,7) = 1;
            elseif (ForcePlateID == 'B') || (ForcePlateID == 'b')
                data(:,7) = 2;
            elseif (ForcePlateID == 'C') || (ForcePlateID == 'c')
                data(:,7) = 3;
            else
                data(:,7) = 4;
            end
            save(CurveName,'data');
            clear data
            
            % Save fore paw data
            CurveName = [name,'_ForeLimbFC',int2str(counter),'.mat'];
            data = ForeLimbData;
            if (FootID == 'R') || (FootID == 'r') 
                data(:,6) = 1;
            else
                data(:,6) = 0;
            end

            if (ForcePlateID == 'A') || (ForcePlateID == 'a') 
                data(:,7) = 1;
            elseif (ForcePlateID == 'B') || (ForcePlateID == 'b')
                data(:,7) = 2;
            elseif (ForcePlateID == 'C') || (ForcePlateID == 'c')
                data(:,7) = 3;
            else
                data(:,7) = 4;
            end
            save(CurveName,'data');
            clear data
            counter = counter + 1;

            clear Data_CuteANDZeroed
        end
        
        % Requests user set a summary file name. -BYMJ
        prompt = {'Additional Foot Stikes in This File?'};
        dlg_title = 'Summary title';
        num_lines = 1;
        defaultans = {'y'};
        answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
        q = answer{1};
        
        close all
    end
        
end