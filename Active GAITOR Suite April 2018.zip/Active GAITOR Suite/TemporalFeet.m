%% TemporalFeet - March 27, 2017 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Brittany Y. Jacobs
% Last Updated: March 30, 2017 by EHL

% NOTES:
% This script is used to manually identify left versus right feet for
% "temporal only" versions of AGATHA 2.0. The script is intended to be run
% after the FSTO images have been through "Edit Mode".  This script will
% show the frame where the first fore- and hind-paws are in contact with 
% the floor (column 8 from AGATHAData = y (frame) location for the centroid
% of the FSTO object. 
% This script was originally written for the 2016 Taxol experiment, but can
% be modified for other data sets in which the spatial component of AGATHA 
% 2.0 could not be run.

%% Load File(s) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Select directory.
Directory = uigetdir;

% Select desired file(s) for batch.
File = uipickfiles('FilterSpec',Directory,'Type',{'*.avi' '.avi'});

% Sets up counter for running the batch.
FileCount = 1;
Finish = length(File);

while FileCount <= Finish
try
    % VideoName - pull each video from File and use VideoReader.
    VideoName = File{FileCount};
    Video = VideoReader(VideoName);
    
    % Break up filename into path, name, and extension. TrialIDName will be
    % used to find the associated AGATHA data file.
    [~,TrialIDName,~] = fileparts(VideoName); 
    TrialIDName(TrialIDName == '.' ) = [];
    
    % Find and load the data file associated with the current trial.
    DataTrialIDName = strcat(TrialIDName,'_DATA');
    load(DataTrialIDName,'-mat');
    AGATHAData = DATA.AGATHA;
    VelocityData = DATA.Velocity;
    
%% Determine frame of first step %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Sort objects in AGATHAData Temporally.
    [~, order] = sort(AGATHAData(:,4)); 
    AGATHADataSort = zeros(size(AGATHAData));
    for ii = 1:size(AGATHADataSort,1)
        AGATHADataSort(ii,:) = AGATHAData(order(ii),:);
    end
    
    % Look at (temporally) first fore (1) paw object and ID frame.
    FindFore = AGATHADataSort((find(AGATHADataSort(:,2) == 1, 1, 'first')), 8);
    
    % Look at (temporally) first hind (0) paw object and ID frame.
    FindHind = AGATHADataSort((find(AGATHADataSort(:,2) == 0, 1, 'first')), 8);
    
%% Load frames and ID L/R %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Load frame of first fore paw object & enter L/R.
    FindFore = floor(FindFore)/Video.FrameRate;
    Video.CurrentTime = FindFore;
    FrameFore = readFrame(Video);
    
    imshow(FrameFore);
    
    Prompt = {'Enter fore paw in contact with the floor (L/R)'};
    Title = 'Fore Paw L/R';
    Lines = 1;
    AnswerFore = inputdlg(Prompt,Title,Lines);
    
    close all
    
    % Load frame of first hind paw object & enter L/R.
    FindHind = floor(FindHind)/Video.FrameRate;
    Video.CurrentTime = FindHind;
    FrameHind = readFrame(Video);
    
    imshow(FrameHind);
    
    Prompt = {'Enter hind paw in contact with the floor (L/R)'};
    Title = 'Hind Paw L/R';
    Lines = 1;
    AnswerHind = inputdlg(Prompt,Title,Lines);
    
    close all
    
%% Set all subsequent objects to correct foot (L/R) %%%%%%%%%%%%%%%%%%%%%%%
    
    % Move data from column(s) 9+ down one; AGATHAData generally has foot IDs
    % coded into column 9.
    % Note: If you have spatial data in AGATHAData (columns 9-16), then the
    % following 2 lines should be replaced with:
    % AGATHADataSort(:,10:17) = AGATHADataSort(:,9:16);
    % AGATHADataSort(:,9) = NaN(size(AGATHADataSort,1),1);
    AGATHADataSort(:,10) = AGATHADataSort(:,9);
    AGATHADataSort(:,9) = NaN(size(AGATHADataSort,1),1); 
    
    % Set all fore paw object foot IDs to L/R (1/0).
    ForeIndex = find(AGATHADataSort(:,2) == 1);     
    AnswerFore1 = strcmp(AnswerFore{1},'L');
    AnswerFore2 = strcmp(AnswerFore{1},'l');
    if AnswerFore1 == 1 || AnswerFore2 == 1
        for i = 1:2:length(ForeIndex)
            AGATHADataSort(ForeIndex(i),9) = 1;
        end
        for i = 2:2:length(ForeIndex)
            AGATHADataSort(ForeIndex(i),9) = 0;
        end
    else
        for i = 1:2:length(ForeIndex)
            AGATHADataSort(ForeIndex(i),9) = 0;
        end
        for i = 2:2:length(ForeIndex)
            AGATHADataSort(ForeIndex(i),9) = 1;
        end
    end
    
    % Set all hind paw object foot IDs to L/R (1/0).
    HindIndex = find(AGATHADataSort(:,2) == 0);     
    AnswerHind1 = strcmp(AnswerHind{1},'L');
    AnswerHind2 = strcmp(AnswerHind{1},'l');
    if AnswerHind1 == 1 || AnswerHind2 == 1
        for i = 1:2:length(HindIndex)
            AGATHADataSort(HindIndex(i),9) = 1;
        end
        for i = 2:2:length(HindIndex)
            AGATHADataSort(HindIndex(i),9) = 0;
        end
    else
        for i = 1:2:length(HindIndex)
            AGATHADataSort(HindIndex(i),9) = 0;
        end
        for i = 2:2:length(HindIndex)
            AGATHADataSort(HindIndex(i),9) = 1;
        end
    end
    
%% Save data and prep next file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Re-create DATA with corrected AGATHAData & save.
    DATA = struct('AGATHA',AGATHADataSort,'Velocity',VelocityData);
    Filename_DATA = [TrialIDName, '_DATA_LR.mat'];
    save(Filename_DATA, 'DATA');

    % Don't try and look at file{2} if you only chose 1 file to begin with.
    if length(File) == 1
        break
    end

    % Clear variables for next trial.
    clearvars -except  File FileCount Finish

% Set filecount to address next file in batch.
FileCount = FileCount + 1;

catch
    % If an error occurs, print to the command window and move on to the
    % next video. 
    if exist('TrialIDName','var')
        disp(['Error in ' TrialIDName]);
    else
        disp('Error: Unable to Identify TrialIDName.')
    end
    FileCount = FileCount + 1;
end
   
end