

[file,path] = uigetfile('*.tdms','Find the Files to Import','MultiSelect', 'on');

% This is needed for the multiselect.  Always put the file in this format.
file = cellstr(file); 

% START loop for each trial/file you clicked above.
for n=1:length(file)
    filename = fullfile ( path, file{n} );

    if exist([filename(1:end-5) '.mat'],'file') 
        matFile{1} = [filename(1:end-5) '.mat'];
    else
        % Convert function is from MathWorks. EHL made no edits to it.  It converts
        % the .tdms file from Labview directly into a .mat file for MatLab. This 
        % removes the step of converting files to excel before importing them 
        % into Matlab. 
        matFile = simpleConvertTDMS(filename,1); 
    end
end