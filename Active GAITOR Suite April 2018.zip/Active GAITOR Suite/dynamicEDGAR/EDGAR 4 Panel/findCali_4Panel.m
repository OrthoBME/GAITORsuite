function [calibration] = findCali_4Panel(date,panel)

% Find the date, and define the calibration constants based on the date.
% Specific to EHL's data. Definitely a clunky hard code - but it saved time
% for EHL processing the data.
% cal_X, cal_Y, and cal_Z = slope of calibration curve in uC/g
% cal_Xint, cal_Yint, and cal_Zint = y-intercepts of the calibration curve
% in uC.

date = num2str(date);
panel = panel.panel;

comp = [];
% strcmp compares 2 strings.  1 = they are the same, 0 = not the same.
comp(1) = strcmp(date,'20161010');  % Week 4
comp(2) = strcmp(date,'20161011');
comp(3) = strcmp(date,'20161012');
comp(4) = strcmp(date,'20161013');
comp(5) = strcmp(date,'20161014');
comp(6) = strcmp(date,'20161024');  % Week 6
comp(7) = strcmp(date,'20161025');
comp(8) = strcmp(date,'20161026');
comp(9) = strcmp(date,'20161027');
comp(10) = strcmp(date,'20161028');
comp(11) = strcmp(date,'20161114');  % Week 9
comp(12) = strcmp(date,'20161115');
comp(13) = strcmp(date,'20161116');
comp(14) = strcmp(date,'20161117');
comp(15) = strcmp(date,'20161118');

loc = find(comp == 1);  % find where the dates matched -- look for the location of the 1.

%% BYMJ 1/6/17: Set up dates and calibrations for WEEK 4 of exercise study

if loc == 1
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
    
elseif loc == 2
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
    
elseif loc == 3
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
    
elseif loc == 4
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
            
elseif loc == 5
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
end

%% BYMJ 1/6/17: Set up dates and calibrations for WEEK 6 of exercise study

%%% THESE ARE CURRENTLY WEEK 4 VALUES.

if loc == 6
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
    
elseif loc == 7
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
    
elseif loc == 8
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
    
elseif loc == 9
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
            
elseif loc == 10
    if panel == 'A' || panel == 'a'
        cal_X = 0.0023;        cal_Y = 0.0082;        cal_Z = 0.0045;
        cal_Xint = 0.0229;     cal_Yint = 0.1088;     cal_Zint = -0.0152;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    else
        cal_X = 0.0119;        cal_Y = 0.0099;        cal_Z = 0.0035;
        cal_Xint = 0.2776;     cal_Yint = -0.2469;    cal_Zint = 0.0382;
    end
end

%%  BYMJ 6/2/17: Set up dates and calibrations for WEEK 9 of exercise study

if loc == 11
    if panel == 'A' || panel == 'a'
        cal_X = 0.009;        cal_Y = 0.004;        cal_Z = 0.005;
        cal_Xint = 0.132;     cal_Yint = -.073;     cal_Zint = -0.01;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.022;        cal_Y = 0.0099;        cal_Z = 0.004;
        cal_Xint = 0.295;     cal_Yint = -0.2469;    cal_Zint = 0.004;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.009;        cal_Y = 0.009;        cal_Z = 0.005;
        cal_Xint = 0.087;     cal_Yint = 0.033;    cal_Zint = -0.01;
    else
        cal_X = 0.022;        cal_Y = 0.008;        cal_Z = 0.004;
        cal_Xint = 0.261;     cal_Yint = -0.014;    cal_Zint = 0.004;
    end
    
elseif loc == 12 %Calibration data from 20161114
    if panel == 'A' || panel == 'a'
        cal_X = 0.009;        cal_Y = 0.004;        cal_Z = 0.005;
        cal_Xint = 0.132;     cal_Yint = -.073;     cal_Zint = -0.01;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.022;        cal_Y = 0.0099;        cal_Z = 0.004;
        cal_Xint = 0.295;     cal_Yint = -0.2469;    cal_Zint = 0.004;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.009;        cal_Y = 0.009;        cal_Z = 0.005;
        cal_Xint = 0.087;     cal_Yint = 0.033;    cal_Zint = -0.01;
    else
        cal_X = 0.022;        cal_Y = 0.008;        cal_Z = 0.004;
        cal_Xint = 0.261;     cal_Yint = -0.014;    cal_Zint = 0.004;
    end
    
elseif loc == 13
    if panel == 'A' || panel == 'a'
        cal_X = 0.009;        cal_Y = 0.003;        cal_Z = 0.004;
        cal_Xint = 0.284;     cal_Yint = -0.031;     cal_Zint = 0.027;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.023;        cal_Y = 0.0099;        cal_Z = 0.004;
        cal_Xint = 0.396;     cal_Yint = -0.2469;    cal_Zint = 0.008;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.009;        cal_Y = 0.009;        cal_Z = 0.004;
        cal_Xint = 0.252;     cal_Yint = -0.021;    cal_Zint = 0.027;
    else
        cal_X = 0.022;        cal_Y = 0.008;        cal_Z = 0.004;
        cal_Xint = 0.528;     cal_Yint = 0.078;    cal_Zint = 0.008;
    end
    
elseif loc == 14
    if panel == 'A' || panel == 'a'
        cal_X = 0.009;        cal_Y = 0.004;        cal_Z = 0.004;
        cal_Xint = 0.123;     cal_Yint = -0.092;     cal_Zint = 0.021;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.023;        cal_Y = 0.0099;        cal_Z = 0.004;
        cal_Xint = 0.234;     cal_Yint = -0.2469;    cal_Zint = 0.011;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.009;        cal_Y = 0.009;        cal_Z = 0.004;
        cal_Xint = 0.109;     cal_Yint = 0.092;    cal_Zint = -0.038;
    else
        cal_X = 0.022;        cal_Y = 0.008;        cal_Z = 0.004;
        cal_Xint = 0.263;     cal_Yint = 0.0455;    cal_Zint = -0.01;
    end
            
elseif loc == 15
    if panel == 'A' || panel == 'a'
        cal_X = 0.01;        cal_Y = 0.004;        cal_Z = 0.004;
        cal_Xint = 0.254;     cal_Yint = -0.092;     cal_Zint = 0.011;
    elseif panel == 'B' || panel == 'b'
        cal_X = 0.0226;        cal_Y = 0.0099;        cal_Z = 0.004;
        cal_Xint = 0.5916;     cal_Yint = -0.2469;    cal_Zint = -0.0126;
    elseif panel == 'C' || panel == 'c'
        cal_X = 0.0096;        cal_Y = 0.0086;        cal_Z = 0.01;
        cal_Xint = 0.221;     cal_Yint = 0.121;    cal_Zint = -0.09;
    else
        cal_X = 0.021;        cal_Y = 0.008;        cal_Z = 0.004;
        cal_Xint = 0.609;     cal_Yint = 0.069;    cal_Zint = -0.0126;
    end
end

%% Save structure %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Put all variables into a structure
calibration = struct('CalX',cal_X,'CalY',cal_Y,'CalZ',...
    cal_Z,'CalXIntercept',cal_Xint,'CalYIntercept',cal_Yint,...
    'CalZIntercept',cal_Zint);

% Cali_Filename = ['Cali_',date,'_',panel,'.mat'];
% save(Cali_Filename, 'calibration');