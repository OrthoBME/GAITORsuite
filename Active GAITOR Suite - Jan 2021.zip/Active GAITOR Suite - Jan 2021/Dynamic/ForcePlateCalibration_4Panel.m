% Force Plate Calibration_Exercise.m 
% Emily Lakes
% Last Modification:  October 11, 2016
%
% Get the calibration constants for the 4 panel system. MiRa's exercise
% study.

clc; clear all;
home;
close all

% Choose .tdms files, pull info from file name, and convert to .mat
[file,path] = uigetfile('*tdms','Click the files you want to calibrate.','MultiSelect', 'on');
holdpath = path; % Saving actual path info to hand back to code later

for p = 1:length(file)
[path,name,extension] = fileparts(file{p});  % Break up filename into path, name, and extension.
path = holdpath; % Fill path with actual path info again
nameparts = regexp(name, '_','split');  % Break up the name into it's components (assumes name is separated by underscore)
cw = nameparts{6};
direction = nameparts{5};
panel = nameparts{4};

fileconvert = simpleConvertTDMS([path,name,'.tdms'],1);  % this function is from MathWorks.  I made no edits to it.  It converts the .tdms file from Labview directly into a .mat file for MatLab. This removes the step of converting files ot excel and then importing them into Matlab. 
load([path,name,'.mat']);

% X & Y here are using Allen Lab convention, where x is bp and y is ml.
% This is the OPPOSITE of kistler readouts.
% Pull out variables from the structure.
BD_Y = Untitled.Data;  BD_Y = BD_Y(BD_Y~=0);
BD_X = Untitled1.Data; BD_X = BD_X(BD_X~=0);
BD_Z = Untitled2.Data; BD_Z = BD_Z(BD_Z~=0);
AC_Y = Untitled3.Data; AC_Y = AC_Y(AC_Y~=0);
AC_X = Untitled4.Data; AC_X = AC_X(AC_X~=0);
AC_Z = Untitled5.Data; AC_Z = AC_Z(AC_Z~=0);
time = Time.Data(1:length(AC_Z));

% If you want to have a general look at you data before plotting, then
% uncomment the following 4 lines:
% plot(time, [AC_Z, AC_X, AC_Y, BD_Z, BD_X, BD_Y]);
% set(gcf,'color','w');
% legend('AC_Z', 'AC_X', 'AC_Y', 'BD_Z', 'BD_X', 'BD_Y')
% uiwait(msgbox({'Make sure your plots make sense, then click ok.'}));

% Plot the relevant axis and have the user click the left baseline, 
% plateau, and right baseline. This will give the voltage difference.  
% Then, calculate the calibration constant for the desired direction. 
if direction == 'bp'
    direction = 'BP';
end
if direction == 'BP'
    a = strfind(panel,'A');
    c = strfind(panel,'C');
    if isempty(a) == 0 || isempty(c) == 0
    plot(time,AC_X);
    xlabel('Time (s)')
    ylabel('Volts')
    title('AC_X')
    set(gcf,'color','w');
    [leftX leftY] = ginput(1);  
    leftXloc = find(time > leftX);
    leftVolt = AC_X(leftXloc(1));
    [plateauX plateauY] = ginput(1);
    plateauXloc = find(time > plateauX);
    plateauVolt = AC_X(plateauXloc(1));
    [rightX rightY] = ginput(1); 
    rightXloc = find(time > rightX);
    rightVolt = AC_X(rightXloc(1));
    baselineAvg = (leftVolt + rightVolt)/2;
    Vdiff_AC_X = abs(plateauVolt - baselineAvg);
    close all
    fprintf((['\n',name,' g = ' num2str(Vdiff_AC_X) 'V \n']))
    end
    
    b = strfind(panel,'B');
    d = strfind(panel,'D');
    if isempty(b) == 0 || isempty(d) == 0
    plot(time,BD_X);
    xlabel('Time (s)')
    ylabel('Volts')
    title('BD_X')
    set(gcf,'color','w');
    [leftX leftY] = ginput(1); 
    leftXloc = find(time > leftX);
    leftVolt = BD_X(leftXloc(1));
    [plateauX plateauY] = ginput(1); 
    plateauXloc = find(time > plateauX);
    plateauVolt = BD_X(plateauXloc(1));
    [rightX rightY] = ginput(1);  
    rightXloc = find(time > rightX);
    rightVolt = BD_X(rightXloc(1));
    baselineAvg = (leftVolt + rightVolt)/2;
    Vdiff_BD_X = abs(plateauVolt - baselineAvg);
    close all
    fprintf((['\n',name,' g = ' num2str(Vdiff_BD_X) 'V \n']))
    end
end
if direction == 'ml'
    direction = 'ML';
end
if direction == 'ML'
    a = strfind(panel,'A');
    c = strfind(panel,'C');
    if isempty(a) == 0 || isempty(c) == 0
    plot(time,AC_Y);
    xlabel('Time (s)')
    ylabel('Volts')
    title('AC_Y')
    set(gcf,'color','w');
    [leftX leftY] = ginput(1);  
    leftXloc = find(time > leftX);
    leftVolt = AC_Y(leftXloc(1));
    [plateauX plateauY] = ginput(1);
    plateauXloc = find(time > plateauX);
    plateauVolt = AC_Y(plateauXloc(1));
    [rightX rightY] = ginput(1);  
    rightXloc = find(time > rightX);
    rightVolt = AC_Y(rightXloc(1));
    baselineAvg = (leftVolt + rightVolt)/2;
    Vdiff_AC_Y = abs(plateauVolt - baselineAvg);
    close all
    fprintf((['\n',name,' g = ' num2str(Vdiff_AC_Y) 'V \n']))
    end 

    b = strfind(panel,'B');
    d = strfind(panel,'D');
    if isempty(b) == 0 || isempty(d) == 0
    plot(time,BD_Y);
    xlabel('Time (s)')
    ylabel('Volts')
    title('BD_Y')
    set(gcf,'color','w');
    [leftX leftY] = ginput(1);  
    leftXloc = find(time > leftX);
    leftVolt = BD_Y(leftXloc(1));
    [plateauX plateauY] = ginput(1);
    plateauXloc = find(time > plateauX);
    plateauVolt = BD_Y(plateauXloc(1));
    [rightX rightY] = ginput(1);
    rightXloc = find(time > rightX);
    rightVolt = BD_Y(rightXloc(1));
    baselineAvg = (leftVolt + rightVolt)/2;
    Vdiff_BD_Y = abs(plateauVolt - baselineAvg);
    close all
    fprintf((['\n',name,' g = ' num2str(Vdiff_BD_Y) 'V \n']))
    end
end
if direction == 'z'
    direction = 'Z';
end
if direction == 'Z' 
    a = strfind(panel,'A');
    c = strfind(panel,'C');
    if isempty(a) == 0 || isempty(c) == 0
    plot(time,AC_Z);
    xlabel('Time (s)')
    ylabel('Volts')
    title('AC_Z')
    set(gcf,'color','w');
    [leftX leftY] = ginput(1);  
    leftXloc = find(time > leftX);
    leftVolt = AC_Z(leftXloc(1));
    [plateauX plateauY] = ginput(1); 
    plateauXloc = find(time > plateauX);
    plateauVolt = AC_Z(plateauXloc(1));
    [rightX rightY] = ginput(1);  
    rightXloc = find(time > rightX);
    rightVolt = AC_Z(rightXloc(1));
    baselineAvg = (leftVolt + rightVolt)/2;
    Vdiff_AC_Z = abs(plateauVolt - baselineAvg);
    close all
    fprintf((['\n',name,' g = ' num2str(Vdiff_AC_Z) 'V \n']))
    end
    
    b = strfind(panel,'B');
    d = strfind(panel,'D');
    if isempty(b) == 0 || isempty(d) == 0
    plot(time,BD_Z);
    xlabel('Time (s)')
    ylabel('Volts')
    title('BD_Z')
    set(gcf,'color','w');
    [leftX leftY] = ginput(1);  
    leftXloc = find(time > leftX);
    leftVolt = BD_Z(leftXloc(1));
    [plateauX plateauY] = ginput(1); 
    plateauXloc = find(time > plateauX);
    plateauVolt = BD_Z(plateauXloc(1));
    [rightX rightY] = ginput(1);  
    rightXloc = find(time > rightX);
    rightVolt = BD_Z(rightXloc(1));
    baselineAvg = (leftVolt + rightVolt)/2;
    Vdiff_BD_Z = abs(plateauVolt - baselineAvg);
    close all
    fprintf((['\n',name,' g = ' num2str(Vdiff_BD_Z) 'V \n']))
    end
end
end

