function getforceEDGAR_ForeHindPairs_2Panel(animalnum, name, trial, filename, BW, date, path, batch)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SECTION TO RUN CODE AS SCRIPT INSTEAD OF FUNCTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Uncomment lines 9-17 to run as a script.  Also, comment line 1 and
% % the very last 'end' in this file.
% clearvars
% animalnum = '16';
% trial = '2';
% filename = 'H:\20160418 Data\MIA_20160418_r16_t11.tdms';
% thresh = 0;
% BW = 250;
% date = '20160418';
% name = 'tester';
% path = 'C:\Users\elakes\Desktop';
% batch = 'EHL_Test.xls';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  EDGAR DYNAMIC PROCESSING CODE
%%%%%  Edited from getforce (HEK) by BYMJ 12-12-14 
%%%%%  Edited into getforceEDGAR_EHL 9-2016 for multi-component set-up
%%%%%  Last Edited: 11/29/16 EHL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% USER INPUTS
% animalnum = Desired Animal ID  (e.g. '1')
% name = Name of the trial
% trial = Trial number (e.g. '1') 
% file = Complete file location path
% thresh = Step threshold (default = 0)
% BW = Body weight of animal in grams
% date = Date of trial (e.g. '20160314')
% path = Complete file location path

% NOTES                   % EHL's DATA CHANNELS:
% 1 = LEFT FOOT           % [time Z1 Z2 Z3 Z4 X13 X24 Y12 Y34]
% 0 = RIGHT FOOT

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  READ FILE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Convert the .tdms file from Labview into .mat file & load into workspace.
% IF you want to convert within the code (see dynamicEDGAR), then
% uncomment the following line: 
if exist([filename(1:end-5) '.mat'],'file') 
    matFile{1} = [filename(1:end-5) '.mat'];
else
    % Convert function is from MathWorks. EHL made no edits to it.  It converts
    % the .tdms file from Labview directly into a .mat file for MatLab. This 
    % removes the step of converting files to excel before importing them 
    % into Matlab. 
    matFile = simpleConvertTDMS(filename,1); 
end

fprintf('Loading... %s \n',name);

load(matFile{1});

% Pull out variables from the structure and name them appropriately. Again,
% specific to EHL's data. Edit to match your data and ordering. 
time = Time.Data;
Z1 = (VoltageZ1.Data);
Z2 = (VoltageZ2.Data);
Z3 = (VoltageZ3.Data);
Z4 = (VoltageZ4.Data);

% Now that we have the variables named appropriately, we can clear the
% original names to keep the workspace clean. 
clear Time VoltageZ1 VoltageZ2 VoltageZ3 VoltageZ4 VoltageX13 VoltageX24 VoltageY12 Voltage Y34

% Since Emily's experiment pretriggered, there is a lot of excess data.
% Roughly trim down to the section we want here. Look at total Z to see
% easier. 
Zcheck = Z1+Z2+Z3+Z4;
plot(Zcheck);
disp('Choose LEFT boundary   ')
[minx, ~] = ginput(1); 
minX = floor(minx);
disp('Choose RIGHT boundary   ')
[maxx, ~] = ginput(1);
maxX = floor(maxx);

% Safegaurd for if you click a boundary outside the matrix
% dimensions. -EHL
t = 1:1:length(Zcheck);  
if minX < t(1)
    minX = t(1);
end
if maxX > t(end)
    maxX = t(end);
end

range = minX:maxX;  % Redefine curves with new range. 
Z1 = Z1(range);
Z2 = Z2(range);
Z3 = Z3(range);
Z4 = Z4(range);
time = time(range); 

% Put variables into a matrix called "data".  This is to match the code
% that Brittany/Heidi wrote.
data = [time Z1 Z2 Z3 Z4];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  DRIFT COMPENSATION
%%%%%  This is from Heidi/Brittany code. EHL did not change this portion, 
%%%%%  other than trying to add comments.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find row 'r', column 'c', and depth 'd' dimensions of the matrix 'data'.
[datr, datc, ~] = size(data);

q = 'y';
check = strcmp(q,'y');
while check == 1
    % Normalizing Channels based on a complex curve fit of the baseline data.
    % This is based on the bf.m function, which BYMJ found.
    D(:,1) = data(:,1);
    % Look at the columns in 'Data' matrix, but don't look at "time" in first 
    % column.  i.e. data = [time Z1 Z2 Z3 Z4 X13 X24 Y12 Y34]
    for j = 2:datc  
               
        % Find baseline for each channel.  See the bf.m function code.
        [~,yfit] = bf(data(:,j),25);  
        figure
        hold on
        plot (data(:,j),'r');
        plot (yfit,'b');
        pause

        % Re-zero all data by subtracting baseline from each channel.
        for i = 1:datr
            D(i,j) = (data(i,j)-yfit(i));  % yfit is the baseline curve fit.
        end
    end
    q = input('Do you need to redo the baseline? (Y/N)    ','s');
    check = strcmp(q,'y');  
end
close ALL
clear check q

% Lowpass filter, 25 Hz  (this filter originated from Heidi's code)
for i = 2:datc
    fNorm = 25/(2500/2); % 25 Hz cutoff, fs = 2500 Hz
    [B, A] = butter(4, fNorm, 'low'); 
    D(:,i) = filter(B, A, D(:,i));  
    % Now, the filtered data is in "D". So use D from this point on!
end

% Redefine channels with "D" from above. 
Z1_filtered = D(:,2);       
Z2_filtered = D(:,3);      
Z3_filtered = D(:,4);       
Z4_filtered = D(:,5);

% Clean up workspace.
clear A B  % Don't need these.  Only used for the filter above. 
clear datc datd datr data Data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  FIND STEPS (SPIKES) & SAVE CALIBRATION DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
% EHL can identify where strikes occur based on the total Z 
% force on the plate (instead of individual z's).
% SUM Z Data - to get strikes  
% Sum the corrected/filtered data for Z1, Z2, Z3, & Z4 from above.
warning('off');
Zsum = Z1_filtered + Z2_filtered + Z3_filtered + Z4_filtered;  
[allZstrikes, calibration] = IDspikes_New(Zsum, date);  % See IDspikes2.m code. 

% Separate the "calibration" variable from above.  This will prevent 
% confusion later on. cal_X = calibration constant in X (slope in V/g) and 
% cal_Xint = y-intercept in X (in V).  Again, the calibration function is
% unique to EHL's data - but you can edit this to match your case. 
if calibration ~= 0
    cal_Z = calibration(:,3);            cal_Zint = calibration(:,6);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  ISOLATE EACH FOOT STEP (SPIKE)
%%%%%  This is from Heidi/Brittany code. EHL did not change this portion, 
%%%%%  other than trying to add comments.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Make sure there were spikes selected.  If no spikes, then skip to end.
if allZstrikes(1,1) ~= 0  % allZstrikes is output from IDspikes function above
    [~, c] = size(allZstrikes);   
    %r = # of rows (not used), c = # of columns, which is # of spikes kept
    
    for i = 1:c  % START LOOP for each step we saved for this trial/file.
        step_number = i; % This is for xlswrite1 at the end to avoid 
        % confusion. By the time we get down there, we forget what i was. 
        % We still use i for the index value in this loop. 
        % Define "foot" as left/right instead of 1/0.
        foot_num = allZstrikes(2,i);
        if foot_num == 1
            foot = 'Left';
        else
            foot = 'Right';
        end 
        
        % Distance number is not critical. Just a buffer to take +/- around
        % the spikes to get the whole step. Can change this. 
        distance = 2200;   
        % Take first spike and take +/-distance from the peak of the spike
        range = (allZstrikes(1,i) - distance):(allZstrikes(1,i) + distance);  
        % Only keep positive numbers (if -1000 makes it dip negative).
        range = range(range>0);        
        % Only keep numbers in original range (don't go beyond total
        % length).
        range = range(range<length(D));   
   
        % Sum Z1 Z2 Z3 and Z4, EHL 
        Zcurve = Z1_filtered(range(1):range(end)) + Z2_filtered(range(1):range(end)) + Z3_filtered(range(1):range(end)) + Z4_filtered(range(1):range(end));      
        
        % Re-zero force curves after summing individual components
        Zcurve = Zcurve-Zcurve(1);
        
        % Calibrate force curves so they are in %BW.  
        Zcurve_BW = ((Zcurve - cal_Zint(i))/cal_Z(i)) / BW * 100;
        
        % Turn time vector into seconds (starts as just an index).
        % Divide by 2500 Hz collection frequency to get seconds.
        Time_index = 1:length(Zcurve_BW);
        Time = Time_index/2500*1000;  % change to milliseconds 

        % Plot data - NOW IN %BW & MILLISECONDS
        figure
        hold on
        plot(Time, Zcurve_BW, 'b')
        title ('Step Data')
        % Below changes the position of the plot on your computer monitor.  
        % EHL wanted plots to show up on the second monitor and keep the 
        % Matlab screen clear. You can mess around with your resolution to
        % get them to pop up where you want. 
        set(gcf,'position',[-1100 100 1000 750])  
        % Makes background of the plot white instead of gray. 
        set(gcf,'color','w'); 
      
        disp('Choose LEFT boundary   ')
        [minx, ~] = ginput(1);
        % This is why EHL changed to milliseconds.  
        % Couldn't threshold with values <1.
        minx_index = find(Time > minx);  
        minX = minx_index(1);
        disp('Choose RIGHT boundary   ')
        [maxx, ~] = ginput(1);
        maxx_index = find(Time > maxx);
        maxX = maxx_index(1);

        % Safegaurd for if you click a boundary outside the matrix
        % dimensions. -EHL
        t = 1:1:length(Zcurve_BW);  
        if minX < t(1)
            minX = t(1);
        end
        if maxX > t(end)
            maxX = t(end);
        end

        range = minX:maxX;  % Redefine curves with new range. 
        Zcurve_BW = Zcurve_BW(range);
        Time = Time(range);
        
        % 1/5/16 EHL: rezero at this point based on the last point.  
        % Majority of trials will have the hind foot be the last to touch. 
        % Therefore, rezero by the last point (when no weight on plate anymore). 
        % This helps because in most cases there is a forepaw
        % followed by a hindpaw, creating 2 consecutive peaks, with no dip
        % back down to zero in between.  But, we only care about the second
        % hind foot peak. 
        Zcurve_BW = Zcurve_BW - Zcurve_BW(end);
        Time = Time - Time(1);
        
        close ALL

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  PLOT DATA & FIND PEAKS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Find the maxima of the curve - these should be your forelimb PVF
        % and your hindlimb PVF.  Plot these points on the Z curve for
        % visualization. 
        [ForeHindPeaks,ForeHindLocations] = findpeaks(Zcurve_BW,Time,'MinPeakDistance',100);
        ForeHindLocations = ForeHindLocations';
        figure
        hold on
        plot(Time,Zcurve_BW, 'b')
        for ii = 1:length(ForeHindPeaks)
            plot(ForeHindLocations(ii), ForeHindPeaks(ii),'ko')
            hold on
        end
        
        % Just in case there are peaks you don't want, here you can remove
        % them. 
        PeakNumber = input('Remove Peaks? Type peak # or [# #] or enter for none.   ');
        if isempty(PeakNumber) == 0
            for ii = 1:length(PeakNumber)
                ForeHindPeaks(PeakNumber(ii),:) = 0;
                ForeHindLocations(PeakNumber(ii),:) = 0;
            end
            ForeHindPeaks(ForeHindPeaks == 0) = [];
            ForeHindLocations(ForeHindLocations == 0) = [];
        end
        
        % If there were no peaks, or they were all deleted, don't move forward. 
        if isempty(ForeHindPeaks) == 1
            return
        end
        close all  
        
        % If only one peak, define if fore or hind. Change definition of
        % 'foot' to reflect this. 
        if length(ForeHindPeaks) == 1
            WhichFoot = input('Fore or Hind? (F/H)    ','s');
            if WhichFoot == 'F' || WhichFoot == 'f'
                foot = ['Fore_' foot];
            else
                foot = ['Hind_' foot];
            end
        end
        
        % If you have a fore and hind peak, find the
        % minima between these points to get the "transition" point. 
        if length(ForeHindPeaks) == 2
            TransitionRegion = Zcurve_BW(floor(ForeHindLocations(1)/0.4):floor(ForeHindLocations(2)/0.4));
            TimeRegion = Time(floor(ForeHindLocations(1)/0.4):floor(ForeHindLocations(2)/0.4));
            % To find the minima, take the negative of the curve, and use
            % findpeaks again (like we did above for maxima). 
            [ForeHindTransition,TransitionLocation] = findpeaks(-TransitionRegion,TimeRegion,'SortStr','descend');
        else
            ForeHindTransition = 0;
            TransitionLocation = 0;
        end
        
        % Check for multiple minimum points. 
        if length(ForeHindTransition) > 1
            % Sorted above by descending order - so remove anything after
            % the first one.
            ForeHindTransition = ForeHindTransition(1);
            TransitionLocation = TransitionLocation(1);
        end
        
        % Replot data - Still in %BW & ms           
        figure
        hold on
        plot(Time,Zcurve_BW, 'b')
        % Plot as many points as there are. 
        for ii = 1:length(ForeHindPeaks)
            plot(ForeHindLocations(ii), ForeHindPeaks(ii),'ko')
            hold on
        end
        plot(TransitionLocation(ii),-ForeHindTransition(ii),'k*')
        hold on
        set(gcf,'position',[-1100 100 1000 750])
        set(gcf,'color','w');
        
        qq = input('Do you want to throw out the step? (Y/N) ','s');
        if qq == 'y' || qq == 'Y'
            return
        else
            saveas(gcf,[name '_' num2str(step_number) '.jpg']);
        end
        close ALL

        % Clearly define parameters to be saved later. 
        % If you have 2 peaks, define everything. 
        if length(ForeHindPeaks) == 2
            TransitionTime = TransitionLocation;
            ForePeak = ForeHindPeaks(1);
            ForeTime = ForeHindLocations(1);
            ForeStance = TransitionTime;
            HindPeak = ForeHindPeaks(2);
            HindTime = ForeHindLocations(2);
            HindStance = Time(end) - TransitionTime;
            ForeHindDistance = HindTime - ForeTime;
            TransitionDip = -ForeHindTransition;
            TransitionTime = TransitionLocation;
            Stance = Time(end);
        % If you have one peak, only define for either fore or hind. 
        elseif length(ForeHindPeaks) == 1
            if WhichFoot == 'F' || WhichFoot == 'f'
                ForePeak = ForeHindPeaks(1);
                ForeTime = ForeHindLocations(1);
                ForeStance = Time(end);
                HindPeak = 0;
                HindTime = 0;
                HindStance = 0;
                ForeHindDistance = 0;
                TransitionDip = 0;
                TransitionTime = 0;
                Stance = 0;
            else
                ForePeak = 0;
                ForeTime = 0;
                ForeStance = 0;
                HindPeak = ForeHindPeaks(1);
                HindTime = ForeHindLocations(1);
                HindStance = Time(end);
                ForeHindDistance = 0;
                TransitionDip = 0;
                TransitionTime = 0;  
                Stance = 0;
            end
        end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  IMPULSE CALCULATIONS
%%%%%  EHL and BYMJ changed this on 11/28/16.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% You need to have the force and time calibrated to calculate
        % impulse correctly.  First, sum all the points of the curve. Since
        % each point is a single index of time, the sum of each data point 
        % will be in units of %BW-index
        ZI_sum = sum(Zcurve_BW);  %BW-index        
        
        % Then, convert the time index to seconds. Use the max value of the
        % variable Time. This should be the value of the full time duration
        % of the step.
        ZI = ZI_sum*(1/2500);  % %BW-seconds
        
        % Do same for fore and hind portions. 
        % Don't include the actual "transition" point in fore or hind,
        % because we don't know which way it goes. 
        if length(ForeHindPeaks) == 2
            ForeI_sum = sum(Zcurve_BW(1:TransitionTime-1));
            HindI_sum = sum(Zcurve_BW(TransitionTime+1:end));        
            ForeI = ForeI_sum*(1/2500);
            HindI = HindI_sum*(1/2500);
        elseif length(ForeHindPeaks) == 1
            if WhichFoot == 'F' || WhichFoot == 'f'
                ForeI_sum = sum(Zcurve_BW(1:TransitionTime-1));
                ForeI = ForeI_sum*(1/2500);
                HindI = 0;
                ZI = 0;
            else
                HindI_sum = sum(Zcurve_BW(TransitionTime+1:end));        
                HindI = HindI_sum*(1/2500);
                ForeI = 0;
                ZI = 0;
            end
        end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  WRITE RAW OUTPUT XLS FILE FOR EACH STEP    
%%%%%  Make new raw excel file for each step... EHL is saving ALL data 
%%%%%  vectors, so give each step one huge excel file with all raw data. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    warning('off','MATLAB:xlswrite:AddSheet');

    % EHL took the following lines from the xlswrite1 documentation on
    % MatLab forum.  xlswrite1 significantly speeds up the writing time by
    % not opening/closing excel for each write command.  This is much, much
    % faster. 
    Excel = actxserver('Excel.Application');  % Define the server.
    RawFile = [path '\' name '_' num2str(i) '_RawFile.xls']; % Name the file
    if ~exist(RawFile,'file')  % If the file doesn't exist, create it.
        ExcelWorkbook = Excel.Workbooks.Add; 
        ExcelWorkbook.Sheets.Add; 
        ExcelWorkbook.SaveAs(RawFile,1); 
        ExcelWorkbook.Close(false); 
    end 
    ExcelWorkbook =  Excel.workbooks.Open(RawFile);  % Open Excel

    fprintf('Writing Raw xls File... \n');
     
    % All data vectors for each step. Not normalized or
    % calibrated yet - but it is cropped and filtered for the
    % step. This should be everything you need to
    % recreate/recalculate/replot the data for each step.
    xlswrite1(RawFile,{'File name'},1,'B2');        xlswrite1(RawFile,{name},1,'B3'); 
    xlswrite1(RawFile,{'Animal number'},1,'C2');    xlswrite1(RawFile,{animalnum},1,'C3'); 
    xlswrite1(RawFile,{'Trial number'},1,'D2');     xlswrite1(RawFile,{trial},1,'D3');
    xlswrite1(RawFile,{'Step number (within trial)'},1,'E2');   xlswrite1(RawFile,step_number,1,'E3');
    xlswrite1(RawFile,{'Foot (L = 1, R = 0)'},1,'F2');    xlswrite1(RawFile,foot,1,'F3'); 
    xlswrite1(RawFile,{'Animal body weight'},1,'G2');     xlswrite1(RawFile,BW,1,'G3'); 
    xlswrite1(RawFile,{'Z cali (V/g)'},1,'H2');     xlswrite1(RawFile,cal_Z(i),1,'H3'); 
    xlswrite1(RawFile,{'Z int (V)'},1,'I2');        xlswrite1(RawFile,cal_Zint(i),1,'I3');
    xlswrite1(RawFile,{'Time Index'},1,'J2');       xlswrite1(RawFile,Time_index(range)',1,'J3');
    xlswrite1(RawFile,{'Z1n (V)'},1,'K2');          xlswrite1(RawFile,Z1_filtered(range),1,'K3');
    xlswrite1(RawFile,{'Z2n (V)'},1,'L2');          xlswrite1(RawFile,Z2_filtered(range),1,'L3');
    xlswrite1(RawFile,{'Z3n (V)'},1,'M2');          xlswrite1(RawFile,Z3_filtered(range),1,'M3');
    xlswrite1(RawFile,{'Z4n (V)'},1,'N2');          xlswrite1(RawFile,Z4_filtered(range),1,'N3');
    xlswrite1(RawFile,{'Z Curve (V)'},1,'O2');      xlswrite1(RawFile,Zcurve(range),1,'O3');
    
    ExcelWorkbook.Save 
    ExcelWorkbook.Close(false) % Close Excel workbook. 
    Excel.Quit; 
    delete(Excel);
    
    system('taskkill /F /IM EXCEL.EXE');
    
    fprintf('    Raw xls File Complete. \n');
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  WRITE PROCESSED DATA TO SUMMARY EXCEL DOCUMENT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    
    Excel = actxserver('Excel.Application');
    % There will only be one summary sheet. Name it in the line below.
    SummaryFile = [path '\' batch];
    if ~exist(SummaryFile,'file') 
        % If the summary file does not exist, create it. 
        ExcelWorkbook = Excel.Workbooks.Add; 
        ExcelWorkbook.Sheets.Add; 
        ExcelWorkbook.SaveAs(SummaryFile);  
        ExcelWorkbook.Close(false); 
    end 

    ExcelWorkbook =  Excel.workbooks.Open(SummaryFile);   % Open Excel
        
    fprintf('Writing Headers to Summary xls File... \n');

    % Fill in headers for SummaryFile.  Put here so it is only written
    % once (only if the file doesn't already exist).
    xlswrite1(SummaryFile,{'File Name'},1,'A1');
    xlswrite1(SummaryFile,{'Animal Number'},1,'B1');
    xlswrite1(SummaryFile,{'Trial Number'},1,'C1');
    xlswrite1(SummaryFile,{'Step Number (within trial)'},1,'D1');
    xlswrite1(SummaryFile,{'Foot'},1,'E1');
    xlswrite1(SummaryFile,{'Fore Peak (%BW)'},1,'F1');
    xlswrite1(SummaryFile,{'Fore Peak Location (msec)'},1,'G1');
    xlswrite1(SummaryFile,{'Fore Impulse(%BW-sec)'},1,'H1');
    xlswrite1(SummaryFile,{'Fore Stance Time (msec)'},1,'I1');
    xlswrite1(SummaryFile,{'Hind Peak (%BW)'},1,'J1');
    xlswrite1(SummaryFile,{'Hind Peak Location (msec)'},1,'K1');
    xlswrite1(SummaryFile,{'Hind Impulse(%BW-sec)'},1,'L1');
    xlswrite1(SummaryFile,{'Hind Stance Time (msec)'},1,'M1');
    xlswrite1(SummaryFile,{'Transition Drip (%BW)'},1,'N1');
    xlswrite1(SummaryFile,{'Transition Location (msec)'},1,'O1');
    xlswrite1(SummaryFile,{'Fore Hind Distance (msec)'},1,'P1');
    xlswrite1(SummaryFile,{'Total Impulse(%BW-sec)'},1,'Q1');
    xlswrite1(SummaryFile,{'Total Stance Time (msec)'},1,'R1');

    ExcelWorkbook.Save 
    ExcelWorkbook.Close(false) % Close Excel workbook. 
    Excel.Quit; 
    delete(Excel);
    
    system('taskkill /F /IM EXCEL.EXE');
    
    fprintf('Headers Written to Summary xls File. \n');
    
    end 
    clear Excel
    
    fprintf('Writting Summary Results... \n'); 
    
    StepResults = [{name} {animalnum} {trial} {step_number} {foot} {ForePeak} ...
        {ForeTime} {ForeI} {ForeStance} {HindPeak} {HindTime} ...
        {HindI} {HindStance} {TransitionDip} {TransitionLocation} {ForeHindDistance} {ZI} {Stance}];
    
    [~,~] = xlsappend(SummaryFile,StepResults,1);
    % xlsappend is a function EHL pulled from the MatLab forum.  She did
    % not make any edits to this function.  It looks at the excel file, and
    % finds the next available row and writes the StepResults array to this
    % line. 
    
    fprintf('    Summary Results Complete. \n\n'); 
else 
    fprintf('No Spikes Selected. \n');    
end
   

end % end for the entire function


