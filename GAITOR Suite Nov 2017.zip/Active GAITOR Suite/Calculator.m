 function [] = Calculator(OutputFilename)
% February 16, 2017
% Samantha Haus, Brittany Jacobs, & Emily Lakes
%
% Last Updated: October 5, 2017
%   OCT-05-2017: EHL looking for an error in step width calculations.
%   AUG-22-2017: EHL changed variable name STImbFore or STImbHind to
%   DFImbFore, etc... This was to stay consistent, since we use duty
%   factors everywhere else.  The calculation of DF Imbalance was also
%   changed from R-L to L-R to get the right (typically our injured limb)
%   difference relative to left (typically reference limb).
%
% OutputFilename = Name of the current batch. This is what the master excel
% file will be named with. 
% Example: AGATHACalculator('Experiment1_Wk2_Day3')

% Choose the .mat files you want to fun through the calculator code.
% uipickfiles opens a GUI to select as many .mat files as you need. 
directory = uigetdir;
file = uipickfiles('FilterSpec',directory,'Type',{'*.mat'});
filecount = 1;
finish = length(file);

ErrorCount = 1;
ErrCalcs = [];

% Start a loop to run through each .mat file that was selected in
% uipickfiles above. 
while filecount <= finish
    if finish >= 4  % If there are more than 4 files, display output.
        if filecount == round(finish*2.5/10,0)
            disp('25% Complete');
        elseif filecount == round(finish*5/10,0)
            disp('50% Complete');
        elseif filecount == round(finish*7.5/10,0)
            disp('75% Complete');
        elseif filecount == round(finish,0)
            disp('COMPLETE');
        end
    end
    
    % Try to run the current .mat file through the calculator code. 
    try
        clearvars -except directory file filecount finish ErrorCount ...
            ErrCalcs OutputFilename
        [~,TrialIDName,~] = fileparts(file{filecount}); 
        AGATHAcalc(file{filecount},OutputFilename,TrialIDName);
        filecount = filecount + 1;
        
    % If the calculator code hits an error, catch it, save the error
    % message, and move on to the next .mat file. 
    catch MException
        ErrorLine = MException.stack.line;
        fprintf(['ERROR encountered in ', TrialIDName, ' at Line: ', '%i \n'],ErrorLine);
        ErrorMessage = MException.message;
        fprintf([ErrorMessage '\n \n']);

        ErrCalcs{ErrorCount,1} = file{filecount};
        ErrCalcs{ErrorCount,2} = ErrorLine;
        ErrCalcs{ErrorCount,3} = ErrorMessage;

        ErrorCount = ErrorCount + 1;
        filecount = filecount + 1;
        beep
    end
    
    % If only one .mat file was chosen, don't try and look for a second
    % video. 
    if length(file) == 1
        break
    end
end

% Save the error messages into a .mat file for the entire batch. This way,
% you can look at the all the files that may need rerun. 
if isempty(ErrCalcs) == 0
    Filename_BatchErrors = [OutputFilename, '_ErrorCalcs.mat'];
    save(Filename_BatchErrors, 'ErrCalcs');
end

end

%% Post AGATHA calculator. ------------------------------------------------ 
% Takes AGATHA output (.mat file) and calculates spatiotemporal data.
% File = Name of the current .mat file chosen in uipickfiles. 
% OutputFilename = Name of the current batch.  Created when calling the
% main AGATHAcalculator function above. 

function [] = AGATHAcalc(File,Filename,TrialIDName)

% Load AGATHA Output (from list of 'file' selected above).
load(File,'-mat');
AGATHAData = DATA.AGATHA;

%% Temporal Calculcations -------------------------------------------------
% "Temp" matrices are sorted by column 4 (frame of foot strike).

% Create a new AGATHAData matrix sorted by column 4 (frame of foot strike). 
% Used to calculate Duty Factor and Temporal Symmetry.
[~, order] = sort(AGATHAData(:,4)); 
AGATHAData_TempSort = zeros(size(AGATHAData));
for ii = 1:size(AGATHAData_TempSort,1)
    AGATHAData_TempSort(ii,:) = AGATHAData(order(ii),:);
end

% Pull Out Variables
% Find all the step groups and create new matricies.
% Forelimb = 1, Hindlimb = 0, Right Paw = 0, Left Paw = 1

% Find where Column 2, ForeHind = 1 (Fore)
Fore_TempSort = AGATHAData_TempSort(AGATHAData_TempSort(:,2) == 1,:);

% Find where Column 2, ForeHind = 0 Hind)
Hind_TempSort = AGATHAData_TempSort(AGATHAData_TempSort(:,2) == 0,:);

% Find where ForeHindTemp = 1 (Fore) & LeftRightTemp = 1 (Left)
LeftFore_TempSort = AGATHAData_TempSort(AGATHAData_TempSort(:,2) == 1 ...
    & AGATHAData_TempSort(:,9) == 1,:);

% Find where ForeHindTemp = 0 (Hind) & LeftRightTemp = 0 (Right)
LeftHind_TempSort = AGATHAData_TempSort(AGATHAData_TempSort(:,2) == 0 ...
    & AGATHAData_TempSort(:,9) == 1,:);

% Find where ForeHind = 1 (Fore) & LeftRight = 0 (Left)
RightFore_TempSort = AGATHAData_TempSort(AGATHAData_TempSort(:,2) == 1 ...
    & AGATHAData_TempSort(:,9) == 0,:);

% Find where ForeHind = 0 (Hind) & LeftRight = 0 (Right)
RightHind_TempSort = AGATHAData_TempSort(AGATHAData_TempSort(:,2) == 0 ...
    & AGATHAData_TempSort(:,9) == 0,:);

%% Duty Factor ------------------------------------------------------------
% DF = (TO1-FS1)/(FS2-FS1)

% For every LeftForeStepsTemp, calculate DF.
iiend = size(LeftFore_TempSort,1);
if iiend > 1
    iiend = size(LeftFore_TempSort,1)-1;

    % Preallocate DFLeftFore.
    DFLeftFore = zeros(iiend,1);
    for ii = 1:iiend
        DFLeftFore(ii) =(LeftFore_TempSort(ii,6) - LeftFore_TempSort(ii,4)) / ...
            (LeftFore_TempSort((ii+1),4) - LeftFore_TempSort(ii,4));
    end
    
    % Take the median. Remove 0's before taking median. 
    DFLeftForeNZ = DFLeftFore(DFLeftFore ~= 0);
    DFLeftFore_Median = median(DFLeftForeNZ);
else
    DFLeftFore = [];
    DFLeftFore_Median = [];
end

iiend = size(RightFore_TempSort,1);
if iiend > 1
    iiend = size(RightFore_TempSort,1)-1;

    % Preallocate DFRightFore.
    DFRightFore = zeros(iiend,1);
    for ii = 1:iiend
        DFRightFore(ii) =(RightFore_TempSort(ii,6) - RightFore_TempSort(ii,4)) / ...
            (RightFore_TempSort((ii+1),4) - RightFore_TempSort(ii,4));
    end
    
    % Take the median. Remove 0's before taking median. 
    DFRightForeNZ = DFRightFore(DFRightFore ~= 0);
    DFRightFore_Median = median(DFRightForeNZ);
else
    DFRightFore = [];
    DFRightFore_Median = [];
end

DFFore = mean([DFLeftFore DFRightFore]);

iiend = size(LeftHind_TempSort,1);
if iiend > 1
    iiend = size(LeftHind_TempSort,1)-1;

    % Preallocate DFLeftHind.
    DFLeftHind = zeros(iiend,1);
    for ii = 1:iiend
        DFLeftHind(ii) =(LeftHind_TempSort(ii,6) - LeftHind_TempSort(ii,4)) / ...
            (LeftHind_TempSort((ii+1),4) - LeftHind_TempSort(ii,4));
    end
    
    % Take the median. Remove 0's before taking median. 
    DFLeftHindNZ = DFLeftHind(DFLeftHind ~= 0);
    DFLeftHind_Median = median(DFLeftHindNZ);
else
    DFLeftHind = [];
    DFLeftHind_Median = [];
end


iiend = size(RightHind_TempSort,1);
if iiend > 1
    iiend = size(RightHind_TempSort,1)-1;

    % Preallocate DFRightHind.
    DFRightHind = zeros(iiend,1);
    for ii = 1:iiend
        DFRightHind(ii) =(RightHind_TempSort(ii,6) - RightHind_TempSort(ii,4)) / ...
            (RightHind_TempSort((ii+1),4) - RightHind_TempSort(ii,4));
    end
    
    % Take the median. Remove 0's before taking median. 
    DFRightHindNZ = DFRightHind(DFRightHind ~= 0);
    DFRightHind_Median = median(DFRightHindNZ);
else
    DFRightHind = [];
    DFRightHind_Median = [];
end

DFHind = mean([DFLeftHind DFRightHind]);

% If any variable = NaN, clear it. 
if isnan(DFLeftFore_Median) == 1
    DFLeftFore_Median = [];
end
if isnan(DFRightFore_Median) == 1
    DFRightFore_Median = [];
end
if isnan(DFLeftHind_Median) == 1
    DFLeftHind_Median = [];
end
if isnan(DFRightHind_Median) == 1
    DFRightHind_Median = [];
end

% Preallocate variables for avgerages.
DFImbaFore = zeros(length(DFLeftFore),1);
    DFImbaFore(:,:) = 404;
DFImbaHind = zeros(length(DFLeftHind),1);
    DFImbaHind(:,:) = 404;


% Average the Fore and Hind limbs together & Calculate ST Imbalance.
if exist('DFLeftForeNZ','var') == 1 && exist('DFRightForeNZ','var') == 1
    minLength = min([length(DFLeftForeNZ), length(DFRightForeNZ)]);
    for ii = 1:minLength
        DFImbaFore(ii) =  DFLeftForeNZ(ii) - DFRightForeNZ(ii);
    end
end
if exist('DFLeftHindNZ','var') == 1 && exist('DFRightHindNZ','var') == 1   
    minLength = min([length(DFLeftHindNZ), length(DFRightHindNZ)]);
    for ii = 1:minLength
        DFImbaHind(ii) =  DFLeftHindNZ(ii) - DFRightHindNZ(ii);
    end
end

% Take Medians. Remove 0's before taking median.
DFImbaForeNZ = DFImbaFore(DFImbaFore ~= 404);
DFImbaHindNZ = DFImbaHind(DFImbaHind ~= 404);

if isempty(DFImbaForeNZ) ==0
    DFImbaFore_Median = median(DFImbaHindNZ);
else
    DFImbaFore_Median = [];
end
if isempty(DFImbaHindNZ) ==0
    DFImbaHind_Median = median(DFImbaHindNZ);
else
    DFImbaHind_Median = [];
end

%% Temporal Symmetry ------------------------------------------------------
% Data is sorted by the frame of footstrike (column 4).

% FORE LIMBS --------------------------------------------------------------

% Preallocate Variables.
TempSymFore = zeros(size(RightFore_TempSort,1),1);
StrideLengthFore = zeros(size(RightFore_TempSort,1),1);
StepWidthFore = zeros(size(RightFore_TempSort,1),1);

% Check if there is a right fore step.
if isempty(RightFore_TempSort) == 0
    for ii = 1:size(RightFore_TempSort,1)
        %Find previous and post foot strikes based on closest y coordinate.
        LeftPrevFSTemp = max(Fore_TempSort(Fore_TempSort(:,4) < ...
            RightFore_TempSort(ii,4) & Fore_TempSort(:,9) == 1,4));
        LeftPostFSTemp = min(Fore_TempSort(Fore_TempSort(:,4) > ...
            RightFore_TempSort(ii,4) & Fore_TempSort(:,9) == 1,4));

        % If there was a previous & post left from above, then calculate
        % symmetry. 
        if isempty(LeftPrevFSTemp) == 0 && isempty(LeftPostFSTemp) == 0
            TempSymFore(ii,1) = (RightFore_TempSort(ii,4)-LeftPrevFSTemp) / ...
                (LeftPostFSTemp-LeftPrevFSTemp);    
        else
            continue
        end
    end
end

% HIND LIMBS --------------------------------------------------------------

% Preallocate Variables. 
TempSymHind = zeros(size(RightHind_TempSort,1),1);       
StrideLengthHind = zeros(size(RightHind_TempSort,1),1);          
StepWidthHind = zeros(size(RightHind_TempSort,1),1);

% Check if there is a right hind step.
if isempty(RightHind_TempSort) == 0
    for ii = 1:size(RightHind_TempSort,1)
        % Find previous and post foot strikes based on closest y coordinate.
        LeftPrevFSTemp = max(Hind_TempSort(Hind_TempSort(:,4) < ...
            RightHind_TempSort(ii,4) & Hind_TempSort(:,9) == 1,4));
        LeftPostFSTemp = min(Hind_TempSort(Hind_TempSort(:,4) > ...
            RightHind_TempSort(ii,4) & Hind_TempSort(:,9) == 1,4));
        
        % If there was a previous & post left from above, then calculate
        % symmetry. 
        if isempty(LeftPrevFSTemp) == 0 && isempty(LeftPostFSTemp) == 0
            TempSymHind(ii,1) = (RightHind_TempSort(ii,4)-LeftPrevFSTemp) / ...
                (LeftPostFSTemp-LeftPrevFSTemp);               
        else
            continue
        end
    end
end

%% Spatial Calculatons ----------------------------------------------------
% Data is sorted by the x-position of footstrike (column 3).

% Create a new AGATHAData matrix sorted by column 3 (location of foot strike). 
[~, order] = sort(AGATHAData(:,3)); 
AGATHAData_SpatialSort = zeros(size(AGATHAData));
for ii = 1:size(AGATHAData_SpatialSort,1)
    AGATHAData_SpatialSort(ii,:) = AGATHAData(order(ii),:);
end

% Pull Out Variables
% Find all the step groups and create new matricies.
% Forelimb = 1, Hindlimb = 0, Right Paw = 0, Left Paw = 1

% Find where ForeHind = 1 (Fore)
Fore_SpatialSort = AGATHAData_SpatialSort(AGATHAData_SpatialSort(:,2) == 1,:);

% Find where ForeHind = 0 Hind)
Hind_SpatialSort = AGATHAData_SpatialSort(AGATHAData_SpatialSort(:,2) == 0,:);

% Find where ForeHind = 1 (Fore) & LeftRight = 0 (Left)
RightFore_SpatialSort = AGATHAData_SpatialSort(AGATHAData_SpatialSort(:,2) == 1 ...
    & AGATHAData_SpatialSort(:,9) == 0,:);

% Find where ForeHind = 0 (Hind) & LeftRight = 0 (Right)
RightHind_SpatialSort = AGATHAData_SpatialSort(AGATHAData_SpatialSort(:,2) == 0 ...
    & AGATHAData_SpatialSort(:,9) == 0,:);

% FORE LIMBS --------------------------------------------------------------

% Preallocate Variables.
StepLengthFore = zeros(size(RightHind_SpatialSort,1),1);
SpatialSymFore = zeros(size(RightHind_SpatialSort,1),1);

if size(RightHind_SpatialSort,1) > 1
    for ii = 1:size(RightFore_SpatialSort,1)
        % Find previous and post Foot Strikes based on closest x coordinate. 
        LeftPrevFS = max(Fore_SpatialSort(Fore_SpatialSort(:,3) < RightFore_SpatialSort(ii,3) ...
            & Fore_SpatialSort(:,9) == 1,3));
        LeftPostFS = min(Fore_SpatialSort(Fore_SpatialSort(:,3) > RightFore_SpatialSort(ii,3) ...
            & Fore_SpatialSort(:,9) == 1,3));

        % If there was a previous & post left from above, then continue
        % with calculations. 
        if isempty(LeftPrevFS) == 0 && isempty(LeftPostFS) == 0
            LeftPrevRow = find(Fore_SpatialSort(:,3) == LeftPrevFS);
            LeftPostRow = find(Fore_SpatialSort(:,3) == LeftPostFS);

            % Heron's Theorem.
            % For any given right foot (R1), there is a left foot before
            % (L1,previous) and after (L2,post). This set of 3 foot placements
            % creates a triangle, where:
            % a = L2-L2 (stride)
            % b = side of triangle between L1 and R1.
            % c = side of triangle between R1 and L2.
            % Use pythagorean's theorem to get the lengths of a, b, and c. 
            a = sqrt((Fore_SpatialSort(LeftPrevRow,10) - Fore_SpatialSort(LeftPostRow,10))^2 ...
                + (Fore_SpatialSort(LeftPrevRow,11) - Fore_SpatialSort(LeftPostRow,11))^2);
            b = sqrt((Fore_SpatialSort(LeftPrevRow,10) - RightFore_SpatialSort(ii,10))^2 ...
                + (Fore_SpatialSort(LeftPrevRow,11) - RightFore_SpatialSort(ii,11))^2);
            c = sqrt((RightFore_SpatialSort(ii,10) - Fore_SpatialSort(LeftPostRow,10))^2 ...
                + (RightFore_SpatialSort(ii,11) - Fore_SpatialSort(LeftPostRow,11))^2);
            s = (a+b+c)/2;
            Area = sqrt(s*(s-a)*(s-b)*(s-c));
            StrideLengthFore(ii) = a;
            StepWidthFore(ii) = (Area*2)/StrideLengthFore(ii);
            % Note: A step length in this code is considered R1-L1.  This
            % is to keep all the symmetry and duty factor equations
            % consistent.
            StepLengthFore(ii) = sqrt(b^2 - StepWidthFore(ii)^2);
            SpatialSymFore(ii) = StepLengthFore(ii)/StrideLengthFore(ii);
            
            % Set up variables for body sway calculations. 
%             PrevObj(ii) = Fore_SpatialSort(LeftPrevRow,1);
%             PrevFrame(ii) = Fore_TempSort(find(Fore_TempSort(:,1) == PrevObj(ii)),8);
%             PostObj(ii) = Fore_SpatialSort(LeftPostRow,1);
%             PostFrame(ii) = Fore_TempSort(find(Fore_TempSort(:,1) == PostObj(ii)),8);
%             
%             RightObj(ii) = RightFore_SpatialSort(ii,1);
%             RightFrame(ii) = Fore_TempSort(find(Fore_TempSort(:,1) == RightObj(ii)),8);
        else
            continue
        end     
    end
end

% BodySwayForeVars = struct('PrevFrame',PrevFrame,'PostFrame',PostFrame,'Stride',...
%     StrideLengthFore,'StepWidth',StepWidthFore,'RightFrame',RightFrame);

% Check if the variable exists. If so, take the median.
if exist('TempSymFore','var')
    TempSymForeNZ = TempSymFore(TempSymFore ~= 0);
    TemporalSymFore_Median = median(TempSymForeNZ);
else
    TemporalSymFore_Median = [];
    TempSymFore = [];
end
if exist('StepWidthFore','var')
    StepWidthForeNZ = StepWidthFore(StepWidthFore ~= 0);
    StepWidthFore_Median = median(StepWidthForeNZ);
else
    StepWidthFore_Median = [];
    StepWidthFore = [];
end
if exist('StrideLengthFore','var')
    StrideLengthForeNZ = StrideLengthFore(StrideLengthFore ~= 0);
    StrideLengthFore_Median = median(StrideLengthForeNZ);
else
    StrideLengthFore_Median = [];
    StrideLengthFore = [];
end
if exist('SpatialSymFore','var')
    SpatialSymForeNZ = SpatialSymFore(SpatialSymFore ~= 0);
    SpatialSymFore_Median = median(SpatialSymForeNZ);
else
    SpatialSymFore_Median = [];
    SpatialSymFore = [];
end

% HIND LIMBS --------------------------------------------------------------

% Preallocate Variables. 
StepLengthHind = zeros(size(RightHind_SpatialSort,1),1);
SpatialSymHind = zeros(size(RightHind_SpatialSort,1),1);

if size(RightHind_SpatialSort,1) > 1
    for ii = 1:size(RightHind_SpatialSort,1)
        %Find previous and post Foot Strikes based on closest x coordinate. 
        LeftPrevFS = max(Hind_SpatialSort(Hind_SpatialSort(:,3) < RightHind_SpatialSort(ii,3) ...
            & Hind_SpatialSort(:,9) == 1,3));
        LeftPostFS = min(Hind_SpatialSort(Hind_SpatialSort(:,3) > RightHind_SpatialSort(ii,3) ...
            & Hind_SpatialSort(:,9) == 1,3));
        
        % If there was a previous & post left from above, then continue
        % with calculations. 
        if isempty(LeftPrevFS) == 0 && isempty(LeftPostFS) == 0
            LeftPrevRow = find(Hind_SpatialSort(:,3) == LeftPrevFS);
            LeftPostRow = find(Hind_SpatialSort(:,3) == LeftPostFS);

            % Heron's Theorem.
            % For any given right foot (R1), there is a left foot before
            % (L1,previous) and after (L2,post). This set of 3 foot placements
            % creates a triangle, where:
            % a = L2-L2 (stride)
            % b = side of triangle between L1 and R1.
            % c = side of triangle between R1 and L2.
            % Use pythagorean's theorem to get the lengths of a, b, and c.
            a = sqrt((Hind_SpatialSort(LeftPrevRow,10)-Hind_SpatialSort(LeftPostRow,10))^2 ...
                + (Hind_SpatialSort(LeftPrevRow,11)-Hind_SpatialSort(LeftPostRow,11))^2);
            b = sqrt((Hind_SpatialSort(LeftPrevRow,10)-RightHind_SpatialSort(ii,10))^2 ...
                + (Hind_SpatialSort(LeftPrevRow,11)-RightHind_SpatialSort(ii,11))^2);
            c = sqrt((RightHind_SpatialSort(ii,10)-Hind_SpatialSort(LeftPostRow,10))^2 ...
                + (RightHind_SpatialSort(ii,11)-Hind_SpatialSort(LeftPostRow,11))^2);
            s = (a+b+c)/2;
            Area = sqrt(s*(s-a)*(s-b)*(s-c));
            StrideLengthHind(ii) = a;
            StepWidthHind(ii) = (Area*2)/StrideLengthHind(ii);
            % Note: A step length in this code is considered R1-L1.  This
            % is to keep all the symmetry and duty factor equations
            % consitent.
            StepLengthHind(ii) = sqrt(b^2 - StepWidthHind(ii)^2);
            SpatialSymHind(ii) = StepLengthHind(ii)/StrideLengthHind(ii);
            
            % Set up variables for body sway calculations. 
%             PrevObj(ii) = Hind_SpatialSort(LeftPrevRow,1);
%             PrevFrame(ii) = Hind_TempSort(find(Hind_TempSort(:,1) == PrevObj(ii)),8);
%             PostObj(ii) = Hind_SpatialSort(LeftPostRow,1);
%             PostFrame(ii) = Hind_TempSort(find(Hind_TempSort(:,1) == PostObj(ii)),8);
%             
%             RightObj(ii) = RightHind_SpatialSort(ii,1);
%             RightFrame(ii) = Hind_TempSort(find(Hind_TempSort(:,1) == RightObj(ii)),8);
        else
            continue
        end     
    end
end

% BodySwayHindVars = struct('PrevFrame',PrevFrame,'PostFrame',PostFrame,'Stride',...
%     StrideLengthHind,'StepWidth',StepWidthHind,'RightFrame',RightFrame);

% Check if the variable exists. If so, take the median. Remove 0's first.
if exist('TempSymHind','var')
    TempSymHindNZ = TempSymHind(TempSymHind ~= 0);
    TemporalSymHind_Median = median(TempSymHindNZ);
else
    TemporalSymHind_Median = [];
    TempSymHind = [];
end
if exist('StepWidthHind','var')
    StepWidthHindNZ = StepWidthHind(StepWidthHind ~= 0);
    StepWidthHind_Median = median(StepWidthHindNZ);
else
    StepWidthHind_Median = [];
    StepWidthHind = [];
end
if exist('StrideLengthHind','var')
    StrideLengthHindNZ = StrideLengthHind(StrideLengthHind ~= 0);
    StrideLengthHind_Median = median(StrideLengthHindNZ);
else
    StrideLengthHind_Median = [];
    StrideLengthHind = [];
end
if exist('SpatialSymHind','var')
    SpatialSymHindNZ = SpatialSymHind(SpatialSymHind ~= 0);
    SpatialSymHind_Median = median(SpatialSymHindNZ);
else
    SpatialSymHind_Median = [];
    SpatialSymHind = [];
end

%% Velocity Calculations --------------------------------------------------

BottomBodyCentX = DATA.Velocity.BottomCentroidVelocity(:,1);
BottomBodyCentY = DATA.Velocity.BottomCentroidVelocity(:,2);
BottomNoseCentX = DATA.Velocity.BottomNoseVelocity(:,1);
BotttomNoseCentY = DATA.Velocity.BottomNoseVelocity(:,2);

% Because the body centroid starts tracking when the rat is mostly on the
% screen in AGATHA, the centroid essintially doesn't move for the first few
% frames.  To account for this, crop the x-position of centroid to where
% there is an actual hind footstrike (so we know the centroid is "real"). 
FirstCentFrame = min(Hind_SpatialSort(:,4));
LastCentFrame = max(Fore_SpatialSort(:,6));

FirstBodyPointX = BottomBodyCentX(FirstCentFrame);
FirstBodyPointY = BottomBodyCentY(FirstCentFrame);

FirstNosePointX = BottomNoseCentX(FirstCentFrame);
FirstNosePointY = BotttomNoseCentY(FirstCentFrame);

j = 1;
for i = FirstCentFrame:(LastCentFrame-1)
    ZeroCheckX = eq(BottomBodyCentX(i), 0); 
    ZeroCheckY = eq(BottomBodyCentY(i), 0);
    if ZeroCheckX == 0 || ZeroCheckY == 0
        BottomBodyD(j,1) = sqrt((BottomBodyCentX(i+1) - FirstBodyPointX)^2 + ...
            (BottomBodyCentY(i+1) - FirstBodyPointY)^2);
        BottomNoseD(j,1) = sqrt((BottomNoseCentX(i+1) - FirstNosePointX)^2 + ...
            (BotttomNoseCentY(i+1) - FirstNosePointY)^2);

        BottomBodyD(j,2) = i;
        BottomNoseD(j,2) = i;

        j = j + 1; 
    else
        % do nothing
    end
end

BottomBodyLinearCoefficients = polyfit(BottomBodyD(:,2),BottomBodyD(:,1),1);
BottomNoseLinearCoefficients = polyfit(BottomNoseD(:,2),BottomNoseD(:,1),1);

BottomVelocityBody = BottomBodyLinearCoefficients(1);
BottomVelocityNose = BottomNoseLinearCoefficients(1);

% Only look for Top velocity vectors if they exist. (Top vectors were added
% 3/30/17).
if exist('DATA.Velocity.TopCentroidVelocity','var') == 1
    TopBodyCentX = DATA.Velocity.TopCentroidVelocity(:,1);
    TopBodyCentY = DATA.Velocity.TopCentroidVelocity(:,2);
    TopNoseCentX = DATA.Velocity.TopNoseVelocity(:,1);
    TopNoseCentY = DATA.Velocity.TopNoseVelocity(:,2);
    j = 1;
    for i = FirstCentFrame:(LastCentFrame-1)
        ZeroCheckX = eq(TopBodyCentX(i), 0); 
        ZeroCheckY = eq(TopBodyCentY(i), 0);
        if ZeroCheckX == 0 || ZeroCheckY == 0
            TopBodyD(j,1) = sqrt((TopBodyCentX(i+1) - FirstBodyPointX)^2 + ...
                (TopBodyCentY(i+1) - FirstBodyPointY)^2);
            TopNoseD(j,1) = sqrt((TopNoseCentX(i+1) - FirstNosePointX)^2 + ...
                (TopNoseCentY(i+1) - FirstNosePointY)^2);

            TopBodyD(j,2) = i;
            TopNoseD(j,2) = i;

            j = j + 1; 
        else
            % do nothing
        end
    end

    TopBodyLinearCoefficients = polyfit(TopBodyD(:,2),TopBodyD(:,1),1);
    TopNoseLinearCoefficients = polyfit(TopNoseD(:,2),TopNoseD(:,1),1);

    TopVelocityBody = TopBodyLinearCoefficients(1);
    TopVelocityNose = TopNoseLinearCoefficients(1);

    % Compare Top and Bottom velocities. Top velocities are not output into
    % the Excel sheets below.  They are only used as a safety check here. 
    BodyDiff = abs(TopVelocityBody - BottomVelocityBody)/TopVelocityBody*100;
    NoseDiff = abs(TopVelocityNose - BottomVelocityNose)/TopVelocityNose*100;

    if BodyDiff >= 10
        fprintf(['\nCheck Velocity for ', TrialIDName,'. ','%i',...
            ' difference detected between top and bottom body velocities.' , '\n'],BodyDiff);
    end
    if NoseDiff >= 10
        fprintf(['\nCheck Velocity for ', TrialIDName,'. ','%i',...
            ' difference detected between top and bottom nose velocities.' , '\n'],NoseDiff);
    end
end

% Eventually, the Y position may be used to track body sway; however, this
% is currently not being used as of February 17, 2017. 
%BodyCentY = DATA.Velocity.CentroidVelocity(:,2);
%NoseCentY = DATA.Velocity.NoseVelocity(:,2);
% for i = 1:size(BodySwayForeVars.StepWidth,2)
%     BodyCentYFrame1 = floor(BodySwayForeVars.PrevFrame(i));
%     BodyCentYFrame2 = floor(BodySwayForeVars.PostFrame(i));
%     BodyCentYRange = BodyCentY(BodyCentYFrame1:BodyCentYFrame2);
%     FrameRange = [BodyCentYFrame1:BodyCentYFrame2];
% end
% 
% for i = 1:size(BodySwayHindVars.StepWidth,2)
%     BodyCentYFrame1 = floor(BodySwayHindVars.PrevFrame(i));
%     BodyCentYFrame2 = floor(BodySwayHindVars.PostFrame(i));
%     BodyCentYRange = BodyCentY(BodyCentYFrame1:BodyCentYFrame2);
%     FrameRange = [BodyCentYFrame1:BodyCentYFrame2];
% end
% plot(RightFrame(i),BodyCentYRange(f),'o');
% hold on
% plot(RightFrame(i),BodyCentYRange(1),'*');
% close all
% plot(FrameRange,BodyCentYRange)
% hold on
% plot(RightFrame(i),BodyCentYRange(f),'o');
% hold on
% plot(FrameRange(1),BodyCentYRange(1),'*');
% fin = length(FrameRange);
% plot(FrameRange(fin),BodyCentYRange(fin),'*');
    

%% Save Data to Excel -----------------------------------------------------

% Write an individual trial sheet with all values for each trial of a batch.
TrialLabels = [{'Left Fore Duty Factor'},{'Right Fore Duty Factor'}, ...
    {'Fore Duty Factor'},{'ST Imbalance Fore'},{'Left Hind Duty Factor'},{'Right Hind Duty Factor'}, ...
    {'Hind Duty Factor'},{'ST Imbalance Hind'},{'Fore Limb Temporal Symmetry'},{'Hind Limb Temporal Symmetry'}, ...
    {'Fore Step Width'},{'Hind Step Width'},{'Fore Stride Length'}, ...
    {'Hind Stride Length'},{'Spatial Symmetry Fore'},{'Spatial Symmetry Hind'}, ...
    {'Bottom Nose Velocity'},{'Bottom Body Velocity'}];
TrialFilename = TrialIDName(1:end-5);
xlswrite(TrialFilename,TrialLabels);

% Preallocate a large martix of all the trial data. 
TrialData = zeros(size(DFLeftFore,1),16);

% Fill in the matrix with each vector. 
TrialData(1:length(DFLeftFore),1) = DFLeftFore';
TrialData(1:length(DFRightFore),2) = DFRightFore';
TrialData(1:length(DFFore),3) = DFFore;
TrialData(1:length(DFImbaFore),4) = DFImbaFore;
TrialData(1:length(DFLeftHind),5) = DFLeftHind';
TrialData(1:length(DFRightHind),6) = DFRightHind';
TrialData(1:length(DFHind),7) = DFHind;
TrialData(1:length(DFImbaHind),8) = DFImbaHind;
TrialData(1:length(TempSymFore),9) = TempSymFore';
TrialData(1:length(TempSymHind),10) = TempSymHind;
TrialData(1:length(StepWidthFore),11) = StepWidthFore;
TrialData(1:length(StepWidthHind),12) = StepWidthHind;
TrialData(1:length(StrideLengthFore),13) = StrideLengthFore;
TrialData(1:length(StrideLengthHind),14) = StrideLengthHind;
TrialData(1:length(SpatialSymFore),15) = SpatialSymFore;
TrialData(1:length(SpatialSymHind),16) = SpatialSymHind;
TrialData(1,17) = BottomVelocityNose;
TrialData(1,18) = BottomVelocityBody;

xlsappend(TrialFilename,TrialData);

% Write a master sheet with median values for each trial of a batch.
MasterSheet = [Filename '_master.xlsx'];
if exist('MasterSheet','file') == 0
    MasterLabels = [{'TrialIDName'},{'DF Left Hind'},{'DF Right Hind'},{'DF Hind'} ...
        {'DF Imbalance Hind (L-R)'},{'DF Left Fore'},{'DF Right Fore'},{'DF Fore'},...
        {'DF Imbalance Fore (L-R)'},{'Temporal Sym Fore'}, ...
        {'Temporal Sym Hind'}, {'Step Width Fore (pixels)'},{'Step Width Hind (pixels)'}, ...
        {'Stride Length Hind (pixels)'}, {'Stride Length Fore (pixels)'},{'Spatial Sym Fore'}, ...
        {'Spatial Sym Hind'}, {'Bottom Nose Velocity (pixels/frame)'},{'Bottom Body Velocity (pixels/frame)'}];
    xlswrite(MasterSheet,MasterLabels);
end
MasterData = [{TrialIDName},{DFLeftHind_Median},{DFRightHind_Median},{DFHind_Median},{DFImbaHind_Median},{DFLeftFore_Median},...
    {DFRightFore_Median},{DFFore_Median},{DFImbaFore_Median},{TemporalSymFore_Median},{TemporalSymHind_Median},{StepWidthFore_Median},...
    {StepWidthHind_Median},{StrideLengthHind_Median},{StrideLengthFore_Median},{SpatialSymFore_Median},...
    {SpatialSymHind_Median},{BottomVelocityNose},{BottomVelocityBody}];

for i = 1:17
    if isnan(MasterData{i}) == 1
        MasterData{i} = [];
    end
end

xlsappend(MasterSheet,MasterData);

end

