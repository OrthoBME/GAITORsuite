% LightingSetup.m
% Emily H. Lakes, Brittany Y. Jacobs, & Kyle D. Allen

% Last Updated: September 4, 2017
%   Aug-22-2017: EHL added a parameter called ConcatenateVideos.  

% This script produces the necessary setup file to run AGATHA. Images for 
% filter setup will also be saved from this code. Generally, these 
% parameters can be set through AGATHA's companion setup GUI interface.

%%%%%%%%% TO START: Press the "Run" button in the Top Editor Tab. %%%%%%%%%

clc; clear;
close all;

% Output file name declaration. Change based on associated batch. 
% Example: 'Day1' or 'Day1_Rat03_t06-t08'
BatchInput = inputdlg('Enter a unique batch name for your experiment and testing day.','Batch Name',1,{'Default'});
Batch = BatchInput{1};

%% Select Z Coordinates %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Directory = uigetdir;
waitfor(msgbox('Select a single sample video for filtering'))
File = uipickfiles('FilterSpec',Directory,'Type',{'*.avi' '.avi'});

% This is needed for the multiselect.  Always put the file in this format.
File = cellstr(File); 

% VideoName - use the full root for best results
VideoName = File{1};  

fprintf('Loading video... 1-2 minutes processing time \n \n');
v = VideoReader(VideoName);
Video = read(v);

[~, XMax, ~, FrameMax] = size(Video);
MidFrame = round(FrameMax/2);

waitfor(msgbox('Select the arena floor by clicking once.'));
imshow(Video(:,:,:,MidFrame));
[~,FloorZCoordinate] = ginput(1);
close all

waitfor(msgbox('Select the back of the arena in the mirrored image by clicking once.'));
imshow(Video(:,:,:,MidFrame));
[~,ArenaZCoordinate] = ginput(1);
close all

%% Background Construction

% FOR TOP
TopFirstFrame = (Video(1:FloorZCoordinate,:,:,1));
TopEndFrame = (Video(1:FloorZCoordinate,:,:,FrameMax));

Background1 = [TopFirstFrame(:,1:floor(XMax/2),:,:),TopEndFrame(:,(floor(XMax/2)+1):XMax,:,:)];
Background2 = [TopEndFrame(:,1:floor(XMax/2),:,:),TopFirstFrame(:,(floor(XMax/2)+1):XMax,:,:)];

% Picks the best background based upon the consistency of the image.
% Background that doesn't have the rat eliminated should have a higher
% variability in the red, green, and blue channels.
RedVariability = std(std(double(Background1(:,:,1)))) - std(std(double(Background2(:,:,1))));
GreenVariability = std(std(double(Background1(:,:,2)))) - std(std(double(Background2(:,:,2))));
BlueVariability = std(std(double(Background1(:,:,3)))) - std(std(double(Background2(:,:,3))));
if (RedVariability < 0) && (GreenVariability < 0) && (BlueVariability < 0)
    TopBackground = Background1;
elseif (RedVariability > 0) && (GreenVariability < 0) && (BlueVariability < 0)
    TopBackground = Background1;
elseif (RedVariability < 0) && (GreenVariability > 0) && (BlueVariability < 0)
    TopBackground = Background1;
elseif (RedVariability < 0) && (GreenVariability < 0) && (BlueVariability > 0)
    TopBackground = Background1;
else
    TopBackground = Background2;
end

% FOR BOTTOM
BottomFirstFrame = (Video(ArenaZCoordinate:end,:,:,1));
BottomEndFrame = (Video(ArenaZCoordinate:end,:,:,FrameMax));

Background1 = [BottomFirstFrame(:,1:floor(XMax/2),:,:),BottomEndFrame(:,(floor(XMax/2)+1):XMax,:,:)];
Background2 = [BottomEndFrame(:,1:floor(XMax/2),:,:),BottomFirstFrame(:,(floor(XMax/2)+1):XMax,:,:)];

% Picks the best background based upon the consistency of the image.
% Background that doesn't have the rat eliminated should have a higher
% variability in the red, green, and blue channels.
RedVariability = std(std(double(Background1(:,:,1)))) - std(std(double(Background2(:,:,1))));
GreenVariability = std(std(double(Background1(:,:,2)))) - std(std(double(Background2(:,:,2))));
BlueVariability = std(std(double(Background1(:,:,3)))) - std(std(double(Background2(:,:,3))));
if (RedVariability < 0) && (GreenVariability < 0) && (BlueVariability < 0)
    BottomBackground = Background1;
elseif (RedVariability > 0) && (GreenVariability < 0) && (BlueVariability < 0)
    BottomBackground = Background1;
elseif (RedVariability < 0) && (GreenVariability > 0) && (BlueVariability < 0)
    BottomBackground = Background1;
elseif (RedVariability < 0) && (GreenVariability < 0) && (BlueVariability > 0)
    BottomBackground = Background1;
else
    BottomBackground = Background2;
end

%% Save Images

% Define im_bottom as middle frame to select filters from.
figure('visible','off'); imshow(Video(:,:,:,MidFrame));
saveas(gcf, [Batch, '_im_full_bg.jpg']) 

% Define im_bottom as middle frame to select filters from.
TopMidFrame = Video(1:FloorZCoordinate,:,:,MidFrame); 
figure('visible','off'); imshow(TopMidFrame);
saveas(gcf, [Batch, '_im_rat_bg.jpg']) 

% Define im_bottom as middle frame to select filters from.
BottomMidFrame = Video(ArenaZCoordinate:end,:,:,MidFrame); 
figure('visible','off'); imshow(BottomMidFrame);
saveas(gcf, [Batch, '_im_paw_bg.jpg']) 

%% Complete
close all;
fprintf('LightingSetup is complete. Please run colorThresholder to check filters. \n \n');
