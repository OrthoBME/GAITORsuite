%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  dynamicEDGAR_BYMJ.m
%%%%%  EDGAR Dynamic Data Processing Interface
%%%%%  Edited from ZXPeaks (HEK) by BYMJ 12-12-14
%%%%%  Edited from dynamicEDGAR.m (BYMJ) by EHL 03-23-2016
%%%%%  Edited from dynamicEDGAR_EHL2.m (EHL) by BYMJ on 4-6-2017
%%%%%  EHL converted to 4 force plate system, and now calculates the free
%%%%%  moment and center of pressure for the foot.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clearvars;
home;
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% SET BATCH NAME AND SETUP MODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set summary file name for batch
batch = 'Exercise_W9.xls';
% Path from Emily's EDGAR2 version: 'F:\Dynamic\MIA_2016_EHL_SummaryFile.xls'

% Select setup. For 2-cube/4-panel setup, please set setup to 'EDGAR'. For
% 4-cube/2-panel setup, please set setup to 'EDGAR2'.
setup = 'EDGAR_ForeHindPairs_4Panel';

% BW matrix has animalnum as the column.
%%% BYMJ 1/6/17: Set up to be run by week
%%% For Emily's experiment, comment out this variable here.
    % Week 4
%      BWmatrix = [378 372 388 000 380 372 367 386 365 412 385 375 414 408 ...
%          415 377 389 380 408 388 380 395 397 400 402 364 366 400 410 388];
     % Week 9
     BWmatrix = [425 425 425 000 438 406 416 430 430 463 430 423 485 455 ...
         470 430 438 431 463 453 419 440 457 466 442 408 420 458 460 446];
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Note:
% 1 = LEFT FOOT;        % 0 = RIGHT FOOT;

% Step threshold
thresh = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  FIND FILE
%%%%%  (EDIT ON 8/17/15 BYMJ) & Pull Info (EHL 9/27/2016)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose what file type you have.  Change to '*.tdms' to convert directly
% from .tdms within the code.  If you already converted, then leave as .mat
[file,path] = uigetfile('*.tdms','Find the Files to Import','MultiSelect', 'on');

% This is needed for the multiselect.  Always put the file in this format.
file = cellstr(file); 

% START loop for each trial/file you clicked above.
for n=1:length(file)
    close all
    tic  % Get time to click through each trial. tic = start, toc = end.
    filename = fullfile ( path, file{n} );
    % Break up filename into path, name, and extension.
    [path,name,extension] = fileparts(filename);  
    
    % Break up the name into it's components (assumes name is separated by 
    % underscores).  Change this based on your naming convention.
    switch setup
        case 'EDGAR_4Panel'
            nameparts = regexp(name, '_','split');  
            date = nameparts{1};
            animalnum = nameparts{2};
            trial = nameparts{3};
        case 'EDGAR_2Panel'
            nameparts = regexp(name, '_','split');  
            date = nameparts{2};
            animalnum = nameparts{3};
            trial = nameparts{4};
        case 'EDGAR_Taxol'
            nameparts = regexp(name, '_','split');  
            date = nameparts{1};
            animalnum = nameparts{2};
            trial = nameparts{3};
         case 'EDGAR_ForeHindPairs_2Panel'
            nameparts = regexp(name, '_','split');  
            date = nameparts{2};
            animalnum = nameparts{3};
            trial = nameparts{4};
         case 'EDGAR_ForeHindPairs_4Panel'
            nameparts = regexp(name, '_','split');  
            date = nameparts{1};
            animalnum = nameparts{2};
            trial = nameparts{3};
            trial = trial(2:end); %possible fix for trial name write?
    end

    % Pull the body weight from the file name. 
    % In grams. -- Specific to EHL's data - edit for your data.
    % All animalnum are 'r##', so take last 2 digits in the string, 
    % and convert to a number.
    animalcolumn = str2double(animalnum(2:3));  
    
    %%% Delete this loop after Emily's MIA experiment is done!!
    if strcmp(setup,'EDGAR_2Panel') == 1 || strcmp(setup,'EDGAR_ForeHindPairs_2Panel') == 1
        % BW matrix has animalnum as t0he column.
        if animalcolumn < 37
            BWmatrix = [316 303 301 300 315 303 299 311 343 261 310 300 305 344 351 348 334 352 337 346 364 337 355 356 361 345 318 370 383 387 374 366 397 416 350 390];
            BW = BWmatrix(animalcolumn);  % The location in BWmatrix matches the animal number (animalcolumn)
        end
        if animalcolumn > 36  % animals greater than 36 were naive - they had multiple weeks.
            date = str2double(date);
            BWmatrix = [357 316 358 371 307 335; 391 340 402 409 331 357; 409 365 427 419 353 377];
            % then week 1 - which is row 1 in BWmatrix above
            if date < 20160407  
                BW = BWmatrix(1,animalcolumn-36);
            % then week 4 - which is row 3 in BWmatrix above
            elseif date > 20160418  
                BW = BWmatrix(3,animalcolumn-36);
            % then week 2 - which is row 2 in BWmatrix above
            else  
                BW = BWmatrix(2,animalcolumn-36);
            end
        end
        if animalcolumn == 43  % 43 was a do-over 2nd week animal.
            BW = 345;
        end    
    else
    % KEEP THIS LINE!!
    BW = BWmatrix(animalcolumn);  % The location in BWmatrix matches the animal number (animalcolumn)
    end
    % Call getforceEDGAR version
    % n is the number of files you clicked. For each file, run 
    % getforceEDGAR version.
    switch setup
        case 'EDGAR_4Panel'
            getforceEDGAR_4Panel(animalnum, name, n, filename, thresh, BW, date, path, batch); 
        case 'EDGAR_2Panel'
            getforceEDGAR_2Panel(animalnum, name, n, filename, thresh, BW, date, path, batch); 
        case 'EDGAR_Taxol'
            getforceEDGAR_Taxol(animalnum, name, n, filename, thresh, BW, date, path, batch);
        case 'EDGAR_ForeHindPairs_4Panel'
            getforceEDGAR_ForeHindPairs_4Panel(animalnum, name, n, filename, BW, date, path, batch);
        case 'EDGAR_ForeHindPairs_2Panel'
            getforceEDGAR_ForeHindPairs_2Panel(animalnum, name, n, filename, BW, date, path, batch);
    end
    
    if length(file) == 1
        break
    end
end

toc
fprintf ('COMPLETE  \n \n')
clear
