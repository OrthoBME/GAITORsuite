function [] = StepTracker2(Input)

Directory = uigetdir;
File = uipickfiles('FilterSpec',Directory,'Type',{'*.jpg','.jpg'});

FileCount = 1;
Finish = length(File);
TrialIDName = [];

load(Input)

while FileCount <= Finish
try 

A_real = Input.PlateBounds(1);    AB_real = Input.PlateBounds(2);
B_real = Input.PlateBounds(3);    C_real = Input.PlateBounds(4);
CD_real = Input.PlateBounds(5);   D_real = Input.PlateBounds(6);

ConcatenateVideos = Input.ConcatenateVideos;

File = cellstr(File);
Image = File{FileCount};

[~,TrialIDName,~] = fileparts(Image);
TrialIDName(TrialIDName == '.' ) = [];


Image_read = imread(Image);
[y_max x_max_scaled] = size(Image_read);

x_max = x_max_scaled/3;

forepaw = round(0.25*y_max);
mid = round(0.5*y_max);
hindpaw = round(0.75*y_max);

color1 = Image_read(forepaw,:,:);
color2 = Image_read(hindpaw,:,:);

start1 = find(color1 == 0,1,'first');
start2 = find(color2 == 0,1,'first');

% Transpose
color3 = fliplr(color1);
color4 = fliplr(color2);

end1 = x_max - find(color3 == 0,1,'first');
end2 = x_max - find(color4 == 0,1,'first');

width1 = end1 - start1;
width2 = end2 - start2;

if strcmp(ConcatenateVideos,'Y')
    real_width = 1280;
elseif strcmp(ConcatenateVideos,'N')
    real_width = 1408;
end

A_fore = start1 + (A_real/real_width)*width1;
AB_fore = start1 + (AB_real/real_width)*width1;
B_fore = start1 + (B_real/real_width)*width1;
C_fore = start1 + (C_real/real_width)*width1;
CD_fore = start1 + (CD_real/real_width)*width1;
D_fore = start1 + (D_real/real_width)*width1;

A_hind = start2 + (A_real/real_width)*width2;
AB_hind = start2 + (AB_real/real_width)*width2;
B_hind = start2 + (B_real/real_width)*width2;
C_hind = start2 + (C_real/real_width)*width2;
CD_hind = start2 + (CD_real/real_width)*width2;
D_hind = start2 + (D_real/real_width)*width2;

% Create line markers for force panel borders.
x_fore = [A_fore AB_fore B_fore C_fore CD_fore D_fore];
ystart_fore = [0 0 0 0 0 0];
yend_fore = [mid mid mid mid mid mid];

x_hind = [A_hind AB_hind B_hind C_hind CD_hind D_hind];
ystart_hind = [mid mid mid mid mid mid];
yend_hind = [y_max y_max y_max y_max y_max y_max];

imshow(Image_read);
hold on

for ix = 1:length(x_fore)
    line([x_fore(ix) x_fore(ix)],[ystart_fore(ix) yend_fore(ix)],'Color','white');
end

for ix = 1:length(x_hind)
    line([x_hind(ix) x_hind(ix)],[ystart_hind(ix) yend_hind(ix)],'Color','white');
end

PlotName = [TrialIDName,' Paw Print Tracker'];
title(PlotName,'Interpreter', 'none')

hold off


 Filename_PawTracker = [TrialIDName,'_PawTracker.jpg'];
 Fig = gcf;
 Fig.InvertHardcopy = 'off';
 saveas(gcf,Filename_PawTracker);

fprintf('Paw Images Saved. \n');

%% Prepare for Next File & Error Catch %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
% Don't try and look at file{2} if you only chose 1 file to begin with.
   if length(File) == 1
       break
   end
   close all;
catch MException
    ErrorLine = MException.stack.line;
    fprintf(['\nERROR encountered in ', TrialIDName, ' at Line: ', '%i', '\n'],ErrorLine);
    ErrorMessage = MException.message;
    disp(ErrorMessage);

    beep   

end
% Set filecount to address next file in batch.
FileCount = FileCount + 1;
end

close all 