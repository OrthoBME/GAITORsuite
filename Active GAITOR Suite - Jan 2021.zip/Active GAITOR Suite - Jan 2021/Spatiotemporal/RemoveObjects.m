% RemoveObjects.m
% Last Updated: March 1, 2017
% Emily H. Lakes & Brittany Y. Jacobs

% If you only need to delete FSTO objects, then use this code to delete the
% object number you do not want. 

clc; clear;
close all;

% Choose the _DATA.mat files that you want to edit from AGATHA.
files = uipickfiles;

for i = 1:length(files)
    current = load(files{i});
    [~,filename,~] = fileparts(files{i});
    disp(filename)
    Data = current.DATA.AGATHA;
    
    % Find the last object number and display it.  This will show how many
    % objects there are in the command window, in case you need to delete
    % all objects after x.  Since object numbers won't always
    % correspond to row numbers, the maximum object number is used.
    last = max(Data(:,1));
    disp(last);
    
    % Enter objects numbers as: 1 2 3 4.
    prompt = {'Enter Vector of Object #s to Remove'};
    dlg_title = 'Input';
    num_lines = 1;
    defaultans = {''};
    [answer] = inputdlg(prompt,dlg_title,num_lines,defaultans);

    vector = str2num(answer{1});
    data = Data;
    
    % Find the row that contains the chosen object number and delete it.
    for ii = 1:length(vector)
        deleterow = find(data(:,1) == vector(ii));
        data(deleterow,:) = [];
    end
    
    % Resave the edited _DATA.mat file. 
    AGATHA = data;
    Velocity = current.DATA.Velocity;
    filename_edit = [filename '_edit.mat'];
    DATA = struct('AGATHA',AGATHA,'Velocity',Velocity);
    save(filename_edit,'DATA');

    clearvars -except i files
    clc
end
