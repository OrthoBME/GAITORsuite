function [strikes,cali] = IDspikes_4Panel(channel, date, panelgroup)

panelgroup = panelgroup.panelgroup;
q2 = 'y';
while q2 == 'y' || 'Y';
    spikes = spike_times(abs(channel),0.5);  %0.5 is default threshold for spike_times function.
    x1 = spikes(1,:);
    y1 = spikes(2,:);
    title('Click ONCE on spikes you want to keep. ENTER when finished. No spikes - just ENTER');
    [x1 y1] = ginput;
    q2 = input('Do you need to rechoose the spikes? (Y/N)   ', 's');
    if q2 ~= 'y' || 'Y';
        break
    end
    continue  
end

check = isempty(x1);
if check == 1;
    fprintf('No Spikes Selected. \n');         
    strikes = 0;
    cali = 0;
    return
end

close ALL 

%%%%% ID Panel Steps       
    [r c] = size(spikes);
    diff = [];
    for i = 1:length(x1)
        for j = 1:c
            diff(j) = abs(spikes(1,j)-x1(i));
        end
        [rr cc] = find(diff==min(diff));
        S(:,i) = spikes(:,cc);
    end
    if exist('S')
        spikes = S;
    end
    
    check = 'y';
    while check == 'y'
        foot = [];
        panel = [];
        for i = 1:length(x1)
            figure
            hold on
            plot(channel,'k-')
            plot(spikes(1,i),spikes(2,i),'ro')
            xlabel('Matrix Index (not time)')
            ylabel('Voltage')
            title( ['Foot Strikes'])
            hold off
            q3 = input('Is this a LEFT or RIGHT foot strike? (L/R)  ','s');
                if q3 == 'L' || q3 == 'l'
                    foot(i) = 1;
                else
                    foot(i) = 0;
                end
            panelquestion = strcmp(panelgroup,'AC');
            if panelquestion == 1
                q4 = input('Which panel is this step on? (A/C)  ','s');
                panel(i) = q4;
                temp_panel = struct('panel',q4);
                [calibration] = findCali_4Panel(date,temp_panel);
                cali(i,1) = calibration.CalX;
                cali(i,2) = calibration.CalY;
                cali(i,3) = calibration.CalZ;
                cali(i,4) = calibration.CalXIntercept;
                cali(i,5) = calibration.CalYIntercept;
                cali(i,6) = calibration.CalZIntercept;
                               
            else
                q4 = input('Which panel is this step on? (B/D)  ','s');
                panel(i) = q4;
                temp_panel = struct('panel',q4);
                [calibration] = findCali_4Panel(date,temp_panel);
                cali(i,1) = calibration.CalX;
                cali(i,2) = calibration.CalY;
                cali(i,3) = calibration.CalZ;
                cali(i,4) = calibration.CalXIntercept;
                cali(i,5) = calibration.CalYIntercept;
                cali(i,6) = calibration.CalZIntercept;                               
            end
        check = input('Do you need to mark the foot again? (Y/N) ', 's');
    end
    if length(x1) == 0
        strikes(1:4,1) = 0;
    else
        strikes = spikes;
        strikes(3,:) = foot;
        strikes(4,:) = panel; 
    end
    end
end