function [FSTODataNew] = FSTOEditor(FSTORGB, Direction,TrialIDName)

FSTOEdit = FSTORGB;    
imshow(FSTORGB);
BoundsL = questdlg('Do you need to set new left bound?');
Comp = strcmp(BoundsL,'Yes');
if Comp == 1
    xlabel('Click your new left bound, then press Enter.');
    [x, y] = getpts;
    FSTOEdit(:,1:x(1),:) = 0;
    close all
    figure
    imshow(FSTOEdit)
end
BoundsR = questdlg('Do you need to set new right bound?');
Comp = strcmp(BoundsR,'Yes');
if Comp == 1
    xlabel('Click your new right bound, then press Enter.');
    [xx, yy] = getpts;
    FSTOEdit(:,xx(1):size(FSTOEdit,2),:) = 0;
    close all
    figure
    imshow(FSTOEdit)
end

Remove = questdlg('Do you need to remove any objects?');
Comp = strcmp(Remove,'Yes');
while Comp == 1
    RemoveObj = getrect;
    y = RemoveObj(1);
    x = RemoveObj(2);
    h = RemoveObj(3);
    w = RemoveObj(4);
    FSTOEdit(x:x+w,y:y+h,:) = 0;
    close all
    figure
    imshow(FSTOEdit)
    Remove = questdlg('Do you need to remove another object?');
    Comp = strcmp(Remove,'Yes');
end

Fill = questdlg('Do you need to fill any objects?');
Comp = strcmp(Fill,'Yes');
while Comp == 1
    RemoveObj = getrect;
    y = RemoveObj(1);
    x = RemoveObj(2);
    h = RemoveObj(3);
    w = RemoveObj(4);
    Obj = max(max(FSTOEdit(x:x+w,y:y+h,:)));
    FSTOEdit(x:x+w,y:y+h,:) = Obj;
    close all
    figure
    imshow(FSTOEdit)
    Fill = questdlg('Do you need to fill another object?');
    Comp = strcmp(Fill,'Yes');
end

Split = questdlg('Do you need to split any objects?');
Comp = strcmp(Split,'Yes');
while Comp == 1
    waitfor(msgbox('Draw a box around the object you want to split'));
    RemoveObj = getrect;
    y = RemoveObj(1);
    x = RemoveObj(2);
    h = RemoveObj(3);
    w = RemoveObj(4);
    range = FSTOEdit(x:x+w,y:y+h);
    hold on
    rectangle('Position',[y x h w],'EdgeColor','w');
    title('Click points to define a split line, then press Enter.');
    [xx, yy] = getpts;
    Fit = polyfit(xx,yy,1);
    Space = linspace(y,y+h);
    Line = Fit(1)*Space + Fit(2);
    for i = 1:length(Space)
        FSTOEdit(round(Line(i))-2:round(Line(i))+2,round(Space(i))-2:round(Space(i))+2,:) = 0;
    end
    close all 
    imshow(FSTOEdit)
    Split = questdlg('Do you need to split another object?');
    Comp = strcmp(Split,'Yes');
end



LabeledFSTO = bwlabel(FSTOEdit);
FSTOStats = regionprops(LabeledFSTO, 'Centroid', 'Extrema');
% Recreate Black & White FSTO Image.
for i = 1:max(max(LabeledFSTO))
    if Direction == 'L'
        FS = [FSTOStats(i).Extrema(2)-0.5,FSTOStats(i).Extrema(10)-0.5];
        TO = [FSTOStats(i).Extrema(6)-0.5,FSTOStats(i).Extrema(14)-0.5];
        ObjCent = [FSTOStats(i).Centroid(1),FSTOStats(i).Centroid(2)];
    else
        FS = [FSTOStats(i).Extrema(1)-0.5,FSTOStats(i).Extrema(9)-0.5];
        TO = [FSTOStats(i).Extrema(5)-0.5,FSTOStats(i).Extrema(13)-0.5];
        ObjCent = [FSTOStats(i).Centroid(1),FSTOStats(i).Centroid(2)];
    end
    FSTODataNew(i,:) = [i,0,FS,TO,ObjCent];
end

FSTODataNew = sortrows(FSTODataNew, 3);
RealFSTOObjs = find(FSTODataNew(:,3) > 0);
FSTODataNew = FSTODataNew(min(RealFSTOObjs):max(RealFSTOObjs),:);

% Define Fore and Hind Paws and Locate X Coordinate for Finding Paws.
FSTOObjCentroid(:,1:2) = FSTODataNew(:,7:8);
CentroidBetas = polyfit(FSTOObjCentroid(:,1),FSTOObjCentroid(:,2),1);
XSpace = linspace(1,size(LabeledFSTO,2));
CentroidLine = CentroidBetas(2)+CentroidBetas(1)*XSpace;

% Define Fore and Hind Paws.
BlueLabeledFSTO = LabeledFSTO;      RedLabeledFSTO = LabeledFSTO;
for i = 1:length(FSTODataNew(:,1))
    if FSTODataNew(i,7) ~= 0
        ObjResidual = FSTODataNew(i,8) - (CentroidBetas(2) + CentroidBetas(1)*FSTODataNew(i,7));
        if ObjResidual < 0
            FSTODataNew(i,2) = 1; % ForeLimb = 1
            BlueLabeledFSTO(BlueLabeledFSTO == FSTODataNew(i,1)) = 200;    
        else
            FSTODataNew(i,2) = 0; % HindLimb = 0
            RedLabeledFSTO(RedLabeledFSTO == FSTODataNew(i,1)) = 200;
        end
    end
end

% Create RGB version of FSTO Image.
FSTOOnes = ones(size(LabeledFSTO,1),size(LabeledFSTO,2));
FSTORGB = cat(3, RedLabeledFSTO, FSTOOnes, BlueLabeledFSTO);
FSTORGB = uint8(FSTORGB);
FSTORGB(FSTORGB ~= 200) = 0;

figure; imshow(FSTORGB);          
hold on

% Adjust number text position for visibility. If single digit (<10), adjust
% x-position by 4 & if double digit, adjust by 10 from centroid.
for i = 1:length(FSTODataNew(:,1))
    if FSTODataNew(i,1) < 10
        text(FSTODataNew(i,7)-4,FSTODataNew(i,8),int2str(FSTODataNew(i,1)), 'Color', 'white');
    else
        text(FSTODataNew(i,7)-10,FSTODataNew(i,8),int2str(FSTODataNew(i,1)), 'Color', 'white');
    end
    plot(FSTODataNew(i,3),FSTODataNew(i,4),'co');
    plot(FSTODataNew(i,5),FSTODataNew(i,6),'mo');
end 
plot(XSpace,CentroidLine,'yellow');
hold off

Filename_FSTO_Edit = [TrialIDName,'_FSTO_Edit.jpg'];
Fig = gcf;
Fig.InvertHardcopy = 'off';
saveas(gcf,Filename_FSTO_Edit);


close all



% end
% end
