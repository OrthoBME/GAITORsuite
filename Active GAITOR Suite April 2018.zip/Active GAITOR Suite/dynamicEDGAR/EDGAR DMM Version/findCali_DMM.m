function calibrations = findCali_DMM(date,panel)

% Find the date, and define the calibration constants based on the date.
% Specific to EHL's data. Definitely a clunky hard code - but it saved time
% for EHL processing the data.
% cal_X, cal_Y, and cal_Z = slope of calibration curve in v/g
% cal_Xint, cal_Yint, and cal_Zint = y-intercepts of the calibration curve
% in volts.

date = num2str(date);

comp = [];
comp(1) = strcmp(date,'20160613');
comp(2) = strcmp(date,'20160614');
comp(3) = strcmp(date,'20160627');
comp(4) = strcmp(date,'20160628');
comp(5) = strcmp(date,'20160629');
comp(6) = strcmp(date,'20160711');
comp(7) = strcmp(date,'20160712');
comp(8) = strcmp(date,'20160713');
comp(9) = strcmp(date,'20160725');
comp(10) = strcmp(date,'20160726');
comp(11) = strcmp(date,'20160727');
comp(12) = strcmp(date,'20160816');
comp(13) = strcmp(date,'20160817');
comp(14) = strcmp(date,'20160905');
comp(15) = strcmp(date,'20160907');
comp(16) = strcmp(date,'20160908');

loc = find(comp == 1);  % find where the dates matched -- look for the location of the 1.

if loc == 1
    if panel == 'A'
        cal_Z = 0.0042;
        cal_Zint = 0.003;
    elseif panel == 'B'
        cal_Z = 0.0044;
        cal_Zint = 0.0308;
    elseif panel == 'C'
        cal_Z = 0.0038;
        cal_Zint = 0.0343;
    elseif panel == 'D'
        cal_Z = 0.0043;
        cal_Zint = 0.0241;
    end
elseif loc == 2
    if panel == 'A'
        cal_Z = 0.0043;
        cal_Zint = -0.0129;
    elseif panel == 'B'
        cal_Z = 0.0044;
        cal_Zint = 0.0208;
    elseif panel == 'C'
        cal_Z = 0.0042;
        cal_Zint = -0.0105;
    elseif panel == 'D'
        cal_Z = 0.0044;
        cal_Zint = -0.0029;
    end
elseif loc == 3
    if panel == 'A'
        cal_Z = 0.0047;
        cal_Zint = -0.0075;
    elseif panel == 'B'
        cal_Z = 0.0044;
        cal_Zint = 0.0025;
    elseif panel == 'C'
        cal_Z = 0.0039;
        cal_Zint = 0.0172;
    elseif panel == 'D'
        cal_Z = 0.0043;
        cal_Zint = -0.0041;
    end
elseif loc == 4
    if panel == 'A'
        cal_Z = 0.0039;
        cal_Zint = 0.0337;
    elseif panel == 'B'
        cal_Z = 0.004;
        cal_Zint = 0.0048;
    elseif panel == 'C'
        cal_Z = 0.0042;
        cal_Zint = 0.0026;
    elseif panel == 'D'
        cal_Z = 0.0044;
        cal_Zint = -0.0025;
    end
elseif loc == 5
    if panel == 'A'
        cal_Z = 0.0047;
        cal_Zint = -0.0106;
    elseif panel == 'B'
        cal_Z = 0.0041;
        cal_Zint = 0.0241;
    elseif panel == 'C'
        cal_Z = 0.0043;
        cal_Zint = 0.0149;
    elseif panel == 'D'
        cal_Z = 0.0042;
        cal_Zint = 0.0193;
    end
elseif loc == 6
    if panel == 'A'
        cal_Z = 0.0045;
        cal_Zint = 0.003;
    elseif panel == 'B'
        cal_Z = 0.0043;
        cal_Zint = -0.0134;
    elseif panel == 'C'
        cal_Z = 0.0043;
        cal_Zint = -0.004;
    elseif panel == 'D'
        cal_Z = 0.0044;
        cal_Zint = 0.0018;
    end
elseif loc == 7
    if panel == 'A'
        cal_Z = 0.0044;
        cal_Zint = 0.0087;
    elseif panel == 'B'
        cal_Z = 0.0042;
        cal_Zint = 0.005;
    elseif panel == 'C'
        cal_Z = 0.0043;
        cal_Zint = -0.0045;
    elseif panel == 'D'
        cal_Z = 0.0057;
        cal_Zint = -0.0222;
    end
elseif loc == 8
    if panel == 'A'
        cal_Z = 0.0044;
        cal_Zint = 0.0087;
    elseif panel == 'B'
        cal_Z = 0.0042;
        cal_Zint = -0.0035;
    elseif panel == 'C'
        cal_Z = 0.0042;
        cal_Zint = 0.0008;
    elseif panel == 'D'
        cal_Z = 0.0045;
        cal_Zint = -0.0019;
    end
elseif loc == 9
    if panel == 'A'
        cal_Z = 0.0044;
        cal_Zint = 0.0018;
    elseif panel == 'B'
        cal_Z = 0.0042;
        cal_Zint = -0.0116;
    elseif panel == 'C'
        cal_Z = 0.0042;
        cal_Zint = 0.0066;
    elseif panel == 'D'
        cal_Z = 0.0044;
        cal_Zint = -0.0013;
    end
elseif loc == 10
    if panel == 'A'
        cal_Z = 0.0045;
        cal_Zint = -0.006;
    elseif panel == 'B'
        cal_Z = 0.0042;
        cal_Zint = -0.003;
    elseif panel == 'C'
        cal_Z = 0.0043;
        cal_Zint = -0.002;
    elseif panel == 'D'
        cal_Z = 0.0042;
        cal_Zint = 0.0182;
    end
elseif loc == 11
    if panel == 'A'
        cal_Z = 0.0044;
        cal_Zint = 0.0129;
    elseif panel == 'B'
        cal_Z = 0.0041;
        cal_Zint = 0.0048;
    elseif panel == 'C'
        cal_Z = 0.0044;
        cal_Zint = -0.0101;
    elseif panel == 'D'
        cal_Z = 0.0044;
        cal_Zint = 0.0053;
    end
elseif loc == 12
    if panel == 'A'
        cal_Z = 0.0044;
        cal_Zint = -0.0253;
    elseif panel == 'B'
        cal_Z = 0.004;
        cal_Zint = 0.0078;
    elseif panel == 'C'
        cal_Z = 0.0044;
        cal_Zint = -0.0168;
    elseif panel == 'D'
        cal_Z = 0.0045;
        cal_Zint = -0.0151;
    end
elseif loc == 13
    if panel == 'A'
        cal_Z = 0.0044;
        cal_Zint = 0.0115;
    elseif panel == 'B'
        cal_Z = 0.004;
        cal_Zint = 0.0034;
    elseif panel == 'C'
        cal_Z = 0.0043;
        cal_Zint = -0.0073;
    elseif panel == 'D'
        cal_Z = 0.0045;
        cal_Zint = -0.0054;
    end
elseif loc == 14
    if panel == 'A'
        cal_Z = 0.0042;
        cal_Zint = 0.003;
    elseif panel == 'B'
        cal_Z = 0.0044;
        cal_Zint = 0.0308;
    elseif panel == 'C'
        cal_Z = 0.0038;
        cal_Zint = 0.0343;
    elseif panel == 'D'
        cal_Z = 0.0043;
        cal_Zint = 0.0241;
    end
elseif loc == 15
    if panel == 'A'
        cal_Z = 0.0047;
        cal_Zint = -0.0086;
    elseif panel == 'B'
        cal_Z = 0.0039;
        cal_Zint = 0.0245;
    elseif panel == 'C'
        cal_Z = 0.0042;
        cal_Zint = -0.0016;
    elseif panel == 'D'
        cal_Z = 0.0045;
        cal_Zint = 0.0055;
    end
elseif loc == 16
    if panel == 'A'
        cal_Z = 0.0045;
        cal_Zint = -0.0073;
    elseif panel == 'B'
        cal_Z = 0.0042;
        cal_Zint = -0.0027;
    elseif panel == 'C'
        cal_Z = 0.0042;
        cal_Zint = -0.0031;
    elseif panel == 'D'
        cal_Z = 0.0044;
        cal_Zint = 0.0085;
    end
end

calibrations = [cal_Z, cal_Zint];