function [strikes,cali] = IDspikes_ForeHindPairs_4Panel(channel, date, panelgroup)

panelgroup = panelgroup.panelgroup;

plot(channel)
title('Click ONCE on the spikes you want to keep. ENTER when done. No spikes - just ENTER');
[SpikeX, SpikeY] = getpts;

check = isempty(SpikeX);
if check == 1
    fprintf('No Spikes Selected. \n');         
    strikes = 0;
    cali = 0;
    return
end

close ALL 

%%%%% ID Panel Steps  
check = 'y';
while check == 'y'
[r, ~] = size(SpikeX);    
foot = [];
panel = [];
for i = 1:r
    figure
    hold on
    plot(channel,'k-')
    plot(SpikeX(i),SpikeY(i),'ro')
    xlabel('Matrix Index (not time)')
    ylabel('Charge')
    title('Foot Strikes')
    hold off
    q3 = input('Is this a LEFT or RIGHT foot strike? (L/R)  ','s');
        if q3 == 'L' || q3 == 'l'
            foot(i) = 1;
        else
            foot(i) = 0;
        end
    panelquestion = strcmp(panelgroup,'AC');
    if panelquestion == 1
        q4 = input('Which panel is this step on? (A/C)  ','s');
        panel(i) = q4;
        temp_panel = struct('panel',q4);
        [calibration] = findCali_4Panel(date,temp_panel);
        cali(i,1) = calibration.CalX;
        cali(i,2) = calibration.CalY;
        cali(i,3) = calibration.CalZ;
        cali(i,4) = calibration.CalXIntercept;
        cali(i,5) = calibration.CalYIntercept;
        cali(i,6) = calibration.CalZIntercept;
        fprintf('\n\n');       
    else
        q4 = input('Which panel is this step on? (B/D)  ','s');
        panel(i) = q4;
        temp_panel = struct('panel',q4);
        [calibration] = findCali_4Panel(date,temp_panel);
        cali(i,1) = calibration.CalX;
        cali(i,2) = calibration.CalY;
        cali(i,3) = calibration.CalZ;
        cali(i,4) = calibration.CalXIntercept;
        cali(i,5) = calibration.CalYIntercept;
        cali(i,6) = calibration.CalZIntercept;  
        fprintf('\n\n');         
    end
  check = input('Do you need to mark the foot again? (Y/N) ', 's');
end 
if isempty(SpikeX) == 1
    strikes(1:3,1) = 0;
else
    strikes = SpikeX';
    strikes(2,:) = foot;
    strikes(3,:) = panel; 
end
end
end  % end for function