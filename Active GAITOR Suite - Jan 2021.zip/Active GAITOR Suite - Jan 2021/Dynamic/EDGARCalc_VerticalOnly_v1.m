%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  dynamicEDGAR_v2.m
%%%%%  EDGAR Dynamic Data Processing Interface
%%%%%  Rebuild by KDA on March 6, 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clearvars;
home;
close all

%% Prompts Warning Message
warning('EDGAR Calculator is designed to work with a single force plate calibration file and a single file of animal weights. Force plate calibrations and animal weights should be specific to the testing day. These files must also follow the required format. The naming convention of the files must also follow the required format, where animals are identified by a leading _R');

%% Select Curves to Analyze
[file,path] = uigetfile('*.mat','Find the Force-Curves to Import','MultiSelect', 'on');
file = cellstr(file); 

%% Get Animal Weights
% For the animal weight, you should have an Excel spreadsheet with the
% first column listing the animal ID and the second column listing the
% corresponding body weight. Note, the animal ID must match the animal ID
% in the name of the dynamic file. The animal ID's do not have to be listed
% in numerical order. 
[weightfile,weightpath] = uigetfile('*.xlsx','Find the Animal Weights to Import','MultiSelect', 'on');
[AnimalWeights_num,AnimalWeights_txt,AnimalWeights_raw] = xlsread(weightfile);

%% Get Force Plate Calibration File
% For the calibration values, you should have an Excel spreadsheet with the
% first column listing the force plate and the second column listing the
% corresponding calibration value to convert from voltage to grams. 
[calibrationfile,calibrationpath] = uigetfile('*.xlsx','Find the Calibration File to Import','MultiSelect', 'on');
[Calibration_num,Calibration_txt,Calibration_raw] = xlsread(calibrationfile);

% Requests user set a summary file name. -BYMJ
prompt = {'Output Filename?'};
dlg_title = 'Summary title';
num_lines = 1;
defaultans = {'EDGAR Summary_'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
OutputFilename = answer{1};

RawData = cell(length(file),6);
RawData(1,1) = {'Full Filename'};
RawData(1,2) = {'Animal ID'};
RawData(1,3) = {'Trial ID'};
RawData(1,4) = {'Fore or Hind Limb'};
RawData(1,5) = {'Force Plate Time Stamp (sec)'};
RawData(1,6) = {'Foot'};
RawData(1,7) = {'Body Weight'};
RawData(1,8) = {'Force Plate'};
RawData(1,9) = {'Force Plate Calibration Constant'};
RawData(1,10) = {'Peak Vertical Force (V)'};
RawData(1,11) = {'Vertical Impulse (V-sec)'};

for n=1:length(file)
    
    % lines for mouse (trials labeled R##)
    filename_string = char(file{n});
    id_rat = strfind(filename_string,'_R');
    AnimalID = filename_string(id_rat+1:id_rat+3);
    id_trial = strfind(filename_string,'_t');
    TrialID = filename_string(id_trial+1:id_trial+3);
    
    % lines for mouse (trials labeled M##)
    filename_string = char(file{n});
    id_rat = strfind(filename_string,'_M');
    AnimalID = filename_string(id_rat+1:id_rat+3);
    id_trial = strfind(filename_string,'_t');
    TrialID = filename_string(id_trial+1:id_trial+3);
    
    id_foot = strfind(filename_string,'_F');
    if isempty(id_foot)
        id_foot = strfind(filename_string,'_H');
    end
    HindForeID = filename_string(id_foot+1:id_foot+4);
    
    WeightID = find(strcmp(AnimalWeights_txt, AnimalID));
    BodyWeight = AnimalWeights_num(WeightID);
    
    filename = fullfile ( path, file{n} );
    load(filename);
    
    PVF = max(data(:,4));
    VImpulse = trapz(data(:,1),data(:,4));
    TimeStamp = data(1,1);
    
    if data(1,7) == 1
        Calibration = 'A';
        CalibrationConstant = Calibration_num(1);
    elseif data(1,7) == 2
        Calibration = 'B';
        CalibrationConstant = Calibration_num(2);
    elseif data(1,7) == 3
        Calibration = 'C';
        CalibrationConstant = Calibration_num(3);
    else
        Calibration = 'D';
        CalibrationConstant = Calibration_num(4);
    end
    
    if data(1,6) == 1
        RightLeft = 'Right';
    else
        RightLeft = 'Left';
    end
    
    RawData(n+1,1) = {filename_string};
    RawData(n+1,2) = {AnimalID};
    RawData(n+1,3) = {TrialID};
    RawData(n+1,4) = {HindForeID};
    RawData(n+1,5) = {TimeStamp};
    RawData(n+1,6) = {RightLeft};
    RawData(n+1,7) = {BodyWeight};
    RawData(n+1,8) = {Calibration};
    RawData(n+1,9) = {CalibrationConstant};
    RawData(n+1,10) = {PVF};
    RawData(n+1,11) = {VImpulse};
    
end

% Open RawData and copy into an Excel spreadsheet