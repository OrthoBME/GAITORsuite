%% ReduceFPS.m
% April 17, 2017
% Emily H. Lakes

% This code was originally made for taking 1000fps videos and sampling them
% down to 250fps for hand digitization.  Code can be used to resample any
% video to a lower fps.  Requires .avi's.
% Note: Most of the video read in and setup of this code was taken from
% AGATHA 2.0 on 4/17/17.

%% Start New Code
clear;  clc;
close all;

% User can select videos to sample. 
Directory = uigetdir;
File = uipickfiles('FilterSpec',Directory,'Type',{'*.avi' '.avi'});

% Ask user the current frame rate and the desired frame rate. 
prompt = {'Current FPS:','Desired FPS:'};
dlg_title = 'FPS Input';
num_lines = 1;
defaultans = {'1000','250'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
CurrentFPS = str2double(answer{1});
DesiredFPS = str2double(answer{2});
FPSRatio = CurrentFPS/DesiredFPS;

% Select the videos you want to run.
% Sets up counters for error and file tracker for batch.
ErrorCount = 1;
FileCount = 1;
Finish = length(File);
ErrVids = [];
TrialIDName = [];

while FileCount <= Finish
try
close all

% This is needed for the multiselect.  Always put the file in this format.
File = cellstr(File); 

% VideoName - use the full root for best results.
VideoName = File{FileCount};

% Break up filename into path, name, and extension.
% TrialIDName - Files associated with this run will be saved with this 
% label. You can set this to be part of the video name, but then videos 
% need to be saved with a very consistent labeling pattern.  
% Running batches, it's typically easier to pass a label.
% Here, we pull TrialIDName from the filename. 
[~,TrialIDName,~] = fileparts(VideoName); 
TrialIDName(TrialIDName == '.' ) = [];

close all
disp(['ReduceFPS Running -- ',TrialIDName]);

% This section looks to see if the target video is even in the MATLAB root 
% directory, then makes mock-up names if the video was split into multiple 
% files (something that can happen with certain high-speed settings).  
% Most of the time only 1 video exists, so the last case is the only 
% condition that exists, a simple video read (i.e. if only 1 video exists 
% per trial, only v1 will be used).  If up to 5 files are used to save a 
% certain video, this section of code will concatenate this 5 videos 
% together into a single file.
clear Video
disp (' ');
disp('Loading video... 1-2 minutes processing time');
if exist('VideoName','var')
    v1 = VideoName;
    VideoName(end-4) = '1';
    v2 = VideoName;
    VideoName(end-4) = '2';
    v3 = VideoName;
    VideoName(end-4) = '3';
    v4 = VideoName;
    VideoName(end-4) = '4';
    v5 = VideoName;
else
    disp('Error - Video does not exist within the directory');
end
if exist(v5,'file')
    v1 = VideoReader(v1);
    v2 = VideoReader(v2);
    v3 = VideoReader(v3);
    v4 = VideoReader(v4);
    v5 = VideoReader(v5);
    Vid1 = read(v1);
    Vid2 = read(v2);
    Vid3 = read(v3);
    Vid4 = read(v4);
    Vid5 = read(v5);
    Video = cat(4,Vid1,Vid2,Vid3,Vid4,Vid5);
elseif exist(v4,'file')
    v1 = VideoReader(v1);
    v2 = VideoReader(v2);
    v3 = VideoReader(v3);
    v4 = VideoReader(v4);
    Vid1 = read(v1);
    Vid2 = read(v2);
    Vid3 = read(v3);
    Vid4 = read(v4);
    Video = cat(4,Vid1,Vid2,Vid3,Vid4);
elseif exist(v3,'file')
    v1 = VideoReader(v1);
    v2 = VideoReader(v2);
    v3 = VideoReader(v3);
    Vid1 = read(v1);
    Vid2 = read(v2);
    Vid3 = read(v3);
    Video = cat(4,Vid1,Vid2,Vid3);
elseif exist(v2,'file')
    v1 = VideoReader(v1);
    v2 = VideoReader(v2);
    Vid1 = read(v1);
    Vid2 = read(v2);
    Video = cat(4,Vid1,Vid2);
else
    v1 = VideoReader(v1);  
    Video = read(v1);
end

% Video is now stored in the variable Video, so we clear the workspace 
% of large, unnecessary variables
clear v1 v2 v3 v4 v5 Vid1 Vid2 Vid3 Vid4 Vid5
disp('Video Loaded');
disp(' ');

% ZMAX is the height of the video (1280 x 1080 video will have a ZMAX of 1080).
% XMAX is the height of the video (1280 x 1080 video will have a XMAX of 1280).
% colorchannel is not used.
% FrameMAX is the number of frames in the video.
[ZMax, XMax, ~, FrameMax] = size(Video);

% Sample frames based on current and desired fps (defined above).
disp('Resampling Video...');
FrameCounter = 1;
for ii = 1:FPSRatio:FrameMax
    ReducedVideo(:,:,:,FrameCounter) = Video(:,:,:,ii);
    FrameCounter = FrameCounter + 1;
end

v = VideoWriter([TrialIDName,'_',num2str(DesiredFPS),'fps.avi'],'Uncompressed AVI');
open(v);
writeVideo(v,ReducedVideo);
close(v);
disp([TrialIDName, ' Complete!']);
disp('-----------------------');
disp('');

% If there is an error, display to command window and move on to the next. 
catch MException
    ErrorLine = MException.stack.line;
    fprintf(['\nERROR encountered in ', TrialIDName, ' at Line: ', '%i', '\n'],ErrorLine);
    ErrorMessage = MException.message;
    disp(ErrorMessage);
    
    ErrVids{ErrorCount,1} = TrialIDName;
    ErrVids{ErrorCount,2} = ErrorLine;
    ErrVids{ErrorCount,3} = ErrorMessage;
    
    ErrorCount = ErrorCount + 1;
    FileCount = FileCount + 1;
    beep 
end
FileCount = FileCount + 1;
end
