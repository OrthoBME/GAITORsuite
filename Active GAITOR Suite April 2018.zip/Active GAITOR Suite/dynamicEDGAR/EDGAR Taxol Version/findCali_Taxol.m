function calibrations = findCali_Taxol(date,panel)

% Find the date, and define the calibration constants based on the date.
% Specific to EHL's data. Definitely a clunky hard code - but it saved time
% for EHL processing the data.
% cal_X, cal_Y, and cal_Z = slope of calibration curve in v/g
% cal_Xint, cal_Yint, and cal_Zint = y-intercepts of the calibration curve
% in volts.

date = num2str(date);

comp = [];
comp(1) = strcmp(date,'20160824');
comp(2) = strcmp(date,'20160825');
loc = find(comp == 1);  % find where the dates matched -- look for the location of the 1.

if loc == 1
    if panel == 'A'
        cal_Z = 0.004702;
        cal_Zint = -0.01995;
    elseif panel == 'B'
        cal_Z = 0.0042;
        cal_Zint = 0.00191;
    elseif panel == 'C'
        cal_Z = 0.003988;
        cal_Zint = 0.008044;
    elseif panel == 'D'
        cal_Z = 0.004587;
        cal_Zint = -0.01263;
    end
elseif loc == 2
    if panel == 'A'
        cal_Z = 0.00484;
        cal_Zint = -0.04876;
    elseif panel == 'B'
        cal_Z = 0.004063;
        cal_Zint = 0.003525;
    elseif panel == 'C'
        cal_Z = 0.004204;
        cal_Zint = 0.011645;
    elseif panel == 'D'
        cal_Z = 0.004636;
        cal_Zint = -0.00828;
    end
end

calibrations = [cal_Z, cal_Zint];