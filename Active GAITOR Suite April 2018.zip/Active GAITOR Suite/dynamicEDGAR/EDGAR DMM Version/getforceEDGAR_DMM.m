function getforceEDGAR_DMM(animalnum, group, gender, name, trial, filename, BW, date, batch)
                           

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SECTION TO RUN CODE AS SCRIPT INSTEAD OF FUNCTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % Uncomment lines 9-17 to run as a script.  Also, comment line 1 and
% % the very last 'end' in this file.
% clear all
% animalnum = '0';
% group = 'DMM';
% gender = 'F';
% trial = '1';
% filename = 'F:\20160712\20160712_DMM_F_0_t01.tdms';
% BW = 25;
% date = '20160712';
% name = 'TESTER';
% batch = 'TESTER.xls';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  EDGAR DYNAMIC PROCESSING CODE
%%%%%  Edited from getforce (HEK) by BYMJ 12-12-14 
%%%%%  Edited into getforceEDGAR_EHL 9-2016 for multi-component set-up
%%%%%  Last Edited: 11/29/16 EHL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% USER INPUTS
% animalnum = Desired Animal ID  (e.g. '1')
% name = Name of the trial
% trial = Trial number (e.g. '1') 
% file = Complete file location path
% thresh = Step threshold (default = 0)
% BW = Body weight of animal in grams
% date = Date of trial (e.g. '20160314')
% path = Complete file location path

% NOTES                   % EHL's DATA CHANNELS:
% 1 = LEFT FOOT           % [time Z1 Z2 Z3 Z4 X13 X24 Y12 Y34]
% 0 = RIGHT FOOT

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  READ FILE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Convert the .tdms file from Labview into .mat file & load into workspace.
% IF you want to convert within the code (see dynamicEDGAR_EHL2), then
% uncomment the following line: 
matFile = simpleConvertTDMS(filename,1); 

fprintf('Loading... %s \n',name);

% use this line if converting from .tdms within code:
load(matFile{1});

% use this line if loading previously converted files:
% load(filename);

% Convert function is from MathWorks. EHL made no edits to it.  It converts 
% the .tdms file from Labview directly into a .mat file for MatLab. This 
% removes the step of converting files to excel before importing them 
% into Matlab. 

% Pull out variables from the structure and name them appropriately. 
% 16/17: EHL had to add "Untitled" to each variable because she switched
% from loading tdms files to mat files.  For some reason, the mat files
% come in with "Untitled".

%%% BYMJ 1/6/17: labview files structured as follows:
%%%     0: ACZ - VF Untitled.Data
%%%     1: ACX - MLF (this code's y) Untitled1.Data
%%%     2: ACY - BPF (This code's x) Untitled2.Data
%%%     3: BDZ - VF Untitled3.Data
%%%     4: BDX - MLF (this code's y) Untitled4.Data
%%%     6: BDY - BPF (This code's x) Untitled5.Data

% Sometimes the time variable loads as and "UntitledTime" struct instead of
% just "Time". Check your variable name here when troubleshooting.
time = Time.Data(100:end);
AZ = Untitled.Data(100:end);
BZ = Untitled1.Data(100:end);
CZ = Untitled2.Data(100:end);
DZ = Untitled3.Data(100:end);

% Now that we have the variables named appropriately, we can clear the
% original names to keep the workspace clean. 
clear Time Untitled Untitled1 Untitled2 Untitled3

% Put variables into a matrix called "data".  This is to match the code
% that Brittany/Heidi wrote.
data = [time AZ BZ CZ DZ];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  DRIFT COMPENSATION
%%%%%  This is from Heidi/Brittany code. EHL did not change this portion, 
%%%%%  other than trying to add comments.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find row 'r', column 'c', and depth 'd' dimensions of the matrix 'data'.
[datr, ~, ~] = size(data);

% Crop the data to remove obviously excess portions. This is important for
% data collected with a pre-trigger. If you click several times but the
% animal didn't walk, then you may have a bunch of data at the beginning
% that is essentially "zero".  This will look for where there is an actual
% change in data (presumably where the animal actually walked), and crop
% your data matrix to only this portion.  If you use the post-trigger, this
% part is not necessay - but it doesn't hurt anything to keep it in the
% code. -EHL comments after talking to BYMJ on 11/29/16.

% Convert time index to time (s) if necessary
% sampling rate is 2500 Hz
adjust = data(2,1) - data(1,1);
if adjust == 1
    data(:,1) = data(:,1)/2500;
end

% For the number of rows down to 2 (start at the end time point of the 
% trial). This assumed your "real" data is near the end of the trial 
% (because you would stop recording after you get a good one).
j = 1;
for i = datr:-1:2      
    if j == 1
        % Take the difference between adjacent rows, in column 1 
        % (time index is in column 1).
        if (data(i,1)-data(i-1,1)) > .0006 
            % When there is a big shift between time points, it crops it 
            % to keep only the last portion. 
            Data = data(i:end,:);   
            j = 0;
        elseif i == 2
            Data = data;
        end
    end
end

% Define dimensions of new matrix 'Data'. (row, column, depth)
[datr, datc, ~] = size(Data);  

q = 'y';
check = strcmp(q,'y');
while check == 1
    % Normalizing Channels based on a complex curve fit of the baseline data.
    % This is based on the bf.m function, which BYMJ found.
    D(:,1) = Data(:,1);
    % Look at the columns in 'Data' matrix, but don't look at "time" in first 
    % column.  i.e. data = [time Z1 Z2 Z3 Z4 X13 X24 Y12 Y34]
    for j = 2:datc  
        
        % If there is a segment of zeros that are disrupting the scale of
        % the data, set them to the previous nonzero value of the channel.
        % Could alter this to simply shift data up.
        startzero = find(~Data(:,j),1,'first');
        endzero = find(~Data(:,j),1,'last');
        diffzero = endzero - startzero;
        if diffzero > 50
            Data(startzero:endzero,j) = Data(startzero-1,j);
        end    
        
        % Find baseline for each channel.  See the bf.m function code.
        [~,yfit] = bf(Data(:,j),100); 
              
        figure
        hold on
        plot (Data(:,j),'r');
        plot (yfit,'b');
        pause
             
        % Re-zero all data by subtracting baseline from each channel.
        for i = 1:datr
            D(i,j) = (Data(i,j)-yfit(i));  % yfit is the baseline curve fit.
        end
    end
    pause(1)
    q = input('Do you need to redo the baseline? (Y/N)    ','s');
    check = strcmp(q,'y');  
end
close ALL
clear check q

% Lowpass filter, 25 Hz  (this filter originated from Heidi's code)
for i = 2:datc
    fNorm = 10/(2500/2); % 25 Hz cutoff, fs = 2500 Hz
    [B, A] = butter(4, fNorm, 'low'); 
    D(:,i) = filtfilt(B, A, D(:,i));   
    
    % Now, the filtered data is in "D". So use D from this point on!
end

% Redefine channels with "D" from above. 
AZ_filtered = D(:,2);       
BZ_filtered = D(:,3);      
CZ_filtered = D(:,4);       
DZ_filtered = D(:,5); 
                     
% Clean up workspace.
clear A B  % Don't need these.  Only used for the filter above. 
clear datc datd datr data Data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  FIND STEPS (SPIKES) & SAVE CALIBRATION DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for shift = 1:4
    
    % runs both panel sets
    if shift == 1
        Z_filtered = AZ_filtered;
        panelgroup = 'A';
    elseif shift == 2
        clear Z_filtered set
        Z_filtered = BZ_filtered;
        panelgroup = 'B';
    elseif shift == 3
        clear Z_filtered set
        Z_filtered = CZ_filtered;
        panelgroup = 'C';
    elseif shift == 4
        clear Z_filtered set
        Z_filtered = DZ_filtered;
        panelgroup = 'D';
    else
        fprintf('Error shifting between panels')
    end
    
[Zstrikes, calibration] = IDspikes_DMM(Z_filtered, date, panelgroup);  % See IDspikes.m code. 

% Separate the "calibration" variable from above.  This will prevent 
% confusion later on. cal_X = calibration constant in X (slope in uC/g) and 
% cal_Xint = y-intercept in X (in uC).  Again, the calibration function is
% unique to EHL's data - but you can edit this to match your case. 
if calibration ~= 0
    cal_Z = calibration(:,1);            cal_Zint = calibration(:,2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  ISOLATE EACH FOOT STEP (SPIKE)
%%%%%  This is from Heidi/Brittany code. EHL did not change this portion, 
%%%%%  other than trying to add comments.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
warning('off','all')

% Make sure there were spikes selected.  If no spikes, then skip to end.
if Zstrikes(1,1) ~= 0  % allZstrikes is output from IDspikes function above
    [~, c] = size(Zstrikes);   
    %r = # of rows (not used), c = # of columns, which is # of spikes kept
    
    for i = 1:c  % START LOOP for each step we saved for this trial/file.
        step_number = i; % This is for xlswrite1 at the end to avoid 
        % confusion. By the time we get down there, we forget what i was. 
        % We still use i for the index value in this loop. 
        % Define "foot" as left/right instead of 1/0.
        foot_num = Zstrikes(2,i);
        if foot_num == 1
            foot = 'Left';
        else
            foot = 'Right';
        end 
        
        % Distance number is not critical. Just a buffer to take +/- around
        % the spikes to get the whole step. Can change this. 
        distance = 1500;   
        % Take first spike and take +/-distance from the peak of the spike
        range = (Zstrikes(1,i) - distance):(Zstrikes(1,i) + distance);  
        % Only keep positive numbers (if -1000 makes it dip negative).
        range = range(range>0);        
        % Only keep numbers in original range (don't go beyond total
        % length).
        range = range(range<length(D));
        % Find where Z goes above the threshold within this range
                
        % Z curve based on current panel set BYMJ
        Zcurve = Z_filtered(range(1):range(end));      
        
        % Re-zero force curves after summing individual components
        Zcurve = Zcurve-Zcurve(1);
        
        % Calibrate force curves so they are in %BW.  
        %                       y = mx + b
        % Where:
        %        y = measured charge         m = slope in uC/g, 
        %  x = measured grams (what we want)      b = y-intercept in uC. 
        % To get the measured grams, we rearrange the equation to:
        %                       x = (y-b)/m
        %  OR measured grams = (measured charge - y intercept)/slope (uC/g)
        % Applying this to the impulse calculation, we get a converted sum
        % that is now grams*time index.
        
        Zcurve_BW = ((Zcurve - cal_Zint(i))/cal_Z(i)) / BW * 100;
      
        % Turn time vector into seconds (starts as just an index).
        % Divide by 2500 Hz collection frequency to get seconds.
        Time_index = 1:length(Zcurve_BW);
        Time = Time_index/2500*1000;  % change to milliseconds 
                
        % EHL did not change this code - but added the following comments.
        % Check that BPcurve is going the right direction.  Braking
        % (negative) forces should occure first, followed by propulsive
        % (positive) forces. This section finds the location and value of
        % the maximum swave number, and compares it to the location of the
        % maxiumum peak vertical force (Z).  This isn't a perfect filter,
        % but EHL assumes the idea is that the maximum BPcurve point should
        % occur after the maximum vertical point. Therefore, this loop
        % checks for the location of the max BPcurve to be less than the
        % location of the max vertical curve... if it is, then the BPcurve
        % needs flipped. 
        % Note: unit conversion for this portion does not matter, as long
        % as the units on the BP and Z max locations are the same.
        % Technically, the units for BPcurve_Max_X is a time index (where
        % in the array the maximum occurs).  
      
        % Plot data - NOW IN %BW & MILLISECONDS
        figure
        hold on
        plot(Time, Zcurve_BW, 'b')
        title (['Z ' panelgroup])
        % Below changes the position of the plot on your computer monitor.  
        % EHL wanted plots to show up on the second monitor and keep the 
        % Matlab screen clear. You can mess around with your resolution to
        % get them to pop up where you want. 
        set(gcf,'position',[-1100 100 1000 750])  
        % Makes background of the plot white instead of gray. 
        set(gcf,'color','w'); 
      
        disp('Choose LEFT boundary   ')
        [minx, ~] = ginput(1);
        % This is why EHL changed to milliseconds.  
        % Couldn't threshold with values <1.
        minx_index = find(Time > minx);  
        minX = minx_index(1);
        disp('Choose RIGHT boundary   ')
        [maxx, ~] = ginput(1);
        maxx_index = find(Time > maxx);
        maxX = maxx_index(1);

        % Safegaurd for if you click a boundary outside the matrix
        % dimensions. -EHL
        t = 1:1:length(Zcurve_BW);  
        if minX < t(1)
            minX = t(1);
        end
        if maxX > t(end)
            maxX = t(end);
        end

        range = minX:maxX;  % Redefine curves with new range.
        Zcurve_BW = Zcurve_BW(range);
        Time = Time(range);
        
        % 1/5/16 EHL: rezero at this point based on the last point.  
        % Majority of trials will have the hind foot be the last to touch. 
        % Therefore, rezero by the last point (when no weight on plate anymore). 
        % This helps because in most cases there is a forepaw
        % followed by a hindpaw, creating 2 consecutive peaks, with no dip
        % back down to zero in between.  But, we only care about the second
        % hind foot peak.         
        Time = Time - Time(1);
        ReZero = input('Rezero from first or last point? (1/0)   ');
%         ReZero = str2num(ReZero);
        if ReZero == 1
            Zcurve_BW = Zcurve_BW - Zcurve_BW(1);
        else
            Zcurve_BW = Zcurve_BW - Zcurve_BW(end);
        end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  PLOT DATA & CORRECT INCOMPLETE CURVES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Replot data - IN %BW & INDEX            
        figure
        hold on
        plot(Zcurve_BW, 'b')
        legend('Blue: Z', 'Location','northoutside','Orientation','horizontal')
        set(gcf,'position',[-1100 100 1000 750])
        set(gcf,'color','w');   
        
        CorrectNeeded = input('Does this curve need corrected?  (Y/N)','s');
        if strcmp(CorrectNeeded,'Y') || strcmp(CorrectNeeded,'y')
            CurrentCurve = Zcurve_BW;
            if CurrentCurve(1) > 0.15*max(CurrentCurve) 
                MaxLocation = find(CurrentCurve == max(CurrentCurve));
                if MaxLocation > 10
                    CurrentGradient = gradient(CurrentCurve(1:MaxLocation));
                    MaxSlope = max(CurrentGradient);
                    IndexShift = ceil(CurrentCurve(1)/MaxSlope);
                    for x = 1:IndexShift
                        NewCurve(x,1) = MaxSlope*x;
                    end
                    NewCurve(IndexShift+1:size(CurrentCurve,1)+IndexShift,1) = CurrentCurve;
                end
                clearvars CurrentCurve MaxLocation CurrentGradient MaxSlope IndexShift x
            elseif CurrentCurve(end) > 0.15*max(CurrentCurve)
                MaxLocation = find(CurrentCurve == max(CurrentCurve));
                if MaxLocation < (size(CurrentCurve,1) - 10)
                    CurrentGradient = gradient(CurrentCurve(MaxLocation:end));
                    MaxSlope = min(CurrentGradient);
                    YIntercept = CurrentCurve(end) - MaxSlope*size(CurrentCurve,1);
                    IndexShift = ceil(-YIntercept/MaxSlope);
                    for x = size(CurrentCurve,1):IndexShift
                        NewCurve(x,1) = MaxSlope*x + YIntercept;
                    end
                    for q = 1:size(CurrentCurve,1)
                        NewCurve(q,1) = CurrentCurve(q);
                    end
                end
                clearvars CurrentCurve MaxLocation CurrentGradient MaxSlope YIntercept IndexShift x q
            else
                NewCurve = CurrentCurve;  
                clearvars CurrentCurve
            end
        Zcurve_BW = NewCurve;
        NewTime_index = 1:length(Zcurve_BW);
        Time = NewTime_index/2500*1000;  % change to milliseconds 
        disp('   Curves have been corrected.');
        end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  PLOT DATA & FIND PEAKS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Find the maxima of the curve - these should be your forelimb PVF
        % and your hindlimb PVF.  Plot these points on the Z curve for
        % visualization. 
        [ForeHindPeaks,ForeHindLocations] = findpeaks(Zcurve_BW,Time,'MinPeakDistance',50);
        ForeHindLocations = ForeHindLocations';
        figure
        hold on
        plot(Time,Zcurve_BW, 'b')
        for ii = 1:length(ForeHindPeaks)
            plot(ForeHindLocations(ii), ForeHindPeaks(ii),'ko')
            hold on
        end
        
        % Just in case there are peaks you don't want, here you can remove
        % them. 
        PeakNumber = input('Remove Peaks? Type peak # or [# #] or enter for none.   ');
        if isempty(PeakNumber) == 0
            for ii = 1:length(PeakNumber)
                ForeHindPeaks(PeakNumber(ii),:) = 0;
                ForeHindLocations(PeakNumber(ii),:) = 0;
            end
            ForeHindPeaks(ForeHindPeaks == 0) = [];
            ForeHindLocations(ForeHindLocations == 0) = [];
        end
        
        % If there were no peaks, or they were all deleted, don't move forward. 
        if isempty(ForeHindPeaks) == 1
            return
        end
        close all  
        
        % If only one peak, define if fore or hind. Change definition of
        % 'foot' to reflect this. 
        if length(ForeHindPeaks) == 1
            WhichFoot = input('Fore or Hind? (F/H)    ','s');
            if WhichFoot == 'F' || WhichFoot == 'f'
                foot = ['Fore_' foot];
            else
                foot = ['Hind_' foot];
            end
        end
        
        % If you have a fore and hind peak, find the
        % minima between these points to get the "transition" point. 
        if length(ForeHindPeaks) == 2
            TransitionRegion = Zcurve_BW(floor(ForeHindLocations(1)/0.4):floor(ForeHindLocations(2)/0.4));
            TimeRegion = Time(floor(ForeHindLocations(1)/0.4):floor(ForeHindLocations(2)/0.4));
            % To find the minima, take the negative of the curve, and use
            % findpeaks again (like we did above for maxima). 
            [ForeHindTransition,TransitionLocation] = findpeaks(-TransitionRegion,TimeRegion,'SortStr','descend');
        else
            ForeHindTransition = 0;
            TransitionLocation = 0;
        end
        
        % Check for multiple minimum points. 
        if length(ForeHindTransition) > 1
            % Sorted above by descending order - so remove anything after
            % the first one.
            ForeHindTransition = ForeHindTransition(1);
            TransitionLocation = TransitionLocation(1);
        end
        
        % Replot data - Still in %BW & ms           
        figure
        hold on
        plot(Time,Zcurve_BW, 'b')
        % Plot as many points as there are. 
        for ii = 1:length(ForeHindPeaks)
            plot(ForeHindLocations(ii), ForeHindPeaks(ii),'ko')
            hold on
        end
        plot(TransitionLocation(1),-ForeHindTransition(1),'k*')
        hold on
        set(gcf,'position',[-1100 100 1000 750])
        set(gcf,'color','w');
        title([name num2str(step_number) foot]);
        
        qq = input('Do you want to throw out the step? (Y/N) ','s');
        if qq == 'y' || qq == 'Y'
            ThrowOut = 'Yes';
        else
            if exist([name '_' panelgroup '_' foot '.jpg'],'file')
                saveas(gcf,[name '_' panelgroup '_' foot '_REDO' '.jpg']);
            else
                saveas(gcf,[name '_' panelgroup '_' foot '.jpg']);
            end
            ThrowOut = 'No';
        end
        close ALL

        
        if strcmp(ThrowOut,'No')
        % If you have a ForeHind pair - then split them apart, correct the
        % curves, and calculate fore/hind parameters as if they were
        % isolated. 
        if length(ForeHindPeaks) == 2
            ForeCurveSplit = Zcurve_BW(1:round(TransitionLocation*2500/1000)-15);
            CurrentCurve = ForeCurveSplit;
            if CurrentCurve(end) > 0.15*max(CurrentCurve)
                MaxLocation = find(CurrentCurve == max(CurrentCurve));
                if MaxLocation < (size(CurrentCurve,1) - 10)
                    CurrentGradient = gradient(CurrentCurve(MaxLocation:end));
                    MaxSlope = min(CurrentGradient);
                    YIntercept = CurrentCurve(end) - MaxSlope*size(CurrentCurve,1);
                    IndexShift = ceil(-YIntercept/MaxSlope);
                    for q = 1:size(CurrentCurve,1)
                        NewCurve(q,1) = CurrentCurve(q);
                    end
                    for x = size(CurrentCurve,1):IndexShift
                        NewCurve(x,1) = MaxSlope*x + YIntercept;
                    end
                    ForeCurveSplit = NewCurve;
                    ForeTime_index = 1:length(ForeCurveSplit);
                    ForeTimeSplit = ForeTime_index/2500*1000;  % change to milliseconds 
                    clearvars CurrentCurve MaxLocation CurrentGradient MaxSlope YIntercept IndexShift x q ForeTime_index NewCurve
                end
            else
                ForeCurveSplit = CurrentCurve;
                ForeTime_index = 1:length(ForeCurveSplit);
                ForeTimeSplit = ForeTime_index/2500*1000;  % change to milliseconds 
                clearvars CurrentCurve ForeTime_index
            end
           
            HindCurveSplit = Zcurve_BW(round(TransitionLocation*2500/1000)+15:end);
            CurrentCurve = HindCurveSplit;
            if CurrentCurve(1) > 0.15*max(CurrentCurve) 
                MaxLocation = find(CurrentCurve == max(CurrentCurve));
                if MaxLocation > 10
                    CurrentGradient = gradient(CurrentCurve(1:MaxLocation));
                    MaxSlope = max(CurrentGradient);
                    IndexShift = ceil(CurrentCurve(1)/MaxSlope);
                    for x = 1:IndexShift
                        NewCurve(x,1) = MaxSlope*x;
                    end
                    NewCurve(IndexShift+1:size(CurrentCurve,1)+IndexShift,1) = CurrentCurve;
                end
                HindCurveSplit = NewCurve;
                HindTime_index = 1:length(HindCurveSplit);
                HindTimeSplit = HindTime_index/2500*1000;  % change to milliseconds 
                clearvars CurrentCurve MaxLocation CurrentGradient MaxSlope IndexShift x HindTime_index NewCurve
            else
                HindCurveSplit = CurrentCurve;  
                HindTime_index = 1:length(HindCurveSplit);
                HindTimeSplit = HindTime_index/2500*1000;  % change to milliseconds 
                clearvars CurrentCurve HindTime_index
            end
            disp('   ForeHind Pair has been split and corrected.'); 
            % Replot data - Still in %BW & ms           
            figure
            hold on
            plot(Time, Zcurve_BW, 'b')
            plot(ForeTimeSplit,ForeCurveSplit, 'g')
            plot(HindTimeSplit,HindCurveSplit, 'r')
            % Plot as many points as there are. 
            for ii = 1:length(ForeHindPeaks)
                plot(ForeHindLocations(ii), ForeHindPeaks(ii),'ko')
                hold on
            end
            plot(TransitionLocation(1),-ForeHindTransition(1),'k*')
            hold on
            set(gcf,'position',[-1100 100 1000 750])
            set(gcf,'color','w');
            title([name num2str(step_number) foot]);
            saveas(gcf,['ForeHindSplit_' name '_' panelgroup '_' foot '.jpg']);
        end

        % Clearly define parameters to be saved later. 
        % If you have 2 peaks, define everything. 
        if length(ForeHindPeaks) == 2
            TransitionTime = TransitionLocation;
            ForePeak = max(ForeCurveSplit);
            ForeTime = ForeTimeSplit(find(ForeCurveSplit == ForePeak));
            ForeStance = ForeTimeSplit(end);
            TransitionDip = -ForeHindTransition;
            TransitionTime = TransitionLocation;
            HindPeak = max(HindCurveSplit);
            HindTime = HindTimeSplit(find(HindCurveSplit == HindPeak));
            HindStance = HindTimeSplit(end);
            ForeHindDistance = ForeHindLocations(2) - ForeHindLocations(1);
            Stance = Time(end);
            
            % Save relevant variables as .mat's for averaging curves later.
            savename = [name '_' panelgroup '_' foot '.mat'];
            save(['ForeCurve_' savename],'ForeCurveSplit');
            save(['HindCurve_' savename],'HindCurveSplit');
        % If you have one peak, only define for either fore or hind. 
        elseif length(ForeHindPeaks) == 1
            if WhichFoot == 'F' || WhichFoot == 'f'
                ForePeak = ForeHindPeaks(1);
                ForeTime = ForeHindLocations(1);
                ForeStance = Time(end);
                HindPeak = 0;
                HindTime = 0;
                HindStance = 0;
                ForeHindDistance = 0;
                TransitionDip = 0;
                TransitionTime = 0;
                Stance = 0;
                % Save relevant variables as .mat's for averaging curves later.
                savename = [name '_' panelgroup '_' foot '.mat'];
                save(['ForeCurve_' savename],'Zcurve_BW');
            else
                ForePeak = 0;
                ForeTime = 0;
                ForeStance = 0;
                HindPeak = ForeHindPeaks(1);
                HindTime = ForeHindLocations(1);
                HindStance = Time(end);
                ForeHindDistance = 0;
                TransitionDip = 0;
                TransitionTime = 0;  
                Stance = 0;
                % Save relevant variables as .mat's for averaging curves later.
                savename = [name '_' panelgroup '_' foot '.mat'];
                save(['HindCurve_' savename],'Zcurve_BW');
            end
        end
             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  IMPULSE CALCULATIONS
%%%%%  EHL and BYMJ changed this on 4/5/17.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % You need to have the force and time calibrated to calculate
        % impulse correctly.  First, sum all the points of the curve. Since
        % each point is a single index of time, the sum of each data point 
        % will be in units of %BW
        ZI_sum = sum(Zcurve_BW);  % %BW
               
        % Then, convert the time index to seconds. Use the max value of the
        % variable Time. This should be the value of the full time duration
        % of the step. Finally, convert from ms to sec
        ZI = ZI_sum*(1/2500);  % %BW-seconds
        
        TransitionIndex = floor(TransitionTime/1000*2500);
        % Do same for fore and hind portions. 
        % Don't include the actual "transition" point in fore or hind,
        % because we don't know which way it goes. 
        if length(ForeHindPeaks) == 2
            ForeI_sum = sum(ForeCurveSplit);
            HindI_sum = sum(HindCurveSplit);        
            ForeI = ForeI_sum*(1/2500);
            HindI = HindI_sum*(1/2500);
        elseif length(ForeHindPeaks) == 1
            if WhichFoot == 'F' || WhichFoot == 'f'
                ForeI_sum = sum(Zcurve_BW);
                ForeI = ForeI_sum*(1/2500);
                HindI = 0;
                ZI = 0;
            else
                HindI_sum = sum(Zcurve_BW);        
                HindI = HindI_sum*(1/2500);
                ForeI = 0;
                ZI = 0;
            end
        end
           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  WRITE RAW OUTPUT XLS FILE FOR EACH STEP    
%%%%%  Make new raw excel file for each step... EHL is saving ALL data 
%%%%%  vectors, so give each step one huge excel file with all raw data. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    warning('off','MATLAB:xlswrite:AddSheet');

    % EHL took the following lines from the xlswrite1 documentation on
    % MatLab forum.  xlswrite1 significantly speeds up the writing time by
    % not opening/closing excel for each write command.  This is much, much
    % faster. 
    Excel = actxserver('Excel.Application');  % Define the server.
    path = pwd;
    RawFile = [path '\' name '_' panelgroup '_RawFile.xls']; % Name the file
    if ~exist(RawFile,'file')  % If the file doesn't exist, create it.
        ExcelWorkbook = Excel.Workbooks.Add; 
        ExcelWorkbook.Sheets.Add; 
        ExcelWorkbook.SaveAs(RawFile,1); 
        ExcelWorkbook.Close(false); 
    end 
    ExcelWorkbook =  Excel.workbooks.Open(RawFile);  % Open Excel

    fprintf('Writing Raw xls File... \n');
     
    % All data vectors for each step. Not normalized or
    % calibrated yet - but it is cropped and filtered for the
    % step. This should be everything you need to
    % recreate/recalculate/replot the data for each step.
    xlswrite1(RawFile,{'File name'},1,'B2');        xlswrite1(RawFile,{name},1,'B3'); 
    xlswrite1(RawFile,{'Animal number'},1,'C2');    xlswrite1(RawFile,{animalnum},1,'C3'); 
    xlswrite1(RawFile,{'Trial number'},1,'D2');     xlswrite1(RawFile,{trial},1,'D3');
    xlswrite1(RawFile,{'Foot'},1,'E2');             xlswrite1(RawFile,{foot},1,'E3');
    xlswrite1(RawFile,{'Panel'},1,'F2');              xlswrite1(RawFile,panelgroup,1,'F3');
    xlswrite1(RawFile,{'Animal body weight'},1,'G2');     xlswrite1(RawFile,BW,1,'G3'); 
    xlswrite1(RawFile,{'Z cali (uC/g)'},1,'H2');    xlswrite1(RawFile,cal_Z(i),1,'H3');    
    xlswrite1(RawFile,{'Z int (uC)'},1,'I2');       xlswrite1(RawFile,cal_Zint(i),1,'I3');
    xlswrite1(RawFile,{'Time Index'},1,'J2');       xlswrite1(RawFile,Time_index(range)',1,'J3');   
    xlswrite1(RawFile,{'Z Curve (uC)'},1,'K2');     xlswrite1(RawFile,Zcurve(range),1,'K3');
    xlswrite1(RawFile,{'Time (sec)'},1,'L2');       xlswrite1(RawFile,Time',1,'L3'); 
    xlswrite1(RawFile,{'Z Curve (%BW)'},1,'M2');    xlswrite1(RawFile,Zcurve_BW,1,'M3');
   
    ExcelWorkbook.Save 
    ExcelWorkbook.Close(false) % Close Excel workbook. 
    Excel.Quit; 
    delete(Excel);
    
    system('taskkill /F /IM EXCEL.EXE');
    
    fprintf('    Raw xls File Complete. \n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  WRITE PROCESSED DATA TO SUMMARY EXCEL DOCUMENT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    
    Excel = actxserver('Excel.Application');
    % There will only be one summary sheet. Name it in the line below.
    SummaryFile = [path '\' batch];
    if ~exist(SummaryFile,'file') 
        % If the summary file does not exist, create it. 
        ExcelWorkbook = Excel.Workbooks.Add; 
        ExcelWorkbook.Sheets.Add; 
        ExcelWorkbook.SaveAs(SummaryFile);  
        ExcelWorkbook.Close(false); 
    end 

    ExcelWorkbook =  Excel.workbooks.Open(SummaryFile);   % Open Excel
        
    fprintf('Writing Headers to Summary xls File... \n');

    % Fill in headers for SummaryFile.  Put here so it is only written
    % once (only if the file doesn't already exist).
    xlswrite1(SummaryFile,{'File Name'},1,'A1');
    xlswrite1(SummaryFile,{'Group'},1,'B1');
    xlswrite1(SummaryFile,{'Gender'},1,'C1');
    xlswrite1(SummaryFile,{'Animal Number'},1,'D1');
    xlswrite1(SummaryFile,{'Trial Number'},1,'E1');
    xlswrite1(SummaryFile,{'Panel'},1,'F1');
    xlswrite1(SummaryFile,{'Foot'},1,'G1');
    xlswrite1(SummaryFile,{'Fore Peak (%BW)'},1,'H1');
    xlswrite1(SummaryFile,{'Fore Peak Location (msec)'},1,'I1');
    xlswrite1(SummaryFile,{'Fore Impulse(%BW-sec)'},1,'J1');
    xlswrite1(SummaryFile,{'Fore Stance Time (msec)'},1,'K1');
    xlswrite1(SummaryFile,{'Hind Peak (%BW)'},1,'L1');
    xlswrite1(SummaryFile,{'Hind Peak Location (msec)'},1,'M1');
    xlswrite1(SummaryFile,{'Hind Impulse(%BW-sec)'},1,'N1');
    xlswrite1(SummaryFile,{'Hind Stance Time (msec)'},1,'O1');
    xlswrite1(SummaryFile,{'Transition Dip (%BW)'},1,'P1');
    xlswrite1(SummaryFile,{'Transition Location (msec)'},1,'Q1');
    xlswrite1(SummaryFile,{'Fore Hind Distance (msec)'},1,'R1');
    xlswrite1(SummaryFile,{'Total Impulse(%BW-sec)'},1,'S1');
    xlswrite1(SummaryFile,{'Total Stance Time (msec)'},1,'T1');


    ExcelWorkbook.Save 
    ExcelWorkbook.Close(false) % Close Excel workbook. 
    Excel.Quit; 
    delete(Excel);
    
    system('taskkill /F /IM EXCEL.EXE');
    fprintf('Headers Written to Summary xls File. \n');
    
    fprintf('Writting Summary Results... \n'); 

    StepResults = [{name} {group} {gender} {animalnum} {trial} {panelgroup} {foot} {ForePeak} ...
        {ForeTime} {ForeI} {ForeStance} {HindPeak} {HindTime} ...
        {HindI} {HindStance} {TransitionDip} {TransitionLocation} {ForeHindDistance} {ZI} {Stance}];
    
    xlsappend(SummaryFile,StepResults,1);
    % xlsappend is a function EHL pulled from the MatLab forum.  She did
    % not make any edits to this function.  It looks at the excel file, and
    % finds the next available row and writes the StepResults array to this
    % line. 
    
    fprintf('    Summary Results Complete. \n');  
    disp('_________________________________________');
    fprintf('\n');
    close all
        end
    end   
else 
    fprintf('No Spikes Selected. \n');    
end
end

end  % end for the entire function


