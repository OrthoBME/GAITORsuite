function getforceEDGAR(animalnum, name, trial, filename, thresh, BW, date, path, batch)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SECTION TO RUN CODE AS SCRIPT INSTEAD OF FUNCTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Uncomment lines 9-17 to run as a script.  Also, comment line 1 and
% the very last 'end' in this file.
% clear all
% animalnum = '1';
% trial = '1';
% file = 'C:\Users\Emily Lakes\Documents\DMM Mice\Dynamic\MIA_20160314_r02_t02.tdms';
% thresh = 0;
% BW = 250;
% date = '20160314';
% name = 'tester4';
% path = 'C:\Users\Emily Lakes\Desktop\Dynamic';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  EDGAR DYNAMIC PROCESSING CODE
%%%%%  Edited from getforce (HEK) by BYMJ 12-12-14 
%%%%%  Edited into getforceEDGAR_EHL 9-2016 for multi-component set-up
%%%%%  Last Edited: 11/29/16 EHL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% USER INPUTS
% animalnum = Desired Animal ID  (e.g. '1')
% name = Name of the trial
% trial = Trial number (e.g. '1') 
% file = Complete file location path
% thresh = Step threshold (default = 0)
% BW = Body weight of animal in grams
% date = Date of trial (e.g. '20160314')
% path = Complete file location path

% NOTES                   % EHL's DATA CHANNELS:
% 1 = LEFT FOOT           % [time Z1 Z2 Z3 Z4 X13 X24 Y12 Y34]
% 0 = RIGHT FOOT

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  READ FILE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Convert the .tdms file from Labview into .mat file & load into workspace.
% IF you want to convert within the code (see dynamicEDGAR_EHL2), then
% uncomment the following line: 
matFile = simpleConvertTDMS(filename,1); 

fprintf('Loading... %s \n',name);

% use this line if converting from .tdms within code:
load(matFile{1});

% use this line if loading previously converted files:
% load(filename);

% Convert function is from MathWorks. EHL made no edits to it.  It converts 
% the .tdms file from Labview directly into a .mat file for MatLab. This 
% removes the step of converting files to excel before importing them 
% into Matlab. 

% Pull out variables from the structure and name them appropriately. 
% 16/17: EHL had to add "Untitled" to each variable because she switched
% from loading tdms files to mat files.  For some reason, the mat files
% come in with "Untitled".

%%% BYMJ 1/6/17: labview files structured as follows:
%%%     0: ACZ - VF Untitled.Data
%%%     1: ACX - MLF (this code's y) Untitled1.Data
%%%     2: ACY - BPF (This code's x) Untitled2.Data
%%%     3: BDZ - VF Untitled3.Data
%%%     4: BDX - MLF (this code's y) Untitled4.Data
%%%     6: BDY - BPF (This code's x) Untitled5.Data

% Sometimes the time variable loads as and "UntitledTime" struct instead of
% just "Time". Check your variable name here when troubleshooting.
time = (Time.Data);

ACZ = (Untitled.Data);
BDZ = (Untitled3.Data);

% Moving from Kistler ML (X) to our ML axis (Y)
ACX = (Untitled2.Data);
BDX = (Untitled5.Data);

% Moving from Kistler BP (Y) to our BP axis (X)
ACY = (Untitled1.Data);
BDY = (Untitled4.Data);

% Now that we have the variables named appropriately, we can clear the
% original names to keep the workspace clean. 
clear Time Untitled Untitled1 Untitled2 Untitled3 Untitled4 Untitled5

% Put variables into a matrix called "data".  This is to match the code
% that Brittany/Heidi wrote.
data = [time ACZ BDZ ACX BDX ACY BDY];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  DRIFT COMPENSATION
%%%%%  This is from Heidi/Brittany code. EHL did not change this portion, 
%%%%%  other than trying to add comments.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find row 'r', column 'c', and depth 'd' dimensions of the matrix 'data'.
[datr datc datd] = size(data);

% Crop the data to remove obviously excess portions. This is important for
% data collected with a pre-trigger. If you click several times but the
% animal didn't walk, then you may have a bunch of data at the beginning
% that is essentially "zero".  This will look for where there is an actual
% change in data (presumably where the animal actually walked), and crop
% your data matrix to only this portion.  If you use the post-trigger, this
% part is not necessay - but it doesn't hurt anything to keep it in the
% code. -EHL comments after talking to BYMJ on 11/29/16.

% Convert time index to time (s) if necessary
% sampling rate is 2500 Hz
adjust = data(2,1) - data(1,1);
if adjust == 1
    data(:,1) = data(:,1)/2500;
end

% For the number of rows down to 2 (start at the end time point of the 
% trial). This assumed your "real" data is near the end of the trial 
% (because you would stop recording after you get a good one).
j = 1;
for i = datr:-1:2      
    if j == 1;
        % Take the difference between adjacent rows, in column 1 
        % (time index is in column 1).
        if (data(i,1)-data(i-1,1)) > .0006 
            % When there is a big shift between time points, it crops it 
            % to keep only the last portion. 
            Data = data(i:end,:);   
            j = 0;
        elseif i == 2
            Data = data;
        end
    end
end

% Define dimensions of new matrix 'Data'. (row, column, depth)
[datr datc datd] = size(Data);  

q = 'y';
check = strcmp(q,'y');
while check == 1;
    % Normalizing Channels based on a complex curve fit of the baseline data.
    % This is based on the bf.m function, which BYMJ found.
    D(:,1) = Data(:,1);
    % Look at the columns in 'Data' matrix, but don't look at "time" in first 
    % column.  i.e. data = [time Z1 Z2 Z3 Z4 X13 X24 Y12 Y34]
    for j = 2:datc  
        
        % If there is a segment of zeros that are disrupting the scale of
        % the data, set them to the previous nonzero value of the channel.
        % Could alter this to simply shift data up.
        startzero = find(~Data(:,j),1,'first');
        endzero = find(~Data(:,j),1,'last');
        diffzero = endzero - startzero;
        if diffzero > 50
            Data(startzero:endzero,j) = Data(startzero-1,j);
        end    
        
        % Find baseline for each channel.  See the bf.m function code.
        [ycorr,yfit] = bf(Data(:,j),100); 
              
        figure
        hold on
        plot (Data(:,j),'r');
        plot (yfit,'b');
        pause
             
        % Re-zero all data by subtracting baseline from each channel.
        for i = 1:datr
            D(i,j) = (Data(i,j)-yfit(i));  % yfit is the baseline curve fit.
        end
    end
    pause(1)
    q = input('Do you need to redo the baseline? (Y/N)    ','s');
    check = strcmp(q,'y');  
end
close ALL
clear check q

% Lowpass filter, 25 Hz  (this filter originated from Heidi's code)
for i = 2:datc
    fNorm = 25/(2500/2); % 25 Hz cutoff, fs = 2500 Hz
    [B, A] = butter(4, fNorm, 'low'); 
    D(:,i) = filter(B, A, D(:,i));  
    % Now, the filtered data is in "D". So use D from this point on!
end

% Redefine channels with "D" from above. 
ACZ_filtered = D(:,2);       
BDZ_filtered = D(:,3);      
ACX_filtered = D(:,4);       
BDX_filtered = D(:,5);
ACY_filtered = D(:,6); 
BDY_filtered = D(:,7);   
                     
% Clean up workspace.
clear A B  % Don't need these.  Only used for the filter above. 
clear datc datd datr data Data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  FIND STEPS (SPIKES) & SAVE CALIBRATION DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for shift = 1:2
    
    % runs both panel sets
    if shift == 1
        Z_filtered = ACZ_filtered;
        Y_filtered = ACY_filtered; 
        X_filtered = ACX_filtered; 
        panelgroup = 'AC';
        panelgroup = struct('panelgroup',panelgroup);
    else
        clear Z_filtered set
        Z_filtered = BDZ_filtered;
        Y_filtered = BDY_filtered; 
        X_filtered = BDX_filtered; 
        panelgroup = 'BD';
        panelgroup = struct('panelgroup',panelgroup);
    end
[Zstrikes, calibration] = IDspikes(Z_filtered, date, panelgroup);  % See IDspikes.m code. 

% Separate the "calibration" variable from above.  This will prevent 
% confusion later on. cal_X = calibration constant in X (slope in uC/g) and 
% cal_Xint = y-intercept in X (in uC).  Again, the calibration function is
% unique to EHL's data - but you can edit this to match your case. 
if calibration ~= 0;
    cal_X = calibration(:,1);            cal_Xint = calibration(:,4);
    cal_Y = calibration(:,2);            cal_Yint = calibration(:,5);
    cal_Z = calibration(:,3);            cal_Zint = calibration(:,6);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  ISOLATE EACH FOOT STEP (SPIKE)
%%%%%  This is from Heidi/Brittany code. EHL did not change this portion, 
%%%%%  other than trying to add comments.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Make sure there were spikes selected.  If no spikes, then skip to end.
if Zstrikes(1,1) ~= 0  % allZstrikes is output from IDspikes function above
    [r c] = size(Zstrikes);   
    %r = # of rows (not used), c = # of columns, which is # of spikes kept
    
     
    for i = 1:c  % START LOOP for each step we saved for this trial/file.
        clear skip
        step_number = i; % This is for xlswrite1 at the end to avoid 
        % confusion. By the time we get down there, we forget what i was. 
        % We still use i for the index value in this loop. 
        % Define "foot" as left/right instead of 1/0.
        foot_num = Zstrikes(3,i);
        if foot_num == 1
            foot = 'Left';
        else foot = 'Right';
        end 
        
        % Distance number is not critical. Just a buffer to take +/- around
        % the spikes to get the whole step. Can change this. 
        distance = 5000;   
        % Take first spike and take +/-distance from the peak of the spike
        range = (Zstrikes(1,i) - distance):(Zstrikes(1,i) + distance);  
        % Only keep positive numbers (if -1000 makes it dip negative).
        range = range(range>0);        
        % Only keep numbers in original range (don't go beyond total
        % length).
        range = range(range<length(D));
        % Find where Z goes above the threshold within this range
        steprange = find(Z_filtered(range)>thresh);
        steprange = steprange+(range(1));
        start = [];
        fin = [];
        for l = find(steprange == Zstrikes(1,i)):-1:2
            if steprange(l)-steprange(l-1) > 1
                start = [start steprange(l)];
            end
        end
        for l = find(steprange == Zstrikes(1,i)):length(steprange)
            if steprange(l)-steprange(l-1) > 1
                fin = [fin steprange(l)];
            end
        end
        
        if length(start) == 0
            start = steprange(1);
        end
        if length(fin) == 0
            fin = steprange(end);
        end
        
        start = start(1);
        fin = fin(1);
        range = start:fin;
        
        % Define force curves for the 3 axes
        % MLcurve = Mediolateral curve based on current panel set BYMJ
        MLcurve = Y_filtered(range);    
        % BPcurve = Braking/Propulsing curve (based on current panel set
        % BYMJ
        BPcurve = X_filtered(range);          
        % Z curve based on current panel set BYMJ
        Zcurve = Z_filtered(range);      
        
        % Re-zero force curves after summing individual components
        MLcurve = MLcurve-MLcurve(1);
        BPcurve = BPcurve-BPcurve(1);
        Zcurve = Zcurve-Zcurve(1);
        
        % Calibrate force curves so they are in %BW.  
        %                       y = mx + b
        % Where:
        %        y = measured charge         m = slope in uC/g, 
        %  x = measured grams (what we want)      b = y-intercept in uC. 
        % To get the measured grams, we rearrange the equation to:
        %                       x = (y-b)/m
        %  OR measured grams = (measured charge - y intercept)/slope (uC/g)
        % Applying this to the impulse calculation, we get a converted sum
        % that is now grams*time index.
        
        Zcurve_BW = ((Zcurve - cal_Zint(i))/cal_Z(i)) / BW * 100;
        MLcurve_BW = ((MLcurve - cal_Xint(i))/cal_X(i)) / BW * 100; % Kistler axes used for calibration label
        BPcurve_BW = ((BPcurve - cal_Yint(i))/cal_Y(i)) / BW * 100; % Kistler axes used for calibration label
        
        % Turn time vector into seconds (starts as just an index).
        % Divide by 2500 Hz collection frequency to get seconds.
        Time_index = 1:length(Zcurve_BW);
        Time = Time_index/2500*1000;  % change to milliseconds 
                
        % EHL did not change this code - but added the following comments.
        % Check that BPcurve is going the right direction.  Braking
        % (negative) forces should occure first, followed by propulsive
        % (positive) forces. This section finds the location and value of
        % the maximum swave number, and compares it to the location of the
        % maxiumum peak vertical force (Z).  This isn't a perfect filter,
        % but EHL assumes the idea is that the maximum BPcurve point should
        % occur after the maximum vertical point. Therefore, this loop
        % checks for the location of the max BPcurve to be less than the
        % location of the max vertical curve... if it is, then the BPcurve
        % needs flipped. 
        % Note: unit conversion for this portion does not matter, as long
        % as the units on the BP and Z max locations are the same.
        % Technically, the units for BPcurve_Max_X is a time index (where
        % in the array the maximum occurs).  
      

        % Plot data - NOW IN %BW & MILLISECONDS
        figure
        hold on
        plot(Time, Zcurve_BW, 'b')
        plot(Time, MLcurve_BW, 'g')
        plot(Time, BPcurve_BW, 'r')
        title ('Step Data')
        legend('Blue: Z', 'Green: ML (y)', 'Red: BP (x)', 'Location','northoutside','Orientation','horizontal')
        % Below changes the position of the plot on your computer monitor.  
        % EHL wanted plots to show up on the second monitor and keep the 
        % Matlab screen clear. You can mess around with your resolution to
        % get them to pop up where you want. 
        set(gcf,'position',[-1100 100 1000 750])  
        % Makes background of the plot white instead of gray. 
        set(gcf,'color','w'); 
        
        yflip = input('Do you need to flip the ML curve? (Y/N)   ', 's');     
        if yflip == 'y' || yflip =='Y'
        MLcurve_BW = -MLcurve_BW; 
        MLcurve_BW = MLcurve_BW - MLcurve_BW(1);
        end
      
        disp('Choose LEFT boundary   ')
        [minx miny] = ginput(1);
        % This is why EHL changed to milliseconds.  
        % Couldn't threshold with values <1.
        minx_index = find(Time > minx);  
        minX = minx_index(1);
        disp('Choose RIGHT boundary   ')
        [maxx maxy] = ginput(1);
        maxx_index = find(Time > maxx);
        maxX = maxx_index(1);

        % Safegaurd for if you click a boundary outside the matrix
        % dimensions. -EHL
        t = 1:1:length(Zcurve_BW);  
        if minX < t(1);
            minX = t(1);
        end
        if maxX > t(end)
            maxX = t(end);
        end

        range = minX:maxX;  % Redefine curves with new range.
        MLcurve_BW = MLcurve_BW(range);  
        Zcurve_BW = Zcurve_BW(range);
        BPcurve_BW = BPcurve_BW(range);
        Time = Time(range);
        
        % 1/5/16 EHL: rezero at this point based on the last point.  
        % Majority of trials will have the hind foot be the last to touch. 
        % Therefore, rezero by the last point (when no weight on plate anymore). 
        % This helps because in most cases there is a forepaw
        % followed by a hindpaw, creating 2 consecutive peaks, with no dip
        % back down to zero in between.  But, we only care about the second
        % hind foot peak. 
        MLcurve_BW = MLcurve_BW - MLcurve_BW(end);
        BPcurve_BW = BPcurve_BW - BPcurve_BW(end);
        Zcurve_BW = Zcurve_BW - Zcurve_BW(end);
        Time = Time - Time(1);
        
        close ALL

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  PLOT DATA & CHOOSE MEDIOLATERAL PEAKS & CHOOSE BRAKE/PROP PEAKS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Replot data - IN %BW & INDEX            
        figure
        hold on
        plot(Zcurve_BW, 'b')
        plot(MLcurve_BW, 'g')
        plot(BPcurve_BW, 'r')
        legend('Blue: Z', 'Green: ML (y)', 'Red: BP (x)','Location','northoutside','Orientation','horizontal')
        set(gcf,'position',[-1100 100 1000 750])
        set(gcf,'color','w');
        
        % Choose mediolateral peaks
        disp('Select Mediolateral Y Axis Peak 1   ')
        [ML_click1_x, ~] = ginput(1);
        if ML_click1_x > 50
            ML_click1_y_range = MLcurve_BW(round(ML_click1_x - 50):round(ML_click1_x + 50));
        else
            ML_click1_y_range = MLcurve_BW(1:round(ML_click1_x + 50));
        end
        ML_click1_y = max(ML_click1_y_range);
        MLcurve_BW_yloc1 = find(MLcurve_BW == ML_click1_y,1);
        ML_peak1_x = Time(MLcurve_BW_yloc1);
        ML_peak1_y = MLcurve_BW(MLcurve_BW_yloc1);
        
        disp('Select Mediolateral Y Axis Peak 2   ')
        [ML_click2_x, ~] = ginput(1);
        if (length(MLcurve_BW) - ML_click2_x) > 50
           ML_click2_y_range = MLcurve_BW(round(ML_click2_x - 50):round(ML_click2_x + 50));
        else
           ML_click2_y_range = MLcurve_BW(round(ML_click2_x - 50):length(MLcurve_BW));
        end
        ML_click2_x = max(ML_click2_y_range);
        MLcurve_BW_yloc2 = find(MLcurve_BW == ML_click2_x,1);
        ML_peak2_x = Time(MLcurve_BW_yloc2);
        ML_peak2_y = MLcurve_BW( MLcurve_BW_yloc2);
        
        % Flip BP curve if needed
        xflip = input('Do you need to flip the BP curve? (Y/N)   ', 's');     
        if xflip == 'y' || yflip =='Y'
        BPcurve_BW = -BPcurve_BW; 
        end
        close        
        
        % Replot data - IN %BW & INDEX           
        figure
        hold on
        plot(Zcurve_BW, 'b')
        plot(MLcurve_BW, 'g')
        plot(BPcurve_BW, 'r')
        legend('Blue: Z', 'Green: ML (y)', 'Red: BP (x)','Location','northoutside','Orientation','horizontal')
        set(gcf,'position',[-1100 100 1000 750])
        set(gcf,'color','w');       
        
        % Choose min/max braking/propulsion
        disp('Select Minimum Braking/Propulsion   ')
        [BP_min_x, ~] = ginput(1);
        if BP_min_x > 50
            BP_min_y_range = BPcurve_BW(round(BP_min_x - 50):round(BP_min_x + 50));
        else
            BP_min_y_range = BPcurve_BW(1:(round(BP_min_x + 50)));
        end
        BP_min_y = min(BP_min_y_range);
        BPcurve_BW_ylocmin = find(BPcurve_BW == BP_min_y,1);
        BP_min_x = Time(BPcurve_BW_ylocmin);
        BP_min_y = BPcurve_BW(BPcurve_BW_ylocmin);
        disp('Select Maximum Braking/Propulsion    ')
        [BP_max_x, ~] = ginput(1);
        if (length(BPcurve_BW) - BP_max_x) > 50
            BP_max_y_range = BPcurve_BW(round(BP_max_x - 50):round(BP_max_x + 50));
        else
            BP_max_y_range = BPcurve_BW(round(BP_max_x - 50):length(BPcurve_BW));
        end
        BP_max_y = max(BP_max_y_range);
        BPcurve_BW_ylocmax = find(BPcurve_BW == BP_max_y,1);      
        BP_max_x = Time(BPcurve_BW_ylocmax);
        BP_max_y = BPcurve_BW(BPcurve_BW_ylocmax);
        close
        
        % Replot data - IN %BW & MILLISECONDS
        figure
        hold on
        plot(Time, Zcurve_BW, 'b')
        plot(Time, MLcurve_BW, 'g')
        plot(Time, BPcurve_BW, 'r')
        plot(BP_min_x,BP_min_y,'ko')
        plot(BP_max_x,BP_max_y,'k*')
        plot(ML_peak1_x,ML_peak1_y,'k+')
        plot(ML_peak2_x,ML_peak2_y,'kv')
        legend('Blue: Z', 'Green: ML (y)', 'Red: BP (x)', 'o : min','* : max', '+ : 1st m-l peak', 'v : 2nd m-l peak','Location','northoutside','Orientation','horizontal')
        set(gcf,'position',[-1100 100 1000 750]) 
        set(gcf,'color','w');

        qq = input('Do you want to throw out the step? (Y/N) ','s');
        if qq == 'y' || qq == 'Y'
            skip = 'yes'; % Indicates whether to keep or toss step.
        else
            saveas(gcf,[name '_' num2str(step_number) '.jpg']);
            skip = 'no';
        end
        close ALL

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  SEPARATE BRAKING & PROPULSIVE PORTIONS OF BPCURVE
%%%%%  To get two separate impulse values, we need to divide the curve into
%%%%%  the braking (negative) and propulsive positive) portions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
    if strcmp(skip,'no') == 1;
        brakeI = [];
        propI = [];
        % Sort BPcurve into negative (braking) and positive (propulsive)
        % portions. 
        for q = 1:length(BPcurve_BW)  % Index through each point in curve
            % If the point is negative, then put it in the "brakeI" array
            if BPcurve_BW(q)<=0   
                brakeI = [brakeI BPcurve_BW(q)];   
                % By redefining the array on each iteration, 
                % it will keep "tacking" on the next value. So: if a = [] 
                % to start with, then a = [1], then on next iteration you 
                % want to add 2 ... so call a = [a 2], which equals [1 2].
            else
                % Else - the point must be positive, so put it in the 
                % "propI" array
                propI = [propI BPcurve_BW(q)];
            end
        end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  IMPULSE CALCULATIONS
%%%%%  EHL and BYMJ changed this on 4/5/17.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % You need to have the force and time calibrated to calculate
        % impulse correctly.  First, sum all the points of the curve. Since
        % each point is a single index of time, the sum of each data point 
        % will be in units of %BW
        ZI_sum = sum(Zcurve_BW);  % %BW
        YI_sum = sum(MLcurve_BW);  % %BW
        BrakeI_sum = sum(brakeI);  % %BW
        PropI_sum = sum(propI);  % %BW
               
        % Then, convert the time index to seconds. Use the max value of the
        % variable Time. This should be the value of the full time duration
        % of the step. Finally, convert from ms to sec
        ZI = (ZI_sum*max(Time))/1000;    % %BW-seconds
        YI = (YI_sum*max(Time))/1000;    % %BW-seconds
        BrakeI = (BrakeI_sum*max(Time))/1000;   % %BW-seconds
        PropI =  (PropI_sum*max(Time))/1000;   % %BW-seconds
    end
    end
           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  WRITE RAW OUTPUT XLS FILE FOR EACH STEP    
%%%%%  Make new raw excel file for each step... EHL is saving ALL data 
%%%%%  vectors, so give each step one huge excel file with all raw data. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(skip,'no') == 1;
    warning('off','MATLAB:xlswrite:AddSheet');

    % EHL took the following lines from the xlswrite1 documentation on
    % MatLab forum.  xlswrite1 significantly speeds up the writing time by
    % not opening/closing excel for each write command.  This is much, much
    % faster. 
    Excel = actxserver('Excel.Application');  % Define the server.
    RawFile = [path '\' name '_' num2str(i) '_RawFile.xls']; % Name the file
    if ~exist(RawFile,'file')  % If the file doesn't exist, create it.
        ExcelWorkbook = Excel.Workbooks.Add; 
        ExcelWorkbook.Sheets.Add; 
        ExcelWorkbook.SaveAs(RawFile); 
        ExcelWorkbook.Close(false); 
    end 
    ExcelWorkbook =  Excel.workbooks.Open(RawFile);  % Open Excel

    fprintf('Writing Raw xls File... \n');
     
    % All data vectors for each step. Not normalized or
    % calibrated yet - but it is cropped and filtered for the
    % step. This should be everything you need to
    % recreate/recalculate/replot the data for each step.
    xlswrite1(RawFile,{'File name'},1,'B2');        xlswrite1(RawFile,{name},1,'B3'); 
    xlswrite1(RawFile,{'Animal number'},1,'C2');    xlswrite1(RawFile,{animalnum},1,'C3'); 
    xlswrite1(RawFile,{'Trial number'},1,'D2');     xlswrite1(RawFile,{trial},1,'D3');
    xlswrite1(RawFile,{'Step number (within trial)'},1,'E2');   xlswrite1(RawFile,step_number,1,'E3');
    xlswrite1(RawFile,{'Foot (L = 1, R = 0)'},1,'F2');    xlswrite1(RawFile,foot,1,'F3'); 
    xlswrite1(RawFile,{'Animal body weight'},1,'G2');     xlswrite1(RawFile,BW,1,'G3'); 
    xlswrite1(RawFile,{'X cali (uC/g)'},1,'H2');     xlswrite1(RawFile,cal_X(i),1,'H3'); 
    xlswrite1(RawFile,{'Y cali (uC/g)'},1,'I2');     xlswrite1(RawFile,cal_Y(i),1,'I3');
    xlswrite1(RawFile,{'Z cali (uC/g)'},1,'J2');     xlswrite1(RawFile,cal_Z(i),1,'J3'); 
    xlswrite1(RawFile,{'X int (uC)'},1,'K2');        xlswrite1(RawFile,cal_Xint(i),1,'K3');
    xlswrite1(RawFile,{'Y int (uC)'},1,'L2');        xlswrite1(RawFile,cal_Yint(i),1,'L3');  
    xlswrite1(RawFile,{'Z int (uC)'},1,'M2');        xlswrite1(RawFile,cal_Zint(i),1,'M3');
    xlswrite1(RawFile,{'Time Index'},1,'N2');       xlswrite1(RawFile,Time_index(range)',1,'N3');   
    xlswrite1(RawFile,{'Z Curve (uC)'},1,'O2');      xlswrite1(RawFile,Zcurve(range),1,'O3');
    xlswrite1(RawFile,{'X Curve (uC)'},1,'P2');      xlswrite1(RawFile,BPcurve(range),1,'P3');
    xlswrite1(RawFile,{'Y Curve (uC)'},1,'Q2');      xlswrite1(RawFile,MLcurve(range),1,'Q3');

    ExcelWorkbook.Save 
    ExcelWorkbook.Close(false) % Close Excel workbook. 
    Excel.Quit; 
    delete(Excel);
    
    system('taskkill /F /IM EXCEL.EXE');
    
    fprintf('    Raw xls File Complete. \n');
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  WRITE CALIBRATED OUTPUT XLS FILE FOR EACH STEP    
%%%%%  Same as above, only calibrated force curves.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    Excel = actxserver('Excel.Application');  % Define the server.
    CalFile = [path '\' name '_' num2str(i) '_CalibratedFile.xls']; % Name the file
    if ~exist(CalFile,'file')  % If the file doesn't exist, create it.
        ExcelWorkbook = Excel.Workbooks.Add; 
        ExcelWorkbook.Sheets.Add; 
        ExcelWorkbook.SaveAs(CalFile); 
        ExcelWorkbook.Close(false); 
    end 
    ExcelWorkbook =  Excel.workbooks.Open(CalFile);   % Open Excel

    fprintf('Writing Calibrated xls File... \n');
     
    % All data vectors for each step. Not normalized or
    % calibrated yet - but it is cropped and filtered for the
    % step. This should be everything you need to
    % recreate/recalculate/replot the data for each step.
    xlswrite1(CalFile,{'File name'},1,'B2');        xlswrite1(CalFile,{name},1,'B3'); 
    xlswrite1(CalFile,{'Animal number'},1,'C2');    xlswrite1(CalFile,{animalnum},1,'C3'); 
    xlswrite1(CalFile,{'Trial number'},1,'D2');     xlswrite1(CalFile,{trial},1,'D3');
    xlswrite1(CalFile,{'Step number (within trial)'},1,'E2');   xlswrite1(CalFile,step_number,1,'E3');
    xlswrite1(CalFile,{'Foot (L = 1, R = 0)'},1,'F2');    xlswrite1(CalFile,foot,1,'F3'); 
    xlswrite1(CalFile,{'Animal body weight'},1,'G2');     xlswrite1(CalFile,BW,1,'G3'); 
    xlswrite1(CalFile,{'X cali (uC/g)'},1,'H2');     xlswrite1(CalFile,cal_X(i),1,'H3'); 
    xlswrite1(CalFile,{'Y cali (uC/g)'},1,'I2');     xlswrite1(CalFile,cal_Y(i),1,'I3');
    xlswrite1(CalFile,{'Z cali (uC/g)'},1,'J2');     xlswrite1(CalFile,cal_Z(i),1,'J3'); 
    xlswrite1(CalFile,{'X int (uC)'},1,'K2');        xlswrite1(CalFile,cal_Xint(i),1,'K3');
    xlswrite1(CalFile,{'Y int (uC)'},1,'L2');        xlswrite1(CalFile,cal_Yint(i),1,'L3');  
    xlswrite1(CalFile,{'Z int (uC)'},1,'M2');        xlswrite1(CalFile,cal_Zint(i),1,'M3');
    xlswrite1(CalFile,{'Time Index'},1,'N2');       xlswrite1(CalFile,Time_index',1,'N3');   
    xlswrite1(CalFile,{'Z Curve (uC)'},1,'O2');      xlswrite1(CalFile,Zcurve_BW,1,'O3');
    xlswrite1(CalFile,{'X Curve (uC)'},1,'P2');      xlswrite1(CalFile,BPcurve_BW,1,'P3');
    xlswrite1(CalFile,{'Y Curve (uC)'},1,'Q2');      xlswrite1(CalFile,MLcurve_BW,1,'Q3');
 

    ExcelWorkbook.Save 
    ExcelWorkbook.Close(false) % Close Excel workbook. 
    Excel.Quit; 
    delete(Excel);
    
    system('taskkill /F /IM EXCEL.EXE');

    
    fprintf('    Calibrated xls File Complete. \n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  WRITE PROCESSED DATA TO SUMMARY EXCEL DOCUMENT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    
    Excel = actxserver('Excel.Application');
    % There will only be one summary sheet. Name it in the line below.
    SummaryFile = [path '\' batch];
    if ~exist(SummaryFile,'file') 
        % If the summary file does not exist, create it. 
        ExcelWorkbook = Excel.Workbooks.Add; 
        ExcelWorkbook.Sheets.Add; 
        ExcelWorkbook.SaveAs(SummaryFile);  
        ExcelWorkbook.Close(false); 
    end 

    ExcelWorkbook =  Excel.workbooks.Open(SummaryFile);   % Open Excel

    fprintf('Writing Headers to Summary xls File... \n');

    % Fill in headers for SummaryFile.  Put here so it is only written
    % once (only if the file doesn't already exist).
    xlswrite1(SummaryFile,{'File Name'},1,'A1');
    xlswrite1(SummaryFile,{'Animal Number'},1,'B1');
    xlswrite1(SummaryFile,{'Trial Number'},1,'C1');
    xlswrite1(SummaryFile,{'Step Number (within trial)'},1,'D1');
    xlswrite1(SummaryFile,{'Foot'},1,'E1');

    xlswrite1(SummaryFile,{'Z Max (%BW)'},1,'F1');
    xlswrite1(SummaryFile,{'Z Max Location (msec)'},1,'G1');
    xlswrite1(SummaryFile,{'Z Impulse(%BW-msec)'},1,'H1');
    xlswrite1(SummaryFile,{'Stance Time (msec)'},1,'I1');

    xlswrite1(SummaryFile,{'X BP Min (%BW)'},1,'J1');
    xlswrite1(SummaryFile,{'X BP Min Location (msec)'},1,'K1'); 
    xlswrite1(SummaryFile,{'X BP Max (%BW)'},1,'L1');
    xlswrite1(SummaryFile,{'X BP Max Location (msec)'},1,'M1');
    xlswrite1(SummaryFile,{'X Braking Impulse (%BW-msec)'},1,'N1');
    xlswrite1(SummaryFile,{'X Propulsive Impulse (%BW-msec)'},1,'O1');

    xlswrite1(SummaryFile,{'1st ML Force (%BW)'},1,'P1');
    xlswrite1(SummaryFile,{'1st ML Force Location (msec)'},1,'Q1');
    xlswrite1(SummaryFile,{'2nd ML Force (%BW)'},1,'R1');
    xlswrite1(SummaryFile,{'2nd ML Force Location (msec)'},1,'S1');
    xlswrite1(SummaryFile,{'Y ML Impulse (%BW-msec)'},1,'T1');

    ExcelWorkbook.Save 
    ExcelWorkbook.Close(false) % Close Excel workbook. 
    Excel.Quit; 
    delete(Excel);
    
    system('taskkill /F /IM EXCEL.EXE');
    fprintf('Headers Written to Summary xls File. \n');
    
    fprintf('Writting Summary Results... \n'); 
    % Put data results into an array to match the headers above. This way,
    % we can write the array at once. 
    Zmax = max(Zcurve_BW); % in %BW
    Zmax_coord = find(Zcurve_BW == max(Zcurve_BW))/2500*1000; % Convert to milliseconds  
    Stance_Time = length(Zcurve_BW)/2500*1000;
    
    StepResults = [{name} {animalnum} {trial} {step_number} {foot} {Zmax} {Zmax_coord} {ZI} {Stance_Time} {BP_min_y} {BP_min_x} {BP_max_y} {BP_max_x} {BrakeI} {PropI} {ML_peak1_y} {ML_peak1_x} {ML_peak2_y} {ML_peak2_x} {YI}];
    
    [success,message] = xlsappend(SummaryFile,StepResults,1);
    % xlsappend is a function EHL pulled from the MatLab forum.  She did
    % not make any edits to this function.  It looks at the excel file, and
    % finds the next available row and writes the StepResults array to this
    % line. 
    
    fprintf('    Summary Results Complete. \n\n');    
end
else 
    fprintf('No Spikes Selected. \n');    
end
end

end  % end for the entire function


