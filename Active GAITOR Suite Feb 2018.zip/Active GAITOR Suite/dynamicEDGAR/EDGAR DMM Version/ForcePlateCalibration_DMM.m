% Force Plate Calibration_Exercise.m 
% Emily Lakes
% Last Modification:  October 11, 2016
%
% Get the calibration constants for the 4 panel system. MiRa's exercise
% study.

clc; clear;
home;
close all

% Choose .tdms files, pull info from file name, and convert to .mat
[file,path] = uigetfile('*tdms','Click the files you want to calibrate.','MultiSelect', 'on');
for p = 1:length(file)
[path,name,extension] = fileparts(file{p});  % Break up filename into path, name, and extension.
nameparts = regexp(name, '_','split');  % Break up the name into it's components (assumes name is separated by underscore)
panel = nameparts{2};
cw = nameparts{3};

fileconvert = simpleConvertTDMS([name,'.tdms'],1);  % this function is from MathWorks.  I made no edits to it.  It converts the .tdms file from Labview directly into a .mat file for MatLab. This removes the step of converting files ot excel and then importing them into Matlab. 
load([name,'.mat']);
 
% Pull out variables from the structure.
A_Z = Untitled.Data;  A_Z = A_Z(A_Z~=0);
B_Z = Untitled1.Data; B_Z = B_Z(B_Z~=0);
C_Z = Untitled2.Data;  C_Z = C_Z(C_Z~=0);
D_Z = Untitled3.Data; D_Z = D_Z(D_Z~=0);
time = Time.Data(1:length(A_Z));

% If you want to have a general look at you data before plotting, then
% uncomment the following 4 lines:
% plot(time, [AB_Z, AB_X, AB_Y, BD_Z, BD_X, BD_Y]);
% set(gcf,'color','w');
% legend('AB_Z', 'AB_X', 'AB_Y', 'BD_Z', 'BD_X', 'BD_Y')
% uiwait(msgbox({'Make sure your plots make sense, then click ok.'}));

% Plot the relevant axis and have the user click the left baseline, 
% plateau, and right baseline. This will give the voltage difference.  
% Then, calculate the calibration constant for the desired direction. 
if panel == 'CalAB'
    Z1 = A_Z;
    Z2 = B_Z;
else
    Z1 = C_Z;
    Z2 = D_Z;
end

plot(time,Z1);
xlabel('Time (s)')
ylabel('uC')
title('Z')
set(gcf,'color','w');
[leftX leftY] = ginput(1);  
leftXloc = find(time > leftX);
leftVolt = Z1(leftXloc(1));
[plateauX plateauY] = ginput(1); 
plateauXloc = find(time > plateauX);
plateauVolt = Z1(plateauXloc(1));
[rightX rightY] = ginput(1);  
rightXloc = find(time > rightX);
rightVolt = Z1(rightXloc(1));
baselineAvg = (leftVolt + rightVolt)/2;
Vdiff_Z1 = abs(plateauVolt - baselineAvg);
close all
if panel == 'CalAB'
    fprintf((['\n',name,' g = ' num2str(Vdiff_Z1) 'uC for A. \n']))
else
    fprintf((['\n',name,' g = ' num2str(Vdiff_Z1) 'uC for C. \n']))
end

plot(time,Z2);
xlabel('Time (s)')
ylabel('uC')
title('Z')
set(gcf,'color','w');
[leftX leftY] = ginput(1);  
leftXloc = find(time > leftX);
leftVolt = Z2(leftXloc(1));
[plateauX plateauY] = ginput(1); 
plateauXloc = find(time > plateauX);
plateauVolt = Z2(plateauXloc(1));
[rightX rightY] = ginput(1);  
rightXloc = find(time > rightX);
rightVolt = Z2(rightXloc(1));
baselineAvg = (leftVolt + rightVolt)/2;
Vdiff_Z2 = abs(plateauVolt - baselineAvg);
close all
if panel == 'CalAB'
    fprintf((['\n',name,' g = ' num2str(Vdiff_Z2) 'uC for B. \n']))
else
    fprintf((['\n',name,' g = ' num2str(Vdiff_Z2) 'uC for D. \n']))
end


end


