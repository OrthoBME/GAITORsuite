function [VELOCITY] = VelocityOnly(Input,TopRatFilter)

%% VelocityOnly - April 1, 2017 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Last Updated: April 1, 2017
% Emily H. Lakes

% Small portion of AGATHA to track only the velocity from the top image.
% Originally created for the 2016 Taxol experiment, but could easily be
% used for other re-runs for velocity. 
%
% Function Inputs
%   *Input: The name of the Input structure with the naming convention
%       'Input_batch', as designated in Input_Setup.m. 
%       Example: 'Input_Default.mat'
%   *TopRatFilter: The name of the rat filter function created by exporting
%       thresholds from colorThresholder.
%       Example: 'MyExperiment_TopRatFilter.m'

% Function Outputs
%   * Velocity_Data: A .mat file contating x,y data for the top view rat
%       centroid for every 20th frame. 
%       

%% Running AGATHA as a Script %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% To troubleshoot AGATHA, please set up AGATHA to run as a script; this
% enables you to preserve variables internal to the function for debugging.
% If you want to run this file as a script - change the line below to match
% your Input .mat file name - for example load('Input_Day1.mat'). 
% Also, comment the first "function" line.
load(Input); 

% Also, uncomment the following lines if running as a script and insert 
% your function name.
% TopRatFilter = 'TaxolRat_20160825';

%% Select Videos & Import/Initialize Variables %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Directory = uigetdir;
File = uipickfiles('FilterSpec',Directory,'Type',{'*.avi' '.avi'});

% Select the videos you want to run.
% Sets up counters for error and file tracker for batch.
ErrorCount = 1;
FileCount = 1;
Finish = length(File);
ErrVids = [];
TrialIDName = [];

% Convert filters
TopRatFilter = str2func(TopRatFilter);

while FileCount <= Finish
try
close all
% Keep variables above and also keep video in case you want to preload it 
% (see PreloadedVideo below). 
clearvars -except Video FileCount File Input ErrorCount ErrVids ... 
    TopRatFilter Finish TrialIDName Editor CentroidVelocity ...

% Pull out variables from "Input" cell array.  Description of these
FloorZCoordinate = Input.ZCoordinates(1);  

%% AGATHA Start %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% VideoName - use the full root for best results.
VideoName = File{FileCount};

% Break up filename into path, name, and extension.
% TrialIDName - Files associated with this run will be saved with this 
% label. You can set this to be part of the video name, but then videos 
% need to be saved with a very consistent labeling pattern.  
% Running batches, it's typically easier to pass a label.
% Here, we pull TrialIDName from the filename. 
[~,TrialIDName,~] = fileparts(VideoName); 
TrialIDName(TrialIDName == '.' ) = [];
    
%% File Read-in Section %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
disp(['VelocityOnly Running -- ',TrialIDName]);

% This section looks to see if the target video is even in the MATLAB root 
% directory, then makes mock-up names if the video was split into multiple 
% files (something that can happen with certain high-speed settings).  
% Most of the time only 1 video exists, so the last case is the only 
% condition that exists, a simple video read (i.e. if only 1 video exists 
% per trial, only v1 will be used).  If up to 5 files are used to save a 
% certain video, this section of code will concatenate this 5 videos 
% together into a single file.
if exist('VideoName','var')
    v1 = VideoName;
    VideoName(end-4) = '1';
    v2 = VideoName;
    VideoName(end-4) = '2';
    v3 = VideoName;
    VideoName(end-4) = '3';
    v4 = VideoName;
    VideoName(end-4) = '4';
    v5 = VideoName;
else
    disp('Error - Video does not exist within the directory');
end
if exist(v5,'file')
    v1 = VideoReader(v1);
    v2 = VideoReader(v2);
    v3 = VideoReader(v3);
    v4 = VideoReader(v4);
    v5 = VideoReader(v5);
    Vid1 = read(v1);
    Vid2 = read(v2);
    Vid3 = read(v3);
    Vid4 = read(v4);
    Vid5 = read(v5);
    Video = cat(4,Vid1,Vid2,Vid3,Vid4,Vid5);
elseif exist(v4,'file')
    v1 = VideoReader(v1);
    v2 = VideoReader(v2);
    v3 = VideoReader(v3);
    v4 = VideoReader(v4);
    Vid1 = read(v1);
    Vid2 = read(v2);
    Vid3 = read(v3);
    Vid4 = read(v4);
    Video = cat(4,Vid1,Vid2,Vid3,Vid4);
elseif exist(v3,'file')
    v1 = VideoReader(v1);
    v2 = VideoReader(v2);
    v3 = VideoReader(v3);
    Vid1 = read(v1);
    Vid2 = read(v2);
    Vid3 = read(v3);
    Video = cat(4,Vid1,Vid2,Vid3);
elseif exist(v2,'file')
    v1 = VideoReader(v1);
    v2 = VideoReader(v2);
    Vid1 = read(v1);
    Vid2 = read(v2);
    Video = cat(4,Vid1,Vid2);
else
    v1 = VideoReader(v1);  
    Video = read(v1);
end

% Video is now stored in the variable Video, so we clear the workspace 
% of large, unnecessary variables
clear v1 v2 v3 v4 v5 Vid1 Vid2 Vid3 Vid4 Vid5
disp('Video Loaded');
disp(' ');

% Find and load the data file associated with the current trial.
DataTrialIDName = strcat(TrialIDName,'_DATA');
load(DataTrialIDName,'-mat');
AGATHAData = DATA.AGATHA;

%% Determine frame of first step %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Sort objects in AGATHAData Temporally.
    [~, order] = sort(AGATHAData(:,4)); 
    AGATHADataSort = zeros(size(AGATHAData));
    for ii = 1:size(AGATHADataSort,1)
        AGATHADataSort(ii,:) = AGATHAData(order(ii),:);
    end
 
    % To avoid when rat is not on screen, find the frame of first hind
    % foot strike and last fore foot strike.  This was taken from
    % TemporalFeet code and modified. 
    % Look at (temporally) first hind (0) paw object and ID frame.
    FirstHind = AGATHADataSort((find(AGATHADataSort(:,2) == 0, 1, 'first')), 8);    
    
    % Look at (temporally) last fore (1) paw object and ID frame.
    LastFore = AGATHADataSort((find(AGATHADataSort(:,2) == 1, 1, 'last')), 8);

%% Direction Tracker Section %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% For hand digitizing, look at position every 20 frames.  Do the same here.
k = 1;
for j = floor(FirstHind):20:floor(LastFore)
    Frame = Video(1:FloorZCoordinate,:,:,j);
    
    % Create mask based on chosen histogram thresholds.
    [~,FilteredRat] = TopRatFilter(Frame);
   
    % Sets non-zero items to white.
    FilteredRat(FilteredRat(:,:) > 0) = 255;
    
    % Erodes followed by dilates to get rid of background noise.
    FilteredRat = imerode(FilteredRat,strel('square',3));
    FilteredRat = imdilate(FilteredRat,strel('square',3));
    FilteredRat = rgb2gray(FilteredRat);
    
    FilteredRat = bwlabel(FilteredRat);
    TopStats = regionprops(FilteredRat, 'Area'); 
    AllArea = [TopStats.Area]';
    FilteredRat(FilteredRat ~= find(AllArea == max(AllArea))) = 0;     

    % Once only one area is selected, then relable, find centroid, and
    % record x_coordinate of the centroid.
    LabeledRat = bwlabel(FilteredRat);
    TopStats = regionprops(LabeledRat, 'Centroid');
    TopCentroidVelocity(k,1) = TopStats.Centroid(1);
    TopCentroidVelocity(k,2) = TopStats.Centroid(2);
    FrameArray(k) = j;
    k = k + 1;
end

%% Calculate Velocity %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This section was adapted from the Calculator code. 

TopBodyCentX = TopCentroidVelocity(:,1);
% TopBodyCentY = TopCentroidVelocity(:,2);
% 
% FirstBodyPointX = TopBodyCentX(1);
% FirstBodyPointY = TopBodyCentY(1);
% 
% j = 1;
% for i = 1:size(TopCentroidVelocity,1)-1
%     ZeroCheckX = eq(TopBodyCentX(i), 0); 
%     ZeroCheckY = eq(TopBodyCentY(i), 0);
%     if ZeroCheckX == 0 || ZeroCheckY == 0
%         TopBodyD(j,1) = sqrt((TopBodyCentX(i+1) - FirstBodyPointX)^2 + ...
%             (TopBodyCentY(i+1) - FirstBodyPointY)^2);
% 
%         TopBodyD(j,2) = i;
%         j = j + 1; 
%     else
%         % Do Nothing.
%     end
% end

TopBodyLinearCoefficients = polyfit(FrameArray',TopBodyCentX,1);

TopVelocityBody = TopBodyLinearCoefficients(1);
    
%% Save the Output Matrices %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

VelocityStruct = struct('TopCentroidVelocity',TopCentroidVelocity);
% Save AGATHA_Data and Velocity_Data into a single structure. 
VELOCITY = struct('Velocity',VelocityStruct);
Filename_DATA = [TrialIDName, '_VELOCITY.mat'];
save(Filename_DATA, 'VELOCITY');

MasterSheet = 'VelocityResults.xlsx';
if exist('MasterSheet','file') == 0
    MasterLabels = [{'TrialIDName'},{'Top Body Velocity'}];
    xlswrite(MasterSheet,MasterLabels);
end
MasterData = [{TrialIDName},{TopVelocityBody}];
xlsappend(MasterSheet,MasterData);

fprintf([TrialIDName, ' COMPLETE. \n______________________________ \n\n']);

% Don't try and look at file{2} if you only chose 1 file to begin with.
if length(File) == 1
    break
end

close all;

catch MException
    ErrorLine = MException.stack.line;
    fprintf(['\nERROR encountered in ', TrialIDName, ' at Line: ', '%i', '\n'],ErrorLine);
    ErrorMessage = MException.message;
    disp(ErrorMessage);
    
    ErrVids{ErrorCount,1} = TrialIDName;
    ErrVids{ErrorCount,2} = ErrorLine;
    ErrVids{ErrorCount,3} = ErrorMessage;
    
    ErrorCount = ErrorCount + 1;
    beep
end

% Set filecount to address next file in batch.
FileCount = FileCount + 1;
end

close all;


