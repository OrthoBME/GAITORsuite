 function [strikes,cali] = IDspikes_Taxol(channel, date, set)

q2 = 'y';
while q2 == 'y' || 'Y'
    spikes = spike_times(abs(channel),0.1);  %0.5 is default threshold for spike_times function.
%     x1 = spikes(1,:);
%     y1 = spikes(2,:);
    title('Click ONCE on spikes you want to keep. ENTER when finished. No spikes - just ENTER');
    [x1, ~] = ginput;
    q2 = input('Do you need to rechoose the spikes? (Y/N)   ', 's');
    if q2 ~= 'y' || 'Y'
        break
    end
    continue  
end

check = isempty(x1);
if check == 1
    fprintf('No Spikes Selected. \n');         
    strikes = 0;
    cali = 0;
    return
end

close ALL 

%%%%% ID Panel Steps       
    [~, c] = size(spikes);
    diff = [];
    for i = 1:length(x1)
        for j = 1:c
            diff(j) = abs(spikes(1,j)-x1(i));
        end
        [~, cc] = find(diff==min(diff));
        S(:,i) = spikes(:,cc);
    end
    if exist('S')
        spikes = S;
    end
    
    check = 'y';
    while check == 'y'
        foot = [];
        panel = [];
        for i = 1:length(x1)
            figure
            hold on
            plot(channel,'k-')
            plot(spikes(1,i),spikes(2,i),'ro')
            xlabel('Matrix Index (not time)')
            ylabel('uC')
            title('Foot Strikes')
            hold off
            q3 = input('Is this a LEFT or RIGHT foot strike? (L/R)  ','s');
                if q3 == 'L' || q3 == 'l'
                    foot(i) = 1;
                else
                    foot(i) = 0;
                end

            check = input('Do you need to mark the foot again? (Y/N) ', 's');
            
            panel(i) = set;
            [cali_temp] = findCali_Taxol(date,set);
            for k = 1:length(cali_temp)
                cali(i,k) = cali_temp(k);
            end
        end
        if length(x1) == 0
            strikes(1:4,1) = 0;
        else
            strikes = spikes;
            strikes(3,:) = foot;
            strikes(4,:) = panel; 
        end
    end
 end