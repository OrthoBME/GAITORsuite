function [strikes,cali] = IDspikes_ForeHindPairs(channel, date)

plot(channel)
title('Click ONCE on the spikes you want to keep. ENTER when done. No spikes - just ENTER');
[SpikeX, SpikeY] = getpts;

check = isempty(SpikeX);
if check == 1
    fprintf('No Spikes Selected. \n');         
    strikes = 0;
    cali = 0;
    return
end

close ALL 

%%%%% ID Panel Steps       
[r, ~] = size(SpikeX);    
foot = [];
panel = [];
for i = 1:r
    figure
    hold on
    plot(channel,'k-')
    plot(SpikeX(i),SpikeY(i),'ro')
    xlabel('Matrix Index (not time)')
    ylabel('Charge')
    title('Foot Strikes')
    hold off
    q3 = input('Is this a LEFT or RIGHT foot strike? (L/R)  ','s');
        if q3 == 'L' || q3 == 'l'
            foot(i) = 1;
        else
            foot(i) = 0;
        end
    q4 = input('Which panel is this step on? (A/B)  ','s');
        panel(i) = q4;
        [cali_temp] = findCali2(date,q4);
        for k = 1:length(cali_temp)
            cali(i,k) = cali_temp(k);
        end
end 
if isempty(SpikeX) == 1
    strikes(1:3,1) = 0;
else
    strikes = SpikeX';
    strikes(2,:) = foot;
    strikes(3,:) = panel; 
end

end  % end for function