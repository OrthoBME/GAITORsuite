function [] = EDGARStepTrackerv2(Input,PawFilter,BGCase)

%% EDGAR Step Tracker - May 30, 2018 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Brittany Y. Jacobs
%
% Last Updated: May 30, 2018
% Load input file and batch of videos. Reconstruct pawprint image and 
% overlay with panel boundaries and labels. Label L/R. Save images.
% Repeat for each trial.

%% Load Input, Select Batch, and Import Variables %%%%%%%%%%%%%%%%%%%%%%%%%

% Select the batch of video files you want to run.
Directory = uigetdir;
File = uipickfiles('FilterSpec',Directory,'Type',{'*.avi','.avi'});
% Sets up counters for error and file tracker for batch.
ErrorCount = 1;
FileCount = 1;
Finish = length(File);
ErrVids = [];
TrialIDName = [];

load(Input)
PawFilter = str2func(PawFilter);

while FileCount <= Finish
try
% Pull out necessary variables from "Input" cell array.  Description of 
% these variables are located in the "Input_Setup.m" file.
    Batch = Input.Batch;
    ArenaZCoordinate = Input.ZCoordinates(2);
    Parallax = Input.Parallax;
    HeaderYN = Input.Header;
    Header = Input.HeaderPixels;
    ConcatenateVideos = Input.ConcatenateVideos;
    FigShow = Input.OutputFigs;
    A = Input.PlateBounds(1);    AB = Input.PlateBounds(2);
    B = Input.PlateBounds(3);    C = Input.PlateBounds(4);
    CD = Input.PlateBounds(5);   D = Input.PlateBounds(6);

% Correct BGcase variable for capitalization.
    switch BGCase  
        case 'rat'
            BGCase = 'Rat';
        case 'paw'
            BGCase = 'Paw';
        case 'both'
            BGCase = 'Both';
        case 'none'
            BGCase = 'None';
        otherwise
            % Do nothing
    end 

% Correct ArenaZCoordinate pixel adjustment if Header is set to Y (add back
% in pixel subtraction made in InputSetup as no video adjustment is made in
% this code the way it is in AGATHAv2.
    if HeaderYN == 'Y'
        ArenaZCoordinate = ArenaZCoordinate + Header;
    end
    
% This is needed for the multiselect.  Always put the file in this format.
File = cellstr(File); 

% VideoName - use the full root for best results.
VideoName = File{FileCount};

% Break up filename into path, name, and extension.
% TrialIDName - Files associated with this run will be saved with this 
% label. You can set this to be part of the video name, but then videos 
% need to be saved with a very consistent labeling pattern.  
% Running batches, it's typically easier to pass a label.
% Here, we pull TrialIDName from the filename. 
[~,TrialIDName,~] = fileparts(VideoName); 
TrialIDName(TrialIDName == '.' ) = [];
    
% Load video
    clear Video
    disp (' ');
    disp('Loading video... 1-2 minutes processing time');
    
    if exist('VideoName','var')
        v1 = VideoName;
        if strcmp(ConcatenateVideos,'Y')
            VideoName(end-4) = '1';
            v2 = VideoName;
            VideoName(end-4) = '2';
            v3 = VideoName;
            VideoName(end-4) = '3';
            v4 = VideoName;
            VideoName(end-4) = '4';
            v5 = VideoName;
        end
    else
        disp('Error - Video does not exist within the directory');
    end
    if strcmp(ConcatenateVideos,'Y')
        if exist(v5,'file')
            v1 = VideoReader(v1);
            v2 = VideoReader(v2);
            v3 = VideoReader(v3);
            v4 = VideoReader(v4);
            v5 = VideoReader(v5);
            Vid1 = read(v1);
            Vid2 = read(v2);
            Vid3 = read(v3);
            Vid4 = read(v4);
            Vid5 = read(v5);
            Video = cat(4,Vid1,Vid2,Vid3,Vid4,Vid5);
        elseif exist(v4,'file')
            v1 = VideoReader(v1);
            v2 = VideoReader(v2);
            v3 = VideoReader(v3);
            v4 = VideoReader(v4);
            Vid1 = read(v1);
            Vid2 = read(v2);
            Vid3 = read(v3);
            Vid4 = read(v4);
            Video = cat(4,Vid1,Vid2,Vid3,Vid4);
        elseif exist(v3,'file')
            v1 = VideoReader(v1);
            v2 = VideoReader(v2);
            v3 = VideoReader(v3);
            Vid1 = read(v1);
            Vid2 = read(v2);
            Vid3 = read(v3);
            Video = cat(4,Vid1,Vid2,Vid3);
        elseif exist(v2,'file')
            v1 = VideoReader(v1);
            v2 = VideoReader(v2);
            Vid1 = read(v1);
            Vid2 = read(v2);
            Video = cat(4,Vid1,Vid2);
        else
            v1 = VideoReader(v1);  
            Video = read(v1);
        end
    else
        v1 = VideoReader(v1);  
        Video = read(v1);
    end
    
% Video is now stored in the variable Video, so we clear the workspace 
% of large, unnecessary variables
    clear v1 v2 v3 v4 v5 Vid1 Vid2 Vid3 Vid4 Vid5
    disp('Video Loaded');
    disp(' ');
    
% ZMAX is the height of the video (1280 x 1080 video will have a ZMAX of 1080).
% XMAX is the height of the video (1280 x 1080 video will have a XMAX of 1280).
% colorchannel is not used, but needs to be called in order to get frames.
% FrameMAX is the number of frames in the video.
    [ZMax, XMax, ~, FrameMax] = size(Video);
  
% Load FSTO structure and DATA matrix.
    load([TrialIDName, 'FSTOStruct.mat']);
    
    Direction = FSTOStruct.Direction;
    AvgRatArea = FSTOStruct.AvgRatArea;
    
    LoadDATAName = [TrialIDName, '_DATA.mat'];

    if exist(LoadDATAName,'file') == 1  
        load([TrialIDName, '_DATA.mat']);
        AGATHAData = DATA.AGATHA;
        FSTOData(:,1:8) = AGATHAData(:,1:8);
    else
% Try to create a functional FSTOData from the raw FSTO image
        FSTORaw = FSTOStruct.ImageMat;        
        LabeledFSTO = bwlabel(FSTORaw);
        FSTOStats = regionprops(LabeledFSTO, 'Centroid', 'Extrema');
        % Recreate Black & White FSTO Image.
        for i = 1:max(max(LabeledFSTO))
            if Direction == 'L'
                FS = [FSTOStats(i).Extrema(2)-0.5,FSTOStats(i).Extrema(10)-0.5];
                TO = [FSTOStats(i).Extrema(6)-0.5,FSTOStats(i).Extrema(14)-0.5];
                ObjCent = [FSTOStats(i).Centroid(1),FSTOStats(i).Centroid(2)];
            else
                FS = [FSTOStats(i).Extrema(1)-0.5,FSTOStats(i).Extrema(9)-0.5];
                TO = [FSTOStats(i).Extrema(5)-0.5,FSTOStats(i).Extrema(13)-0.5];
                ObjCent = [FSTOStats(i).Centroid(1),FSTOStats(i).Centroid(2)];
            end
            FSTODataNew(i,:) = [i,0,FS,TO,ObjCent];
        end

        FSTODataNew = sortrows(FSTODataNew, 3);
        RealFSTOObjs = find(FSTODataNew(:,3) > 0);
        FSTODataNew = FSTODataNew(min(RealFSTOObjs):max(RealFSTOObjs),:);

% Define Fore and Hind Paws and Locate X Coordinate for Finding Paws.
        FSTOObjCentroid(:,1:2) = FSTODataNew(:,7:8);
        CentroidBetas = polyfit(FSTOObjCentroid(:,1),FSTOObjCentroid(:,2),1);
        XSpace = linspace(1,size(LabeledFSTO,2));
% CentroidLine = CentroidBetas(2)+CentroidBetas(1)*XSpace;

        % Define Fore and Hind Paws.
        for i = 1:length(FSTODataNew(:,1))
            if FSTODataNew(i,7) ~= 0
                ObjResidual = FSTODataNew(i,8) - (CentroidBetas(2) + CentroidBetas(1)*FSTODataNew(i,7));
                if ObjResidual < 0
                    FSTODataNew(i,2) = 1; % ForeLimb = 1
                else
                    FSTODataNew(i,2) = 0; % HindLimb = 0
                end
            end
        end
        FSTOData = FSTODataNew;
    end

%% Reconstruct the Paw Image Background %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Constructs the best possible background for paw prints
    PawsFirstFrame = Video(1:ZMax,:,:,1);
    PawsEndFrame = Video(1:ZMax,:,:,FrameMax);
    Background1 = [PawsFirstFrame(:,1:floor(XMax/2),:,:), ...
        PawsEndFrame(:,(floor(XMax/2)+1):XMax,:,:)];
    Background2 = [PawsEndFrame(:,1:floor(XMax/2),:,:), ...
        PawsFirstFrame(:,(floor(XMax/2)+1):XMax,:,:)];

% Picks the best background based upon the consistency of the image.
% Background that doesn't have the rat eliminated should have a higher
% variability in the red, green, and blue channels.
    RedVariability = std(std(double(Background1(:,:,1)))) - ...
        std(std(double(Background2(:,:,1))));
    GreenVariability = std(std(double(Background1(:,:,2)))) - ...
        std(std(double(Background2(:,:,2))));
    BlueVariability = std(std(double(Background1(:,:,3)))) - ...
        std(std(double(Background2(:,:,3))));
    if (RedVariability < 0) && (GreenVariability < 0) && (BlueVariability < 0)
        PawsBackground = Background1;
    elseif (RedVariability > 0) && (GreenVariability < 0) && (BlueVariability < 0)
        PawsBackground = Background1;
    elseif (RedVariability < 0) && (GreenVariability > 0) && (BlueVariability < 0)
        PawsBackground = Background1;
    elseif (RedVariability < 0) && (GreenVariability < 0) && (BlueVariability > 0)
        PawsBackground = Background1;
    else
        PawsBackground = Background2;
    end

    clear Background1 Background2 RedVariability GreenVariability ...
        BlueVariability TopFirstFrame TopEndFrame BottomFirstFrame ...
        BottomEndFrame PawsFirstFrame PawsEndFrame 

%% Find Paw Prints %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Create base image and ID where paw prints should occur.
    PawImages = PawsBackground(ArenaZCoordinate:ZMax,1:XMax);
    PawImages(:,:,1) = 1;   PawImages(:,:,2) = 1;   PawImages(:,:,3) = 1;
    ForePawImages = im2bw(PawImages);       HindPawImages = im2bw(PawImages);

% Define paw # & Fore/Hind - same as FSTO.
    PawPrintData(:,1) = FSTOData(:,1);      PawPrintData(:,2) = FSTOData(:,2);  

    for i = 1:length(FSTOData(:,1))
    try

% Account for Parallax & Set Up Window to Look for Paw
% Get x-coordinate from FSTO as initial guess.
            XPawCoordinate = FSTOData(i,3);  

% If paw is on the left side of screen.
        if XPawCoordinate < XMax/2  
            XPawCenter = XPawCoordinate + round(((XMax/2) - XPawCoordinate)*Parallax,0);
            XPawMin = XPawCenter-round(AvgRatArea/750,0);
            XPawMax = XPawCenter+round(AvgRatArea/750,0);
        else 
            XPawCenter = XPawCoordinate - round((XPawCoordinate - (XMax/2))*Parallax,0);
            XPawMin = XPawCenter-round(AvgRatArea/750,0);
            XPawMax = XPawCenter+round(AvgRatArea/750,0);
        end

% Safety Value for XPawMin and XPawMax.
        if XPawMin < 1
            XPawMin = 1;
        end
        if XPawMax > XMax
            XPawMax = XMax;
        end

% Stance time is found in order to determine how long to run the
% filter.
        StanceTime = FSTOData(i,6) - FSTOData(i,4);

% Find Background for Paw
        PawPrintBackground = PawsBackground(ArenaZCoordinate:ZMax,XPawMin:XPawMax,:);

% This identifies the frame that is 20% of stance and finds the paw.
        j = (FSTOData(i,4) + round(StanceTime*.2,0));

% FOREPAWS ONLY
        if PawPrintData(i,2) == 1 % Forepaw
            ForePawPrint = Video(ArenaZCoordinate:ZMax,XPawMin:XPawMax,:,j-1);

% Cases to determine whether background should be subtracted before
% running filter or not.
            switch BGCase
                case 'Rat'
                    % Do nothing
                case 'Paw'
                    ForePawPrint = ForePawPrint - PawPrintBackground;       
% When you subtract the background from the original image, the
% new background is not perfectly black [0 0 0].  To correct this,
% set all pixels < 10 to 0.  
                    ForePawPrint(ForePawPrint(:,:) < 10) = 0;
                case 'Both'
                    ForePawPrint = ForePawPrint - PawPrintBackground;     
% When you subtract the background from the original image, the
% new background is not perfectly black [0 0 0].  To correct this,
% set all pixels < 10 to 0.  
                    ForePawPrint(ForePawPrint(:,:) < 10) = 0;
                case 'None'
                    % Do nothing
                otherwise
                    fprintf('BGcase incorrectly defined');
            end

% Create mask based on chosen histogram thresholds.
            [~,ForePawPrint] = PawFilter(ForePawPrint);

% Sets non-zero items to white.
            ForePawPrint(ForePawPrint(:,:) > 0) = 255;

% Additional background noise reduction. If any RGB channel = 0, 
% set the whole pixel to [0 0 0].
            for h = 1:size(ForePawPrint,1)
                for hh = 1:size(ForePawPrint,2)
                    if (ForePawPrint(h,hh,1) == 0 || ForePawPrint(h,hh,2) == 0 ...
                            || ForePawPrint(h,hh,3) == 0)
                        ForePawPrint(h,hh,:) = 0; 
                    end
                end
            end

            ForePawPrint = rgb2gray(ForePawPrint);  

% Select the largest area (the paw), ignore all other areas.
            LabeledPawFinal = bwlabel(ForePawPrint);
            PawStats = regionprops(LabeledPawFinal, 'Area'); 
            PawArea = [PawStats.Area]';
            MaxPaw = find(PawArea == max(PawArea));
            LabeledPawFinal(LabeledPawFinal ~= MaxPaw(1)) = 0;
            ForePawPrint = LabeledPawFinal;

            LabeledForePawPrint = ForePawPrint;
            ForePawPrintID = MaxPaw;

        else
% HINDPAWS ONLY
            HindPawPrint = Video(ArenaZCoordinate:ZMax,XPawMin:XPawMax,:,j-1);

% Cases to determine whether background should be subtracted before
% running filter or not.
            switch BGCase
                case 'Rat'
                    % Do nothing
                case 'Paw'
                    HindPawPrint = HindPawPrint - PawPrintBackground;
% When you subtract the background from the original image, the
% new background is not perfectly black [0 0 0].  To correct this,
% set all pixels < 10 to 0.  
                    HindPawPrint(HindPawPrint(:,:) < 10) = 0;

                case 'Both'
                    HindPawPrint = HindPawPrint - PawPrintBackground;
                    HindPawPrint = HindPawPrint - PawPrintBackground;
% When you subtract the background from the original image, the
% new background is not perfectly black [0 0 0].  To correct this,
% set all pixels < 10 to 0.  
                    HindPawPrint(HindPawPrint(:,:) < 10) = 0;
                case 'None'
                    % Do nothing
                otherwise
                    fprintf('BGcase incorrectly defined');
            end

% Create mask based on chosen histogram thresholds
            [~,HindPawPrint] = PawFilter(HindPawPrint);

% Sets non-zero items to white.
            HindPawPrint(HindPawPrint(:,:) > 0) = 255;

            for h = 1:size(HindPawPrint,1)
                for hh = 1:size(HindPawPrint,2)
                    if (HindPawPrint(h,hh,1) == 0 || HindPawPrint(h,hh,2) == 0 || HindPawPrint(h,hh,3) == 0)
                        HindPawPrint(h,hh,:) = 0; 
                    end
                end
            end

            HindPawPrint = rgb2gray(HindPawPrint);

            LabeledPawFinal = bwlabel(HindPawPrint);
            PawStats = regionprops(LabeledPawFinal, 'Area'); 
            PawArea = [PawStats.Area]';
            MaxPaw = find(PawArea == max(PawArea));
            LabeledPawFinal(LabeledPawFinal ~= MaxPaw(1)) = 0;
            HindPawPrint = LabeledPawFinal;

            LabeledHindPawPrint = HindPawPrint;
            HindPawPrintID = MaxPaw;
        end

% Find Paw Location.
% FOREPAW ONLY
         if PawPrintData(i,2) == 1 % Forepaw
            ForePawPrintStats = regionprops(LabeledForePawPrint, 'Centroid');
            ForePawWidth = size(LabeledForePawPrint,2);
            ForePawXPosition = XPawCenter + (ForePawPrintStats(ForePawPrintID).Centroid(1) - (ForePawWidth/2));
            ForePawLoc(i,2:3) = [ForePawXPosition,ForePawPrintStats(ForePawPrintID).Centroid(2)];    
            ForePawLoc(i,1) = PawPrintData(i,1);

% Create Paw Print Image
            LabeledForePaw2 = bwlabel(LabeledForePawPrint);
            ForePawImages(:,XPawMin:XPawMax) =  ForePawImages(:,XPawMin:XPawMax) + LabeledForePaw2; 
            ForePawPrintStats2 = regionprops(ForePawImages, 'BoundingBox');
            PawPrintData(i,4) = ForePawLoc(i,2);
            PawPrintData(i,5) = ForePawLoc(i,3);        
         else
% HINDPAW ONLY
            HindPawPrintStats = regionprops(LabeledHindPawPrint, 'Centroid');
            HindPawPrintWidth = size(LabeledHindPawPrint,2);
            HindPawXPosition = XPawCenter + (HindPawPrintStats(HindPawPrintID).Centroid(1) - (HindPawPrintWidth/2));
            HindPawLoc(i,2:3) = [HindPawXPosition,HindPawPrintStats(HindPawPrintID).Centroid(2)];
            HindPawLoc(i,1) = PawPrintData(i,1);

% Create Paw Print Image
            LabeledHindPaw2 = bwlabel(LabeledHindPawPrint);
            HindPawImages(:,XPawMin:XPawMax) = HindPawImages(:,XPawMin:XPawMax) + LabeledHindPaw2;
            HindPawPrintStats2 = regionprops(HindPawImages, 'BoundingBox');
            PawPrintData(i,4) = HindPawLoc(i,2);
            PawPrintData(i,5) = HindPawLoc(i,3);
         end

         if PawPrintData(i,2) == 1
             f = length(ForePawPrintStats2);
             ForeBounds(i,1) = PawPrintData(i,1);
             ForeBounds(i,2:5) = [ForePawPrintStats2(f).BoundingBox(1), ...
                 ForePawPrintStats2(f).BoundingBox(2), ForePawPrintStats2(f).BoundingBox(3), ...
                 ForePawPrintStats2(f).BoundingBox(4)];
         else
             h = length(HindPawPrintStats2);
             HindBounds(i,1) = PawPrintData(i,1);
             HindBounds(i,2:5) = [HindPawPrintStats2(h).BoundingBox(1), ...
                 HindPawPrintStats2(h).BoundingBox(2), HindPawPrintStats2(h).BoundingBox(3), ...
                 HindPawPrintStats2(h).BoundingBox(4)]; 
         end   
    end %try end
    end

%% Determine if Paw is Left or Right %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FOREPAWS ONLY
    ForePawLocLR = ForePawLoc;
% Removing rows of zeros to leave only forepaw rows.
    ForePawLocLR(all(ForePawLocLR == 0,2),:) = [];  

% 0 = Right Foot, 1 = Left Foot.
    for i = 1:(length(ForePawLocLR(:,1)))
        if i == 1
            ForePawLocLR(i,5) = nan;
            if Direction == 'L'
                ForePawLocLR(i,4) = ForePawLocLR(i,3) > ForePawLocLR(i+1,3);  
            else
                ForePawLocLR(i,4) = ForePawLocLR(i,3) < ForePawLocLR(i+1,3); 
            end
        elseif i == length(ForePawLocLR(:,1))
            ForePawLocLR(i,5) = nan;
            if Direction == 'L'
                ForePawLocLR(i,4) = ForePawLocLR(i,3) > ForePawLocLR(i-1,3); 
            else
                ForePawLocLR(i,4) = ForePawLocLR(i,3) < ForePawLocLR(i-1,3);
            end
         else
            if Direction == 'L'
                ForePawLocLR(i,4) = ForePawLocLR(i,3) > ForePawLocLR(i-1,3); 
                ForePawLocLR(i,5) = ForePawLocLR(i,3) > ForePawLocLR(i+1,3);
            else
                ForePawLocLR(i,4) = ForePawLocLR(i,3) < ForePawLocLR(i-1,3);
                ForePawLocLR(i,5) = ForePawLocLR(i,3) < ForePawLocLR(i+1,3);
            end
        end

        if isnan(ForePawLocLR(i,5)) == 1
            ForePawLocLR(i,6) = ForePawLocLR(i,4);
        elseif ForePawLocLR(i,4) == ForePawLocLR(i,5)
            if ForePawLocLR(i,4) == 0
                ForePawLocLR(i,6) = 0;
            else
                ForePawLocLR(i,6) = 1;
            end
        else
% 400 means the code can't verify right vs left for this step. 
% Will need to be manually defined.
            ForePawLocLR(i,6) = 400; 
        end
    end

% HINDPAWS ONLY
    HindPawLocLR = HindPawLoc;
% Removing rows of zeros to leave only hindpaw rows.
    HindPawLocLR(all(HindPawLocLR == 0,2),:) = [];  

% 0 = Right Foot, 1 = Left Foot.
    for i = 1:(length(HindPawLocLR(:,1)))
        if i == 1
            HindPawLocLR(i,5) = nan;
            if Direction == 'L'
                HindPawLocLR(i,4) = HindPawLocLR(i,3) > HindPawLocLR(i+1,3);  
            else
                HindPawLocLR(i,4) = HindPawLocLR(i,3) < HindPawLocLR(i+1,3);
            end
        elseif i == length(HindPawLocLR(:,1))
            HindPawLocLR(i,5) = nan;
            if Direction == 'L'
                HindPawLocLR(i,4) = HindPawLocLR(i,3) > HindPawLocLR(i-1,3);
            else
                HindPawLocLR(i,4) = HindPawLocLR(i,3) < HindPawLocLR(i-1,3);
            end
         else
            if Direction == 'L'
                HindPawLocLR(i,4) = HindPawLocLR(i,3) > HindPawLocLR(i-1,3);
                HindPawLocLR(i,5) = HindPawLocLR(i,3) > HindPawLocLR(i+1,3); 
            else
                HindPawLocLR(i,4) = HindPawLocLR(i,3) < HindPawLocLR(i-1,3);
                HindPawLocLR(i,5) = HindPawLocLR(i,3) < HindPawLocLR(i+1,3);
            end
        end

        if isnan(HindPawLocLR(i,5)) == 1
            HindPawLocLR(i,6) = HindPawLocLR(i,4);
        elseif HindPawLocLR(i,4) == HindPawLocLR(i,5)
            if HindPawLocLR(i,4) == 0
                HindPawLocLR(i,6) = 0;
            else
                HindPawLocLR(i,6) = 1;
            end
        else
% 400 means the code can't verify right vs left for this step. 
% Will need to be manually defined.
            HindPawLocLR(i,6) = 400; 
        end
    end

% Best guess for unknown (=400) paws. Look to the step before and after the
% unknown step.   
    Seek400 = find(ForePawLocLR(:,6) == 400);
    for i = 1:length(Seek400)
        Current = ForePawLocLR(Seek400(i),3);
        Before = ForePawLocLR(Seek400(i) - 1,3);
        After = ForePawLocLR(Seek400(i) + 1,3);
        if abs(Before-Current) > abs(After - Current) 
            ForePawLocLR(Seek400,6) = ForePawLocLR(Seek400 + 1,6);
        else
            ForePawLocLR(Seek400,6) = ForePawLocLR(Seek400 - 1,6);
        end
    end
    clear Seek400 Current Before After

    Seek400 = find(HindPawLocLR(:,6) == 400);
    for i = 1:length(Seek400)
        Current = HindPawLocLR(Seek400(i),3);
        Before = HindPawLocLR(Seek400(i) - 1,3);
        After = HindPawLocLR(Seek400(i) + 1,3);
        if abs(Before-Current) > abs(After - Current) 
            HindPawLocLR(Seek400,6) = HindPawLocLR(Seek400 + 1,6);
        else
            HindPawLocLR(Seek400,6) = HindPawLocLR(Seek400 - 1,6);
        end
    end

    AllPawLoc = vertcat(ForePawLocLR, HindPawLocLR);
    AllPawLoc = sortrows(AllPawLoc,1);

% Sort left/rights to match the order of PawPrint_Data & FSTO_Data. 
% Move the R = 0 and L = 1 data into column 3 of PawPrint_Data.
    for i = 1:(length(AllPawLoc(:,1)))
        Row = find(AllPawLoc(i,1) == PawPrintData(:,1));
        PawPrintData(Row,3) = AllPawLoc(i,6);
    end  

%% Plot Paw Print Images %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Separate into a single subplot with forepaws, all, and hindpaws in
% separate plots.  Also, convert the pawprint image to RGB and label them
% to match the FSTO image. 

% Create line markers for force panel borders.
    x = [A AB B C CD D];
    ystart = [0 0 0 0 0 0];
    yend = [ZMax ZMax ZMax ZMax ZMax ZMax];

% FOREPAWS ONLY
% Create RGB version of Pawprint Image - Forepaws.
    for i = 1:length(PawPrintData(:,1))
        BlueLabeledPawPrint = bwlabel(ForePawImages);
        BlueLabeledPawPrint(BlueLabeledPawPrint == PawPrintData(i,1)) = 200;
        PawZeros = zeros(size(BlueLabeledPawPrint,1),size(BlueLabeledPawPrint,2));
        ForePawRGB = cat(3, PawZeros, PawZeros, BlueLabeledPawPrint);
    end

    if FigShow == 'N'
        figure('visible','off');
    else
        figure(1);
    end
    warning('off','all');
    
    subplot(3,1,1);
    imshow(ForePawRGB); 
    hold on
    for i = 1:length(PawPrintData(:,1))
        if PawPrintData(i,2) == 1    % Forepaw   
            if PawPrintData(i,1) < 10
                text(PawPrintData(i,4) - 4,PawPrintData(i,5),int2str(PawPrintData(i,1)), 'Color', 'white');
            else
                text(PawPrintData(i,4) - 10,PawPrintData(i,5),int2str(PawPrintData(i,1)), 'Color', 'white');
            end
        end
    end
    
    set(gcf,'CurrentAxes',subplot(3,1,1));
    for ix = 1:length(x)
        line([x(ix) x(ix)],[ystart(ix) yend(ix)],'Color','white');
    end
    title('Forepaws Only')


% HINDPAWS ONLY
% Create RGB version of Pawprint Image - Hindpaws.
    for i = 1:length(PawPrintData(:,1))
        RedLabeledPawPrint = bwlabel(HindPawImages);
        RedLabeledPawPrint(RedLabeledPawPrint == PawPrintData(i,1)) = 200;
        PawZeros = zeros(size(RedLabeledPawPrint,1),size(RedLabeledPawPrint,2));
        HindPawRGB = cat(3, RedLabeledPawPrint, PawZeros, PawZeros);
    end

    subplot(3,1,3);
    imshow(HindPawRGB);
    for i = 1:length(PawPrintData(:,1))
        if PawPrintData(i,2) == 0  % Hindpaw
            if PawPrintData(i,1) < 10
                text(PawPrintData(i,4) - 4,PawPrintData(i,5),int2str(PawPrintData(i,1)), 'Color', 'white');
            else
                text(PawPrintData(i,4) - 10,PawPrintData(i,5),int2str(PawPrintData(i,1)), 'Color', 'white');
            end
        end
    end
    
    set(gcf,'CurrentAxes',subplot(3,1,3));
    for ix = 1:length(x)
        line([x(ix) x(ix)],[ystart(ix) yend(ix)],'Color','white');
    end
    title('Hindpaws Only')
    
% ALL PAWS
    subplot(3,1,2);
    imshow(ForePawRGB + HindPawRGB);
    for i = 1:length(PawPrintData(:,1))
        if PawPrintData(i,1) < 10
            text(PawPrintData(i,4) - 4,PawPrintData(i,5),int2str(PawPrintData(i,1)), 'Color', 'white');
            if PawPrintData(i,3) == 0
                text(PawPrintData(i,4) - 4,PawPrintData(i,5)- 25,'R', 'Color', 'white');
            else
                text(PawPrintData(i,4) - 4,PawPrintData(i,5)- 25,'L', 'Color', 'white');
            end
        else
            text(PawPrintData(i,4) - 10,PawPrintData(i,5),int2str(PawPrintData(i,1)), 'Color', 'white');
            if PawPrintData(i,3) == 0
                text(PawPrintData(i,4) - 4,PawPrintData(i,5)- 25,'R', 'Color', 'white');
            else
                text(PawPrintData(i,4) - 4,PawPrintData(i,5)- 25,'L', 'Color', 'white');
            end
        end
    end
    
    set(gcf,'CurrentAxes',subplot(3,1,2));
    for ix = 1:length(x)
        line([x(ix) x(ix)],[ystart(ix) yend(ix)],'Color','white');
    end    
    title('All Paw Prints')
    truesize
    hold off
% Save expanded Paw print images.
    Filename_EDGARAllPaws = [TrialIDName,'_EDGARAllPaws.jpg'];
    Fig = gcf;
    Fig.InvertHardcopy = 'off';
    saveas(gcf,Filename_EDGARAllPaws);
  
% Save a bigger image of combined fore/hind steps. 
    if FigShow == 'N'
        figure('visible','off');
    else
        figure(2);
    end
    warning('off','all');
    
    imshow(ForePawRGB + HindPawRGB);
    hold on
    for i = 1:length(PawPrintData(:,1))
        hold on
        if PawPrintData(i,1) < 10
            text(PawPrintData(i,4) - 4,PawPrintData(i,5),int2str(PawPrintData(i,1)), 'Color', 'white');
            if PawPrintData(i,3) == 0
                text(PawPrintData(i,4) - 4,PawPrintData(i,5)- 25,'R', 'Color', 'white');
            else
                text(PawPrintData(i,4) - 4,PawPrintData(i,5)- 25,'L', 'Color', 'white');
            end
        else
            text(PawPrintData(i,4) - 10,PawPrintData(i,5),int2str(PawPrintData(i,1)), 'Color', 'white');
            if PawPrintData(i,3) == 0
                text(PawPrintData(i,4) - 4,PawPrintData(i,5)- 25,'R', 'Color', 'white');
            else
                text(PawPrintData(i,4) - 4,PawPrintData(i,5)- 25,'L', 'Color', 'white');
            end
        end
    end
    
    for ix = 1:length(x)
        line([x(ix) x(ix)],[ystart(ix) yend(ix)],'Color','white');
    end
    PlotName = [TrialIDName,' Paw Print Tracker'];
    title(PlotName,'Interpreter', 'none')
    truesize
    hold off
% Save Pawprint Images.
    Filename_PawTracker = [TrialIDName,'_PawTracker.jpg'];
    Fig = gcf;
    Fig.InvertHardcopy = 'off';
    saveas(gcf,Filename_PawTracker);

    fprintf('Paw Images Saved. \n');

%% Prepare for Next File & Error Catch %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
% Don't try and look at file{2} if you only chose 1 file to begin with.
   if length(File) == 1
       break
   end
   close all;

catch MException
    ErrorLine = MException.stack.line;
    fprintf(['\nERROR encountered in ', TrialIDName, ' at Line: ', '%i', '\n'],ErrorLine);
    ErrorMessage = MException.message;
    disp(ErrorMessage);

    ErrVids{ErrorCount,1} = TrialIDName;
    ErrVids{ErrorCount,2} = ErrorLine;
    ErrVids{ErrorCount,3} = ErrorMessage;

    ErrorCount = ErrorCount + 1;
    beep
end

% Set filecount to address next file in batch.
FileCount = FileCount + 1;
end

% If there were error messages, save them to the directory.
if isempty(ErrVids) == 0
    Filename_TrackerErrors = [Batch, '_TrackerErrors.mat'];
    save(Filename_TrackerErrors, 'ErrVids');
end

close all;
